# Feature tree for the Files tab

This adds a checkable Feature tree to Studio's **Files** tab, matching the
"Filter Assemblies by Feature" pattern from your reference screenshot — one
dropdown filters the grid, another assigns features to selected files, plus
inline feature management (add/remove/nest).

## How to apply

Copy each file below into the matching path in your repo, overwriting the
existing ones (2 new files are additions, the rest are edits to files that
already exist in `Final_ASPLSHIELD.zip`):

```
src/ASPLShield.Core/InstallerFile.cs          (edited - added FeatureName)
src/ASPLShield.Core/InstallerProject.cs       (edited - added Features collection)
src/ASPLShield.Studio/Models/FeatureTreeNode.cs        (new)
src/ASPLShield.Studio/Controls/FeatureTreeDropDown.xaml     (new)
src/ASPLShield.Studio/Controls/FeatureTreeDropDown.xaml.cs  (new)
src/ASPLShield.Studio/ViewModels/FileSystemEditorViewModel.cs (edited)
src/ASPLShield.Studio/Views/MainWindow.xaml       (edited - Files tab only)
src/ASPLShield.Studio/Views/MainWindow.xaml.cs    (edited - one new handler)
```

No `.csproj` changes needed — it's an SDK-style WPF project with implicit
globbing, so the new files under `Controls/` and `Models/` are picked up
automatically. No DI registration changes needed either; the feature tree
lives inside the existing `FileSystemEditorViewModel`, already registered.

## What was already there

`InstallerFeature.cs` (Name, DisplayName, ParentFeatureName, IsSelectedByDefault,
IsRequired) already existed in `ASPLShield.Core` but wasn't wired up to
anything — no `Features` collection on the project, no UI. This patch
finishes wiring it up rather than introducing a new model.

## What's new

- **`InstallerFile.FeatureName`** — which feature (by `InstallerFeature.Name`)
  a file/folder belongs to. Empty = feature-independent (always installed).
- **`InstallerProject.Features`** — the project's flat feature list, persisted
  in the `.asplproj` XML under a new `<Features>` element (existing projects
  will just get an empty one on next save; nothing else changes).
- **`FeatureTreeNode`** — wraps `InstallerFeature` as a checkable tree node
  with tri-state parent/child propagation (checking a parent checks all its
  children; a parent shows indeterminate when only some children are
  checked) and builds the tree from the flat list via `ParentFeatureName`.
- **`FeatureTreeDropDown`** — the themed control (uses your existing
  `InputBackgroundBrush` / `InputBorderBrush` / `TextPrimaryBrush` /
  `CardBorderBrush` resources): a ToggleButton that looks like your other
  inputs, opening a checkbox `TreeView` popup underneath. `SingleSelect="True"`
  makes checking one node uncheck the rest (used for "Assign to").
- **Files tab additions**:
  - "Filter Files by Feature" dropdown — multi-check, filters the grid via
    `ICollectionView.Filter` (files grid is now bound to `Files.FilesView`
    instead of `Files.Files` directly).
  - "Assign to" dropdown + "Apply to Selected" button — single-check,
    writes the chosen feature onto every currently-selected grid row
    (multi-select already worked via Ctrl/Shift-click, just wasn't read
    anywhere before).
  - A feature combo + "Add Feature" / "Remove Feature" buttons — type a
    name, optionally select an existing feature first to nest the new one
    underneath it, or select a feature and remove it (children get
    re-parented, affected files get unassigned rather than orphaned).
  - New "Feature" column on the Files grid so assignments are visible at a
    glance without opening the dropdown.

## Known limitation

Up/Down reordering still operates on the file's index in the unfiltered
list, so if a feature filter is active, "Up"/"Move" may not visually match
the filtered grid's row order. Minor, but worth knowing — happy to fix if
it bugs you in practice.

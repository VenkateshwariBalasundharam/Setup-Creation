# ASPLShield Studio Help

ASPLShield Studio is the visual editor for building ASPLShield installer projects. It lets you create a project, add files and shortcuts, define registry and IIS changes, configure services and prerequisites, and then build the installer output.

## Getting Started

1. Open the solution or run the Studio app from the repo root.
2. Start Studio with `dotnet run --project src/ASPLShield.Studio/ASPLShield.Studio.csproj`.
3. Use `New Project` to begin from a blank project, or `Open` to load an existing `.asplproj` file.
4. Fill in the project details, then save before building.

## Main Workflow

1. Set the project name, version, publisher, installation folder, and output folder in the `Overview` tab.
2. Add application files in `Files`.
3. Add shortcuts in `Shortcuts`.
4. Configure registry entries, IIS sites, services, and prerequisites as needed.
5. Choose the build mode and packaging options in `Build`.
6. Review validation messages and build status in the right-hand panel.
7. Click `Build` when the project is ready.

## Overview Tab

Use `Overview` for the core project metadata.

- `Product Name` is the displayed product title.
- `Company Name` is the vendor or organization name.
- `Version` is the installer version.
- `Publisher` is the signing or publishing identity.
- `Installation Folder` is the target install path, such as `[ProgramFiles]\SampleApp`.
- `Output Folder` is where build artifacts are written.

Buttons in this area:

- `New Project` creates a fresh project.
- `Open` loads a saved `.asplproj` file.
- `Save` writes the current project to disk.
- `Build` starts installer generation.

## Files Tab

Use `Files` to define what gets installed.

- `Add Files` adds one or more individual files.
- `Add Folder` adds a folder and its contents.
- `Remove` deletes the selected file entry.
- `Up` and `Down` change the install order.

You can also drag and drop files or folders into the grid.

Columns shown in the grid:

- `Name`
- `Destination`
- `Size`
- `Folder`

## Shortcuts Tab

Use `Shortcuts` to create user-visible launch points.

- `Desktop Shortcut` adds a shortcut on the desktop.
- `Start Menu Shortcut` adds a shortcut to the Start Menu.
- `Remove` deletes the selected shortcut.
- `Up` and `Down` reorder shortcuts.

Columns shown in the grid:

- `Name`
- `Target`
- `Location`

## Registry Tab

Use `Registry` to define registry changes that should happen during install.

- `Add Entry` adds a new registry item.
- `Remove` deletes the selected entry.
- `Up` and `Down` reorder entries.

This tab is for installers that need registry values, keys, or other system integration settings.

## IIS Tab

Use `IIS` when the installer needs to configure web sites or bindings.

- `Add Site` creates a new IIS site entry.
- `Remove` deletes the selected site.
- `Up` and `Down` reorder sites.
- The binding editor lets you add, remove, and reorder bindings for the selected site.

## Services Tab

Use `Services` to install and configure Windows services.

- `Add Service` creates a service definition.
- `Remove` deletes the selected service.
- `Up` and `Down` reorder services.

## Prerequisites Tab

Use `Prerequisites` to describe runtime checks that must pass before install.

- `Add` creates a prerequisite rule.
- `Remove` deletes the selected rule.
- Each prerequisite can be marked as `Required`.
- The editor shows a validation message and remediation hint for the selected rule.

## Build Tab

Use `Build` to control how the installer is generated.

- `Create standalone uninstaller` enables a separate uninstaller project.
- `Package Icon Path` points to the installer icon file.
- `License File Path` points to the license text or RTF file.
- `MSI Authoring` switches between `WiX` and `Native Preview`.

Build mode notes:

- `WiX` generates WiX authoring and compiles the MSI.
- `Native Preview` shows the MSI database preview without the same authoring path.

Other build settings:

- `Upgrade Version Min`
- `Upgrade Version Max`
- `Upgrade Action Property`

The build page also includes a `Native Preview` section where you can inspect tables, rows, and operations, and an `Export Database` button for exporting the preview database.

## Settings and Diagnostics

The right-hand panel on the `Settings` tab is used for project-wide settings and troubleshooting.

- `Theme` changes the Studio appearance.
- `SigningCertificatePath` stores the code-signing certificate path.
- `SigningCertificatePassword` stores the signing password.
- `SigningTimestampUrl` stores the timestamp server URL.
- `SigningToolPath` stores the path to the signing tool.
- `UpdateFeedUri` stores the update feed location used by update checks.

Diagnostics area:

- Shows the current status message.
- Shows the update feed and update check status.
- Shows template status.
- Shows recent installer logs.
- Provides buttons to open the logs folder and install folder.
- Provides a `Refresh Logs` button and a `Check Updates` button.

Template buttons:

- `Save Template` saves the current project as a reusable template.
- `Refresh Templates` reloads templates from disk.
- `Apply Template` loads the selected template into the current project.
- `Delete Template` removes the selected template.

## Templates

Templates make it easier to reuse a known-good project shape.

- Save a template after you have a project configured the way you want.
- Select a template from the list to inspect its name, description, and file path.
- Apply a template to replace the current project contents.
- Delete a template when it is no longer needed.

## Project Files And Local Data

Studio stores some local data under your user profile.

- Project database: `%LocalAppData%\ASPLShield\asplshield.db`
- Template files: `%LocalAppData%\ASPLShield\Templates`
- Integration settings: `%LocalAppData%\ASPLShield\asplshield.integration.json`
- Logs: `%TEMP%\ASPLShield\Logs`

## Troubleshooting

- If `Build` is disabled, check the validation messages in the right-hand panel.
- If the app cannot copy build outputs, close other running Studio instances first.
- If logs are empty, use `Refresh Logs` after running an install or uninstall.
- If an IIS or service item looks wrong, verify the selected project settings and re-open the entry in its tab.
- If you need a clean start, close Studio and reopen it after saving your project.

## File Format

- Studio saves projects as `.asplproj`.
- The file contains the project metadata, files, shortcuts, registry data, IIS configuration, services, prerequisites, build settings, and native preview operations.

## Sample Project

A ready-made demo project is included in the repo:

- Project file: `samples/FullConfiguredSample/FullConfiguredSample.asplproj`
- Payload app: `samples/SamplePayload`
- Demo icon: `samples/FullConfiguredSample/assets/ASPLShieldSample.ico`
- Demo license: `samples/FullConfiguredSample/assets/ASPLShieldSampleLicense.txt`

To use it:

1. Build the payload app first so the EXE exists.
2. Open the `.asplproj` file in Studio.
3. Review the `Overview`, `Files`, `Shortcuts`, `Registry`, `IIS`, `Services`, `Prerequisites`, and `Build` tabs.
4. Change the output folder if you want the generated installer artifacts somewhere else.

ASPLShield smoke tests.

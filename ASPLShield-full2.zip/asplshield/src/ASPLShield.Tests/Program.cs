using System.Text.Json;
using ASPLShield.Build;
using ASPLShield.Core;
using ASPLShield.PackageEngine;
using ASPLShield.Studio;
using ASPLShield.UpdateEngine;
using Microsoft.Data.Sqlite;

var results = new List<(string Name, Func<Task> Test)>
{
    ("Project session save/open", TestProjectSessionServiceAsync),
    ("Build workflow", TestBuildWorkflowServiceAsync),
    ("Refresh snapshot", TestRefreshServiceAsync),
    ("Project serializer", TestProjectSerializerAsync),
    ("Native preview service", TestNativePreviewServiceAsync),
    ("Package validation", TestPackageValidationAsync),
    ("Install folder locator", TestInstalledProductLocatorAsync),
    ("Uninstall recovery", TestUninstallerRecoveryAsync),
    ("Prerequisite authoring", TestPrerequisiteAuthoringAsync),
    ("Prerequisite validation", TestPrerequisiteValidationAsync),
    ("Prerequisite validation messaging", TestPrerequisiteValidationMessageAsync),
    ("Registry and service validation", TestRegistryAndServiceValidationAsync),
    ("Native plan prereqs", TestNativePlanPrerequisitesAsync),
    ("Install rollback", TestInstallRollbackAsync),
    ("Shortcut rollback", TestShortcutRollbackAsync),
    ("Read-only cleanup", TestReadOnlyCleanupAsync),
    ("Template repository", TestTemplateRepositoryAsync),
    ("Update engine", TestUpdateEngineAsync),
    ("Package prerequisites", TestPackagePrerequisitesAsync),
    ("Runtime prerequisites", TestRuntimePrerequisitesAsync),
    ("Wizard templates", TestNewProjectWizardTemplatesAsync)
};

var failures = new List<string>();
foreach (var (name, test) in results)
{
    try
    {
        await test();
        Console.WriteLine($"PASS {name}");
    }
    catch (Exception ex)
    {
        failures.Add($"{name}: {ex.Message}");
        Console.WriteLine($"FAIL {name}: {ex.Message}");
    }
}

if (failures.Count > 0)
{
    Console.Error.WriteLine();
    Console.Error.WriteLine("Smoke tests failed:");
    foreach (var failure in failures)
    {
        Console.Error.WriteLine($"- {failure}");
    }

    return 1;
}

Console.WriteLine("All smoke tests passed.");
return 0;

static async Task TestProjectSessionServiceAsync()
{
    var savePath = Path.Combine(Path.GetTempPath(), $"aspl-session-{Guid.NewGuid():N}.asplproj");
    var loadedProject = ProjectFactory.Create("Loaded App", "ACME", "2.0.0", "ACME", @"[ProgramFiles]\LoadedApp", Path.GetTempPath());
    var repo = new FakeProjectRepository { LoadResult = loadedProject };
    var fileDialogs = new FakeFileDialogService
    {
        OpenProjectFileResult = savePath,
        SaveProjectFileResult = savePath
    };
    var newProjectDialog = new FakeNewProjectDialogService { Result = ProjectFactory.Create("New App", "ACME", "1.0.0", "ACME", @"[ProgramFiles]\NewApp", Path.GetTempPath()) };
    var service = new StudioProjectSessionService(fileDialogs, newProjectDialog, repo);

    var createResult = service.CreateNew();
    Assert.True(createResult.Succeeded, "CreateNew should succeed.");
    Assert.NotNull(createResult.Project);

    var openResult = await service.OpenAsync();
    Assert.True(openResult.Succeeded, "OpenAsync should succeed.");
    Assert.Equal(savePath, openResult.ProjectPath);
    Assert.Equal(1, repo.ObservedRecentProjects.Count);

    var preview = new NativePreviewViewModel();
    preview.ApplyPlan(new NativeMsiAuthoringPlan
    {
        ProductName = "Preview App",
        Version = "1.0.0",
        Publisher = "ACME",
        InstallFolder = @"[ProgramFiles]\PreviewApp",
        Tables =
        {
            new NativeMsiTableAuthoring
            {
                Name = "Property",
                Rows =
                {
                    new NativeMsiTableRow
                    {
                        Columns =
                        {
                            ["Property"] = "Value"
                        }
                    }
                }
            }
        }
    }, "plan.json", "preview.msi");

    var project = ProjectFactory.Create("Session App", "ACME", "1.0.0", "ACME", @"[ProgramFiles]\SessionApp", Path.GetTempPath());
    var saveResult = await service.SaveAsync(project, savePath, preview);
    Assert.True(saveResult.Succeeded, "SaveAsync should succeed.");
    Assert.Equal(savePath, saveResult.ProjectPath);
    Assert.True(project.NativePreviewOperations.Count > 0, "Native preview operations should be persisted.");
    Assert.True(repo.SavedProjects.Count > 0, "Project should be saved.");
}

static async Task TestBuildWorkflowServiceAsync()
{
    var repo = new FakeProjectRepository();
    var buildEngine = new FakeBuildEngine
    {
        Result = new BuildResult
        {
            PackagePath = @"C:\Out\Sample.asplpkg",
            SetupExePath = @"C:\Out\Setup.exe",
            UninstallExePath = @"C:\Out\uninstall.exe",
            MsiAuthoringPath = @"C:\Out\msi.wxs",
            MsiDatabasePath = @"C:\Out\sample.msi",
            MsiPath = @"C:\Out\sample.msi",
            Warnings = new[] { "Minor warning" }
        }
    };
    var service = new StudioBuildWorkflowService(buildEngine, repo);
    var project = ProjectFactory.Create("Build App", "ACME", "1.0.0", "ACME", @"[ProgramFiles]\BuildApp", Path.GetTempPath());

    var result = await service.BuildAsync(project, @"C:\proj\BuildApp.asplproj", Path.GetTempPath(), @"C:\src\Runtime.csproj", @"C:\src\Uninstaller.csproj", Array.Empty<string>());
    Assert.True(result.Succeeded, "Build should succeed.");
    Assert.NotNull(result.BuildResult);
    Assert.Contains(result.Messages, message => message.Contains("Build succeeded:", StringComparison.Ordinal));
    Assert.True(repo.BuildHistory.Count == 1, "Build history should be recorded.");

    var blocked = await service.BuildAsync(project, @"C:\proj\BuildApp.asplproj", Path.GetTempPath(), null, null, new[] { "Port 80 is busy" });
    Assert.False(blocked.Succeeded, "Build should fail when IIS warnings exist.");
    Assert.True(repo.BuildHistory.Count == 2, "Blocked build should be recorded as failure.");
}

static async Task TestRefreshServiceAsync()
{
    var logMonitor = new FakeLogMonitorService(new[] { "install.log: line 1", "install.log: line 2" });
    var validationService = new ProjectValidationService();
    var iisWarnings = new FakeIisWarningService(Array.Empty<string>());
    var refreshService = new StudioRefreshService(validationService, iisWarnings, logMonitor);
    var properties = new PropertiesViewModel(new FakeIntegrationSettingsStore(), new FakeFileDialogService(), new FakeSelectPrerequisiteDialogService());
    var project = ProjectFactory.Create("Refresh App", "ACME", "1.0.0", "ACME", @"[ProgramFiles]\RefreshApp", Path.GetTempPath());

    var snapshot = refreshService.Refresh(project, properties, registryHasErrors: false, serviceHasErrors: false);
    Assert.True(snapshot.SetupProjectPath is null || snapshot.SetupProjectPath.EndsWith("ASPLShield.Runtime.csproj", StringComparison.OrdinalIgnoreCase), "Setup path should resolve to the runtime project or be null.");
    Assert.True(snapshot.UninstallerProjectPath is null || snapshot.UninstallerProjectPath.EndsWith("ASPLShield.Uninstaller.csproj", StringComparison.OrdinalIgnoreCase), "Uninstaller path should resolve to the uninstaller project or be null.");
    Assert.Equal(2, snapshot.RecentLogEntries.Count);
    Assert.Equal("2 recent log entries loaded.", snapshot.RecentLogsSummary);
    Assert.True(!string.IsNullOrWhiteSpace(snapshot.BuildTooltip), "Build tooltip should be populated.");
}

static async Task TestProjectSerializerAsync()
{
    var serializer = new XmlProjectSerializer();
    var tempPath = Path.Combine(Path.GetTempPath(), $"aspl-serializer-{Guid.NewGuid():N}.asplproj");
    var project = ProjectFactory.Create("Xml App", "ACME", "3.1.4", "ACME", @"[ProgramFiles]\XmlApp", Path.GetTempPath());
    project.Files.Add(new InstallerFile
    {
        DisplayName = "App File",
        SourcePath = @"C:\Temp\App.exe",
        DestinationPath = @"bin\App.exe",
        SizeBytes = 42
    });

    await serializer.SaveAsync(project, tempPath);
    var loaded = await serializer.LoadAsync(tempPath);

    Assert.Equal(project.ProductName, loaded.ProductName);
    Assert.Equal(project.Version, loaded.Version);
    Assert.Equal(1, loaded.Files.Count);
    Assert.Equal("App File", loaded.Files[0].DisplayName);
}

static async Task TestNativePreviewServiceAsync()
{
    var tempRoot = Path.Combine(Path.GetTempPath(), $"aspl-native-{Guid.NewGuid():N}");
    Directory.CreateDirectory(tempRoot);
    var planPath = Path.Combine(tempRoot, "plan.json");
    var databasePath = Path.Combine(tempRoot, "preview.msi");
    var exportPath = Path.Combine(tempRoot, "exported.msi");

    var database = new NativeMsiDatabase
    {
        ProductName = "Preview App",
        Version = "1.0.0",
        Publisher = "ACME",
        InstallFolder = @"[ProgramFiles]\PreviewApp",
        Tables =
        {
            new NativeMsiDatabaseTable
            {
                Name = "Property",
                Rows =
                {
                    new NativeMsiDatabaseRow
                    {
                        Index = 1,
                        Columns =
                        {
                            ["Property"] = "Value"
                        }
                    }
                }
            }
        },
        Operations =
        {
            new NativeMsiDatabaseOperation
            {
                Sequence = 1,
                Operation = "InsertRow",
                Table = "Property",
                PrimaryKey = "Property_1",
                Payload =
                {
                    ["Property"] = "Value"
                }
            }
        }
    };

    await using (var stream = File.Create(databasePath))
    {
        await JsonSerializer.SerializeAsync(stream, database);
    }

    var preview = new NativePreviewViewModel();
    var service = new StudioNativePreviewService(new FakeFileDialogService { SaveNativeDatabaseFileResult = exportPath });
    var project = ProjectFactory.Create("Native App", "ACME", "1.0.0", "ACME", @"[ProgramFiles]\NativeApp", tempRoot);

    await service.LoadAsync(preview, project, planPath, databasePath);
    Assert.Equal(databasePath, preview.DatabasePath);
    Assert.Equal("Preview App 1.0.0 | 1 tables | 0 files | 0 shortcuts | 0 registry entries | 0 services | 0 IIS sites", preview.Summary);
    Assert.True(preview.Operations.Count == 1, "Database operations should be projected.");

    var exported = await service.ExportAsync(databasePath, "Preview.native-msi-database.msi");
    Assert.Equal(exportPath, exported);
    Assert.True(File.Exists(exportPath), "Exported MSI database should exist.");
}

static async Task TestPackageValidationAsync()
{
    var tempRoot = Path.Combine(Path.GetTempPath(), $"aspl-package-{Guid.NewGuid():N}");
    Directory.CreateDirectory(tempRoot);
    var payloadRoot = Path.Combine(tempRoot, "payload");
    Directory.CreateDirectory(payloadRoot);
    await File.WriteAllTextAsync(Path.Combine(payloadRoot, "app.txt"), "payload");

    var packagePath = Path.Combine(tempRoot, "sample.asplpkg");
    var engine = new AsplPackageEngine();
    var project = ProjectFactory.Create("Package App", "ACME", "4.0.0", "ACME", @"[ProgramFiles]\PackageApp", tempRoot);

    await engine.CreatePackageAsync(project, payloadRoot, packagePath);
    var validation = await engine.ValidatePackageAsync(packagePath);
    Assert.True(validation.IsValid, "Created package should validate.");

    var missing = await engine.ValidatePackageAsync(Path.Combine(tempRoot, "missing.asplpkg"));
    Assert.False(missing.IsValid, "Missing package should fail validation.");
    Assert.Contains(missing.Errors, error => error.Contains("was not found", StringComparison.OrdinalIgnoreCase));
}

static async Task TestInstalledProductLocatorAsync()
{
    var tempRoot = Path.Combine(Path.GetTempPath(), $"aspl-locator-{Guid.NewGuid():N}");
    var installFolder = Path.Combine(tempRoot, "Install");
    Directory.CreateDirectory(installFolder);

    var statePath = Path.Combine(installFolder, "asplshield.installstate.json");
    await File.WriteAllTextAsync(statePath, "{}");

    var packagePath = Path.Combine(tempRoot, "Demo.asplpkg");
    await File.WriteAllTextAsync(packagePath, "package");

    var resolvedPackage = InstalledProductLocator.ResolvePackagePath(new[] { "--package", packagePath }, tempRoot);
    var resolvedFolder = InstalledProductLocator.ResolveInstallFolder(new[] { "--install-folder", installFolder }, tempRoot);

    Assert.Equal(packagePath, resolvedPackage);
    Assert.Equal(installFolder, resolvedFolder);
}

static async Task TestUninstallerRecoveryAsync()
{
    var tempRoot = Path.Combine(Path.GetTempPath(), $"aspl-uninstall-{Guid.NewGuid():N}");
    var installFolder = Path.Combine(tempRoot, "Install");
    Directory.CreateDirectory(installFolder);

    var shortcutPath = Path.Combine(installFolder, "sample.lnk");
    await File.WriteAllTextAsync(shortcutPath, "shortcut");

    var state = new
    {
        ProductName = "Recovery App",
        ProductVersion = "1.0.0",
        Publisher = "ACME",
        InstallFolder = installFolder,
        PackagePath = Path.Combine(tempRoot, "missing.asplpkg"),
        UpdateFeedUri = (string?)null,
        ShortcutPaths = new[] { shortcutPath }
    };

    await File.WriteAllTextAsync(Path.Combine(installFolder, "asplshield.installstate.json"), JsonSerializer.Serialize(state, new JsonSerializerOptions { WriteIndented = true }));

    var service = new ASPLShield.Uninstaller.UninstallerService();
    await service.UninstallAsync(installFolder);

    Assert.False(Directory.Exists(installFolder), "Install folder should be removed even when the package is missing.");
    Assert.False(File.Exists(shortcutPath), "Shortcut should be removed during uninstall recovery.");
}

static async Task TestPrerequisiteAuthoringAsync()
{
    var properties = new PropertiesViewModel(new FakeIntegrationSettingsStore(), new FakeFileDialogService(), new FakeSelectPrerequisiteDialogService());
    var project = ProjectFactory.Create("Prereq App", "ACME", "1.0.0", "ACME", @"[ProgramFiles]\PrereqApp", Path.GetTempPath());
    properties.Bind(() => project, () => null, () => null);

    properties.PrerequisiteEditor.AddPrerequisiteCommand.Execute(null);
    Assert.Equal(1, project.Prerequisites.Count);
    Assert.True(properties.PrerequisiteEditor.HasSelection, "New prerequisite should be selected.");

    properties.PrerequisiteEditor.Name = "VC++ Runtime";
    properties.PrerequisiteEditor.TypeText = PrerequisiteType.RegistryKey.ToString();
    properties.PrerequisiteEditor.DetectionTarget = @"HKLM\Software\ASPLShield\Runtime";
    properties.PrerequisiteEditor.ExpectedValue = "1";
    properties.PrerequisiteEditor.Required = true;

    Assert.Equal("VC++ Runtime", project.Prerequisites[0].Name);
    Assert.Equal(PrerequisiteType.RegistryKey, project.Prerequisites[0].Type);
    Assert.Equal(@"HKLM\Software\ASPLShield\Runtime", project.Prerequisites[0].DetectionTarget);
    Assert.Equal("1", project.Prerequisites[0].ExpectedValue);
}

static async Task TestPrerequisiteValidationAsync()
{
    var project = ProjectFactory.Create("Invalid Prereq App", "ACME", "1.0.0", "ACME", @"[ProgramFiles]\InvalidPrereqApp", Path.GetTempPath());
    project.Prerequisites.Add(new PrerequisiteEntry
    {
        Name = string.Empty,
        Type = PrerequisiteType.RegistryKey,
        DetectionTarget = string.Empty,
        MinimumVersion = string.Empty
    });

    var validator = new ProjectValidator();
    var validation = validator.Validate(project);

    Assert.False(validation.IsValid, "Invalid prerequisite should block validation.");
    Assert.Contains(validation.Errors, error => error.Contains("Prerequisites require a name", StringComparison.OrdinalIgnoreCase));
    Assert.Contains(validation.Errors, error => error.Contains("requires a detection target", StringComparison.OrdinalIgnoreCase));
}

static async Task TestRegistryAndServiceValidationAsync()
{
    var project = ProjectFactory.Create("Validation App", "ACME", "1.0.0", "ACME", @"[ProgramFiles]\ValidationApp", Path.GetTempPath());
    project.RegistryEntries.Add(new RegistryEntry
    {
        KeyPath = string.Empty,
        Name = string.Empty,
        Value = string.Empty
    });
    project.Services.Add(new ServiceEntry
    {
        ServiceName = "DomainService",
        DisplayName = "Domain Service",
        ExecutablePath = "service.exe",
        AccountName = @"ACME\ServiceUser",
        AccountPassword = string.Empty
    });

    var validator = new ProjectValidator();
    var validation = validator.Validate(project);

    Assert.False(validation.IsValid, "Invalid registry and service entries should block validation.");
    Assert.Contains(validation.Errors, error => error.Contains("Registry entries require a key path", StringComparison.OrdinalIgnoreCase));
    Assert.Contains(validation.Errors, error => error.Contains("Registry entries require either a value name or a value", StringComparison.OrdinalIgnoreCase));
    Assert.Contains(validation.Errors, error => error.Contains("should specify a password for domain accounts", StringComparison.OrdinalIgnoreCase));
}

static async Task TestNativePlanPrerequisitesAsync()
{
    var tempRoot = Path.Combine(Path.GetTempPath(), $"aspl-native-plan-{Guid.NewGuid():N}");
    Directory.CreateDirectory(tempRoot);
    var project = ProjectFactory.Create("Native Plan App", "ACME", "1.0.0", "ACME", @"[ProgramFiles]\NativePlanApp", tempRoot);
    project.Prerequisites.Add(new PrerequisiteEntry
    {
        Name = "Runtime",
        Type = PrerequisiteType.DotNetRuntime,
        Version = "8.0.0",
        MinimumVersion = "8.0.0",
        Required = true
    });

    var scaffold = new NativeMsiAuthoringScaffold();
    var planPath = await scaffold.GeneratePlanAsync(project, tempRoot);
    var json = await File.ReadAllTextAsync(planPath);
    Assert.True(json.Contains("\"Prerequisites\"", StringComparison.OrdinalIgnoreCase), "Native plan should include prerequisites.");
    Assert.True(json.Contains("\"LaunchCondition\"", StringComparison.OrdinalIgnoreCase), "Native plan should include launch conditions.");
    Assert.True(json.Contains("\"Runtime\"", StringComparison.OrdinalIgnoreCase), "Native plan should serialize prerequisite details.");

    project.OutputFolder = tempRoot;
    var wixPath = await new WixMsiGenerator().GenerateAsync(project);
    var wix = await File.ReadAllTextAsync(wixPath);
    Assert.True(wix.Contains("LaunchCondition", StringComparison.OrdinalIgnoreCase), "WiX authoring should include launch conditions.");
}

static Task TestPrerequisiteValidationMessageAsync()
{
    var project = ProjectFactory.Create("Validation Message App", "ACME", "1.0.0", "ACME", @"[ProgramFiles]\ValidationMessageApp", Path.GetTempPath());
    project.Prerequisites.Add(new PrerequisiteEntry
    {
        Name = string.Empty,
        Type = PrerequisiteType.FileExists,
        DetectionTarget = string.Empty,
        Required = true
    });

    var properties = new PropertiesViewModel(new FakeIntegrationSettingsStore(), new FakeFileDialogService(), new FakeSelectPrerequisiteDialogService());
    properties.Bind(() => project, () => null, () => null);
    properties.PrerequisiteEditor.SelectedPrerequisite = project.Prerequisites[0];

    var message = properties.PrerequisiteEditor.ValidationMessage;
    Assert.True(message.Contains("Name is required.", StringComparison.OrdinalIgnoreCase), "Validation message should surface the missing name.");
    Assert.True(message.Contains("Detection target is required for file checks.", StringComparison.OrdinalIgnoreCase), "Validation message should surface the missing detection target.");
    Assert.True(properties.PrerequisiteEditor.HasErrors, "Invalid prerequisite should report validation errors.");
    return Task.CompletedTask;
}

static async Task TestInstallRollbackAsync()
{
    var tempRoot = Path.Combine(Path.GetTempPath(), $"aspl-rollback-{Guid.NewGuid():N}");
    Directory.CreateDirectory(tempRoot);
    var payloadRoot = Path.Combine(tempRoot, "payload");
    Directory.CreateDirectory(payloadRoot);
    await File.WriteAllTextAsync(Path.Combine(payloadRoot, "app.txt"), "payload");

    var packagePath = Path.Combine(tempRoot, "rollback.asplpkg");
    var project = ProjectFactory.Create("Rollback App", "ACME", "1.0.0", "ACME", @"[ProgramFiles]\RollbackApp", tempRoot);
    project.Services.Add(new ServiceEntry
    {
        ServiceName = "RollbackService",
        DisplayName = "Rollback Service",
        ExecutablePath = "missing-service.exe"
    });

    var packageEngine = new AsplPackageEngine();
    await packageEngine.CreatePackageAsync(project, payloadRoot, packagePath);
    var package = await packageEngine.ReadPackageAsync(packagePath);

    var installationFolder = Path.Combine(tempRoot, "Install");
    var installService = new ASPLShield.Runtime.InstallationService(packageEngine);

    var progress = new Progress<ASPLShield.Runtime.InstallationProgress>(_ => { });
    var failed = false;
    try
    {
        await installService.InstallAsync(package, installationFolder, progress);
    }
    catch
    {
        failed = true;
    }

    Assert.True(failed, "Install should fail when service deployment cannot be completed.");
    Assert.False(Directory.Exists(installationFolder), "Rollback should remove the installation folder.");
}

static async Task TestShortcutRollbackAsync()
{
    var tempRoot = Path.Combine(Path.GetTempPath(), $"aspl-shortcut-rollback-{Guid.NewGuid():N}");
    Directory.CreateDirectory(tempRoot);
    var payloadRoot = Path.Combine(tempRoot, "payload");
    Directory.CreateDirectory(payloadRoot);
    await File.WriteAllTextAsync(Path.Combine(payloadRoot, "app.txt"), "payload");

    var productName = $"Shortcut Rollback {Guid.NewGuid():N}";
    var packagePath = Path.Combine(tempRoot, "shortcuts.asplpkg");
    var project = ProjectFactory.Create(productName, "ACME", "1.0.0", "ACME", @"[ProgramFiles]\ShortcutRollbackApp", tempRoot);
    project.Shortcuts.Add(new InstallerShortcut
    {
        Name = "GoodShortcut",
        TargetPath = "app.txt",
        Location = ShortcutLocation.StartMenu
    });
    project.Shortcuts.Add(new InstallerShortcut
    {
        Name = "Bad:Shortcut",
        TargetPath = "app.txt",
        Location = ShortcutLocation.StartMenu
    });

    var packageEngine = new AsplPackageEngine();
    await packageEngine.CreatePackageAsync(project, payloadRoot, packagePath);
    var package = await packageEngine.ReadPackageAsync(packagePath);

    var installationFolder = Path.Combine(tempRoot, "Install");
    var expectedShortcutFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Programs", productName);
    var expectedShortcutPath = Path.Combine(expectedShortcutFolder, "GoodShortcut.lnk");
    var installService = new ASPLShield.Runtime.InstallationService(packageEngine);

    var progress = new Progress<ASPLShield.Runtime.InstallationProgress>(_ => { });
    var failed = false;
    try
    {
        await installService.InstallAsync(package, installationFolder, progress);
    }
    catch
    {
        failed = true;
    }
    finally
    {
        if (File.Exists(expectedShortcutPath))
        {
            File.Delete(expectedShortcutPath);
        }

        if (Directory.Exists(expectedShortcutFolder) && !Directory.EnumerateFileSystemEntries(expectedShortcutFolder).Any())
        {
            Directory.Delete(expectedShortcutFolder);
        }
    }

    Assert.True(failed, "Install should fail when a shortcut cannot be created.");
    Assert.False(Directory.Exists(installationFolder), "Rollback should remove the installation folder after a shortcut failure.");
    Assert.False(File.Exists(expectedShortcutPath), "Rollback should remove any shortcuts that were already created.");
}

static async Task TestReadOnlyCleanupAsync()
{
    var tempRoot = Path.Combine(Path.GetTempPath(), $"aspl-readonly-{Guid.NewGuid():N}");
    var installFolder = Path.Combine(tempRoot, "Install");
    Directory.CreateDirectory(installFolder);

    var state = new
    {
        ProductName = "Readonly App",
        ProductVersion = "1.0.0",
        Publisher = "ACME",
        InstallFolder = installFolder,
        PackagePath = Path.Combine(tempRoot, "missing.asplpkg"),
        UpdateFeedUri = (string?)null,
        ShortcutPaths = new[] { Path.Combine(installFolder, "readonly.lnk") }
    };

    await File.WriteAllTextAsync(Path.Combine(installFolder, "asplshield.installstate.json"), JsonSerializer.Serialize(state, new JsonSerializerOptions { WriteIndented = true }));
    var readOnlyFile = Path.Combine(installFolder, "readonly.lnk");
    await File.WriteAllTextAsync(readOnlyFile, "shortcut");
    File.SetAttributes(readOnlyFile, FileAttributes.ReadOnly);

    var service = new ASPLShield.Uninstaller.UninstallerService();
    await service.UninstallAsync(installFolder);

    Assert.False(Directory.Exists(installFolder), "Read-only artifacts should not block uninstall cleanup.");
}

static async Task TestTemplateRepositoryAsync()
{
    var tempRoot = Path.Combine(Path.GetTempPath(), $"aspl-templates-{Guid.NewGuid():N}");
    Directory.CreateDirectory(tempRoot);
    var dbPath = Path.Combine(tempRoot, "studio.db");
    var initializer = new StudioDatabaseInitializer(new TempSqliteConnectionFactory(dbPath));
    var repository = new SqliteProjectRepository(new XmlProjectSerializer(), initializer, new TempSqliteConnectionFactory(dbPath));

    await repository.InitializeAsync();

    var template = new ProjectTemplateEntry
    {
        Name = "Desktop App",
        Description = "Basic desktop installer template",
        TemplatePath = Path.Combine(tempRoot, "templates", "desktop.asplproj")
    };

    await repository.SaveTemplateAsync(template);
    Assert.True(template.Id > 0, "Saving a template should assign a database id.");

    var templates = await repository.GetTemplatesAsync();
    Assert.Equal(1, templates.Count);
    Assert.Equal("Desktop App", templates[0].Name);
    Assert.Equal(template.TemplatePath, templates[0].TemplatePath);

    template.Description = "Updated template";
    await repository.SaveTemplateAsync(template);

    templates = await repository.GetTemplatesAsync();
    Assert.Equal(1, templates.Count);
    Assert.Equal("Updated template", templates[0].Description);

    await repository.DeleteTemplateAsync(template.Id);
    templates = await repository.GetTemplatesAsync();
    Assert.Equal(0, templates.Count);
}

static async Task TestUpdateEngineAsync()
{
    var tempRoot = Path.Combine(Path.GetTempPath(), $"aspl-update-{Guid.NewGuid():N}");
    Directory.CreateDirectory(tempRoot);
    var feedPath = Path.Combine(tempRoot, "feed.json");
    await File.WriteAllTextAsync(feedPath, """
        {
          "CurrentVersion": "1.0.0",
          "LatestVersion": "1.2.0",
          "DownloadUrl": "https://example.com/downloads/setup.exe",
          "ReleaseNotes": "Bug fixes and polish."
        }
        """);

    var client = new UpdateEngineClient(new HttpClient(), new Uri(feedPath));
    var result = await client.CheckForUpdatesAsync(new Uri(feedPath));

    Assert.True(result.HasUpdate, "Update feed should report a newer version.");
    Assert.NotNull(result.Package);
    Assert.Equal("1.2.0", result.Package!.LatestVersion);
    Assert.True(result.Message?.Contains("Update available", StringComparison.OrdinalIgnoreCase) == true, "Update message should indicate availability.");
}

static async Task TestPackagePrerequisitesAsync()
{
    var tempRoot = Path.Combine(Path.GetTempPath(), $"aspl-package-prereq-{Guid.NewGuid():N}");
    Directory.CreateDirectory(tempRoot);
    var payloadRoot = Path.Combine(tempRoot, "payload");
    Directory.CreateDirectory(payloadRoot);
    await File.WriteAllTextAsync(Path.Combine(payloadRoot, "app.txt"), "payload");

    var project = ProjectFactory.Create("Package Prereq App", "ACME", "1.0.0", "ACME", @"[ProgramFiles]\PackagePrereqApp", tempRoot);
    project.Prerequisites.Add(new PrerequisiteEntry
    {
        Name = "Missing File",
        Type = PrerequisiteType.FileExists,
        DetectionTarget = Path.Combine(tempRoot, "missing.exe"),
        Required = true
    });

    var packagePath = Path.Combine(tempRoot, "prereq.asplpkg");
    var packageEngine = new AsplPackageEngine();
    await packageEngine.CreatePackageAsync(project, payloadRoot, packagePath);
    var package = await packageEngine.ReadPackageAsync(packagePath);

    Assert.Equal(1, package.Manifest.Prerequisites.Count);
    Assert.Equal("Missing File", package.Manifest.Prerequisites[0].Name);
    Assert.True(package.Manifest.Prerequisites[0].Required, "Prerequisite required flag should round-trip.");
}

static async Task TestRuntimePrerequisitesAsync()
{
    var tempRoot = Path.Combine(Path.GetTempPath(), $"aspl-runtime-prereq-{Guid.NewGuid():N}");
    Directory.CreateDirectory(tempRoot);
    var payloadRoot = Path.Combine(tempRoot, "payload");
    Directory.CreateDirectory(payloadRoot);
    await File.WriteAllTextAsync(Path.Combine(payloadRoot, "app.txt"), "payload");

    var project = ProjectFactory.Create("Runtime Prereq App", "ACME", "1.0.0", "ACME", @"[ProgramFiles]\RuntimePrereqApp", tempRoot);
    project.Prerequisites.Add(new PrerequisiteEntry
    {
        Name = "Required Runtime File",
        Type = PrerequisiteType.FileExists,
        DetectionTarget = Path.Combine(tempRoot, "does-not-exist.dll"),
        Required = true
    });

    var packagePath = Path.Combine(tempRoot, "runtime-prereq.asplpkg");
    var packageEngine = new AsplPackageEngine();
    await packageEngine.CreatePackageAsync(project, payloadRoot, packagePath);
    var package = await packageEngine.ReadPackageAsync(packagePath);

    var installFolder = Path.Combine(tempRoot, "Install");
    var installService = new ASPLShield.Runtime.InstallationService(packageEngine, new ASPLShield.ServiceInstaller.WindowsPrerequisiteChecker());
    var progress = new Progress<ASPLShield.Runtime.InstallationProgress>(_ => { });

    var failed = false;
    try
    {
        await installService.InstallAsync(package, installFolder, progress);
    }
    catch
    {
        failed = true;
    }

    Assert.True(failed, "Install should fail when a required prerequisite is missing.");
    Assert.False(Directory.Exists(installFolder), "Prerequisite failure should stop installation before creating the install folder.");
}

static async Task TestNewProjectWizardTemplatesAsync()
{
    var tempRoot = Path.Combine(Path.GetTempPath(), $"aspl-wizard-{Guid.NewGuid():N}");
    Directory.CreateDirectory(tempRoot);
    var templatePath = Path.Combine(tempRoot, "template.asplproj");
    var templateProject = ProjectFactory.Create("Wizard Template", "ACME", "2.0.0", "ACME", @"[ProgramFiles]\WizardTemplate", tempRoot);
    templateProject.OutputFolder = Path.Combine(tempRoot, "out");
    await new XmlProjectSerializer().SaveAsync(templateProject, templatePath);

    var repo = new FakeProjectRepository
    {
        LoadResult = templateProject
    };
    repo.TemplateEntries.Add(new ProjectTemplateEntry
    {
        Id = 1,
        Name = "Wizard Template",
        Description = "Template for the new project wizard",
        TemplatePath = templatePath
    });

    var wizard = new NewProjectWizardViewModel(repo);
    await wizard.LoadTemplatesAsync();
    Assert.Equal(1, wizard.Templates.Count);
    wizard.SelectedTemplate = wizard.Templates[0];
    await wizard.ApplySelectedTemplateAsync();

    Assert.Equal("Wizard Template", wizard.ProductName);
    Assert.Equal("ACME", wizard.CompanyName);
    Assert.Equal("2.0.0", wizard.Version);
    Assert.True(wizard.TemplateStatus.Contains("Applied template", StringComparison.OrdinalIgnoreCase), "Wizard should report applied template.");
}

static class Assert
{
    public static void True(bool condition, string message)
    {
        if (!condition)
        {
            throw new InvalidOperationException(message);
        }
    }

    public static void False(bool condition, string message)
        => True(!condition, message);

    public static void Equal<T>(T expected, T actual)
    {
        if (!EqualityComparer<T>.Default.Equals(expected, actual))
        {
            throw new InvalidOperationException($"Expected '{expected}', got '{actual}'.");
        }
    }

    public static void NotNull(object? value)
    {
        if (value is null)
        {
            throw new InvalidOperationException("Expected value to be non-null.");
        }
    }

    public static void Contains<T>(IEnumerable<T> values, Func<T, bool> predicate)
    {
        if (!values.Any(predicate))
        {
            throw new InvalidOperationException("Expected sequence to contain a matching element.");
        }
    }
}

sealed class FakeProjectRepository : IProjectRepository
{
    public List<(string Path, InstallerProject Project)> SavedProjects { get; } = new();

    public List<(string Path, bool Succeeded, string Message)> BuildHistory { get; } = new();

    public List<string> ObservedRecentProjects { get; } = new();

    public List<ProjectTemplateEntry> TemplateEntries { get; } = new();

    public Dictionary<string, InstallerProject> LoadedProjects { get; } = new(StringComparer.OrdinalIgnoreCase);

    public InstallerProject? LoadResult { get; set; }

    public Task InitializeAsync(CancellationToken cancellationToken = default) => Task.CompletedTask;

    public Task SaveProjectAsync(string path, InstallerProject project, CancellationToken cancellationToken = default)
    {
        SavedProjects.Add((path, project));
        return Task.CompletedTask;
    }

    public Task<InstallerProject?> LoadProjectAsync(string path, CancellationToken cancellationToken = default)
    {
        if (LoadedProjects.TryGetValue(path, out var project))
        {
            return Task.FromResult<InstallerProject?>(project);
        }

        return Task.FromResult(LoadResult);
    }

    public Task RecordBuildAsync(BuildHistoryEntry entry, CancellationToken cancellationToken = default)
    {
        BuildHistory.Add((entry.ProjectPath, entry.Succeeded, entry.Message ?? string.Empty));
        return Task.CompletedTask;
    }

    public Task<IReadOnlyList<BuildHistoryEntry>> GetBuildHistoryAsync(CancellationToken cancellationToken = default)
        => Task.FromResult<IReadOnlyList<BuildHistoryEntry>>(Array.Empty<BuildHistoryEntry>());

    public Task RecordRecentProjectAsync(string path, CancellationToken cancellationToken = default)
    {
        ObservedRecentProjects.Add(path);
        return Task.CompletedTask;
    }

    public Task<IReadOnlyList<RecentProjectEntry>> GetRecentProjectsAsync(CancellationToken cancellationToken = default)
        => Task.FromResult<IReadOnlyList<RecentProjectEntry>>(Array.Empty<RecentProjectEntry>());

    public Task SaveTemplateAsync(ProjectTemplateEntry template, CancellationToken cancellationToken = default)
        => Task.CompletedTask;

    public Task<IReadOnlyList<ProjectTemplateEntry>> GetTemplatesAsync(CancellationToken cancellationToken = default)
        => Task.FromResult<IReadOnlyList<ProjectTemplateEntry>>(TemplateEntries.ToArray());

    public Task DeleteTemplateAsync(long templateId, CancellationToken cancellationToken = default)
        => Task.CompletedTask;
}

sealed class FakeFileDialogService : IFileDialogService
{
    public string? OpenProjectFileResult { get; set; }

    public string? SaveProjectFileResult { get; set; }

    public string? SaveNativeDatabaseFileResult { get; set; }

    public string? SelectFiles() => null;

    public string? SelectFolder() => null;

    public string? SelectSingleFile(string title, string filter) => null;

    public string? SelectColor(string? currentColorHex) => null;

    public string? OpenProjectFile() => OpenProjectFileResult;

    public string? SaveProjectFile(string defaultFileName) => SaveProjectFileResult;

    public string? SaveNativeDatabaseFile(string defaultFileName) => SaveNativeDatabaseFileResult;
}

sealed class FakeNewProjectDialogService : INewProjectDialogService
{
    public InstallerProject? Result { get; set; }

    public InstallerProject? ShowDialog() => Result;
}

sealed class FakeSelectPrerequisiteDialogService : ISelectPrerequisiteDialogService
{
    public PrerequisiteSelectionResult? Result { get; set; }

    public PrerequisiteSelectionResult? ShowDialog() => Result;
}

sealed class FakeBuildEngine : IBuildEngine
{
    public BuildResult Result { get; set; } = new()
    {
        PackagePath = @"C:\Out\Sample.asplpkg",
        SetupExePath = @"C:\Out\Setup.exe"
    };

    public Task<BuildResult> BuildAsync(BuildRequest request, CancellationToken cancellationToken = default)
        => Task.FromResult(Result);
}

sealed class FakeLogMonitorService : IStudioLogMonitorService
{
    private readonly IReadOnlyList<string> _entries;

    public FakeLogMonitorService(IReadOnlyList<string> entries)
    {
        _entries = entries;
    }

    public event EventHandler? Changed
    {
        add { }
        remove { }
    }

    public string LogsDirectoryPath => Path.GetTempPath();

    public void Dispose()
    {
    }

    public IReadOnlyList<string> ReadRecentEntries(int lineCount) => _entries;

    public void Start()
    {
    }
}

sealed class FakeIisWarningService : IIisWarningService
{
    private readonly IReadOnlyList<string> _warnings;

    public FakeIisWarningService(IReadOnlyList<string> warnings)
    {
        _warnings = warnings;
    }

    public IReadOnlyList<string> GetWarnings(InstallerProject project) => _warnings;
}

sealed class FakeIntegrationSettingsStore : IIntegrationSettingsStore
{
    public Task<IntegrationSettings> LoadAsync(CancellationToken cancellationToken = default)
        => Task.FromResult(new IntegrationSettings());

    public Task SaveAsync(IntegrationSettings settings, CancellationToken cancellationToken = default)
        => Task.CompletedTask;
}

sealed class TempSqliteConnectionFactory : IStudioSqliteConnectionFactory
{
    private readonly string _databasePath;

    public TempSqliteConnectionFactory(string databasePath)
    {
        _databasePath = databasePath;
    }

    public SqliteConnection CreateConnection()
        => new($"Data Source={_databasePath}");
}
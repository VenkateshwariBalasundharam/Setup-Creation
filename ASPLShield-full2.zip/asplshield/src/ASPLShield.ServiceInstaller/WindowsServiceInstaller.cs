using ASPLShield.Common;
using ASPLShield.Core;

namespace ASPLShield.ServiceInstaller;

/// <summary>
/// Minimal Windows service deployment helper for future installer integration.
/// </summary>
public sealed class WindowsServiceInstaller : IServiceInstaller
{
    public async Task InstallAsync(ServiceEntry service, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(service);
        if (string.IsNullOrWhiteSpace(service.ServiceName))
        {
            throw new ArgumentException("Service name is required.", nameof(service));
        }

        if (!File.Exists(service.ExecutablePath))
        {
            throw new FileNotFoundException("Service executable not found.", service.ExecutablePath);
        }

        // A prior failed/rolled-back install (or a previous version of this
        // product) may have left a service of the same name registered.
        // sc.exe create fails outright if the name is already taken, so make
        // this idempotent by stopping and removing any existing service with
        // this name first. "Service does not exist" failures here are
        // expected and safely ignored.
        //
        // sc delete does not remove a service immediately — it only marks it
        // for deletion; the SCM finishes the removal once every open handle
        // to the service closes. If we proceed to create straight away, the
        // create can still race against that cleanup and fail with
        // "the specified service already exists" even though the service
        // will report as gone moments later. To avoid that, stop the
        // service (a running service can't be fully removed), issue the
        // delete, then poll until the SCM confirms it is actually gone
        // before creating the new one.
        await TryRunScAsync(new[] { "stop", service.ServiceName }, cancellationToken).ConfigureAwait(false);
        await TryRunScAsync(new[] { "delete", service.ServiceName }, cancellationToken).ConfigureAwait(false);
        await WaitForServiceRemovedAsync(service.ServiceName, cancellationToken).ConfigureAwait(false);

        // IMPORTANT: sc.exe's "binPath=" value must be a single command-line
        // token — the quoted executable path plus any arguments, all
        // together. Building that as one manually-quoted string and passing
        // it as part of a single combined "Arguments" string is fragile
        // (Windows argv quoting/escaping rules are easy to get subtly wrong,
        // and a wrong quote here causes sc.exe to fail with exit code 1639
        // and dump its usage text instead of doing anything useful).
        // ArgumentList lets .NET perform correct Win32 argument escaping for
        // each token itself.
        var arguments = new List<string>
        {
            "create",
            service.ServiceName,
            "binPath=",
            BuildBinPathValue(service),
            "DisplayName=",
            service.DisplayName,
            "start=",
            service.AutoStart
                ? (service.DelayedAutoStart ? "delayed-auto" : "auto")
                : "demand"
        };

        if (!string.IsNullOrWhiteSpace(service.AccountName))
        {
            arguments.Add("obj=");
            arguments.Add(service.AccountName);
            if (!string.IsNullOrWhiteSpace(service.AccountPassword))
            {
                arguments.Add("password=");
                arguments.Add(service.AccountPassword);
            }
        }

        if (service.Dependencies.Count > 0)
        {
            arguments.Add("depend=");
            arguments.Add(string.Join("/", service.Dependencies.Where(static dependency => !string.IsNullOrWhiteSpace(dependency)).Select(static dependency => dependency.Trim())));
        }

        await RunScAsync(arguments, cancellationToken).ConfigureAwait(false);

        if (!string.IsNullOrWhiteSpace(service.Description))
        {
            await RunScAsync(new[] { "description", service.ServiceName, service.Description }, cancellationToken).ConfigureAwait(false);
        }
    }

    public async Task UninstallAsync(string serviceName, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(serviceName))
        {
            throw new ArgumentException("Service name is required.", nameof(serviceName));
        }

        await RunScAsync(new[] { "delete", serviceName }, cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// Polls "sc query" until the service is confirmed removed (query fails
    /// with "does not exist") or a timeout elapses. Guards against the SCM's
    /// asynchronous, mark-for-delete cleanup racing against an immediate
    /// re-create.
    /// </summary>
    private static async Task WaitForServiceRemovedAsync(string serviceName, CancellationToken cancellationToken, int timeoutMilliseconds = 10_000)
    {
        var deadline = DateTime.UtcNow.AddMilliseconds(timeoutMilliseconds);
        while (DateTime.UtcNow < deadline)
        {
            var (exitCode, _, _) = await ExecuteScAsync(new[] { "query", serviceName }, cancellationToken).ConfigureAwait(false);

            // sc query exit code 1060 (ERROR_SERVICE_DOES_NOT_EXIST) means the
            // SCM has fully purged it and it is safe to create again.
            if (exitCode == 1060)
            {
                return;
            }

            await Task.Delay(250, cancellationToken).ConfigureAwait(false);
        }
    }

    private static async Task RunScAsync(IReadOnlyList<string> arguments, CancellationToken cancellationToken)
    {
        var (exitCode, standardOutput, standardError) = await ExecuteScAsync(arguments, cancellationToken).ConfigureAwait(false);
        if (exitCode != 0)
        {
            var detail = string.IsNullOrWhiteSpace(standardError) ? standardOutput : standardError;
            var displayCommand = string.Join(' ', arguments.Select(DisplayQuoteIfNeeded));
            throw new InvalidOperationException(
                $"sc.exe {arguments[0]} failed with exit code {exitCode}. Command: sc.exe {displayCommand} Output: {detail.Trim()}");
        }
    }

    /// <summary>
    /// Runs sc.exe but swallows failures — used for idempotent cleanup where a
    /// missing prior service/state is expected and should not abort install.
    /// </summary>
    private static async Task TryRunScAsync(IReadOnlyList<string> arguments, CancellationToken cancellationToken)
    {
        try
        {
            await ExecuteScAsync(arguments, cancellationToken).ConfigureAwait(false);
        }
        catch
        {
            // Best-effort only.
        }
    }

    private static async Task<(int ExitCode, string StandardOutput, string StandardError)> ExecuteScAsync(
        IReadOnlyList<string> arguments,
        CancellationToken cancellationToken)
    {
        var psi = new System.Diagnostics.ProcessStartInfo
        {
            FileName = "sc.exe",
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };

        foreach (var argument in arguments)
        {
            psi.ArgumentList.Add(argument);
        }

        using var process = System.Diagnostics.Process.Start(psi) ?? throw new InvalidOperationException("Failed to launch sc.exe.");

        var stdOutTask = process.StandardOutput.ReadToEndAsync(cancellationToken);
        var stdErrTask = process.StandardError.ReadToEndAsync(cancellationToken);

        await process.WaitForExitAsync(cancellationToken).ConfigureAwait(false);

        var stdOut = await stdOutTask.ConfigureAwait(false);
        var stdErr = await stdErrTask.ConfigureAwait(false);

        return (process.ExitCode, stdOut, stdErr);
    }

    private static string DisplayQuoteIfNeeded(string value)
        => value.Contains(' ') ? $"\"{value}\"" : value;

    /// <summary>
    /// Builds the value passed to sc.exe's "binPath=" option: the quoted
    /// executable path followed by any extra arguments, e.g.
    /// "C:\ASPLShield\bin\SamplePayload.exe" --service
    /// This entire string is passed as a single ArgumentList element, so
    /// .NET will correctly wrap/escape it as one token on the real Win32
    /// command line — no manual outer quoting needed.
    /// </summary>
    private static string BuildBinPathValue(ServiceEntry service)
    {
        var command = $"\"{service.ExecutablePath}\"";
        if (!string.IsNullOrWhiteSpace(service.Arguments))
        {
            command += $" {service.Arguments}";
        }

        return command;
    }
}
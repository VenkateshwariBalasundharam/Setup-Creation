using System.Diagnostics;
using System.Runtime.Versioning;
using System.Text;
using ASPLShield.Core;

namespace ASPLShield.ServiceInstaller;

/// <summary>
/// IIS deployment helper that drives IIS through appcmd.exe instead of loading
/// Microsoft.Web.Administration.dll in-process.
///
/// Microsoft.Web.Administration.dll is a .NET Framework-era assembly. Loading it
/// directly into a modern .NET (Core/5+) process — especially a self-contained
/// single-file publish — is fragile: it can fail to resolve its own framework-only
/// dependencies, surfacing as opaque, sometimes message-less exceptions
/// (TargetInvocationException, FileNotFoundException for a missing dependency
/// assembly, etc.) even when IIS itself is correctly installed.
///
/// appcmd.exe (%windir%\System32\inetsrv\appcmd.exe) ships with every IIS
/// installation, is a plain native executable, and requires no assembly loading
/// or bitness/runtime matching on our side. Driving it via Process is far more
/// robust and gives us real, readable error text from IIS itself.
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class WindowsIisInstaller : IIisInstaller
{
    public Task InstallAsync(IEnumerable<IisSiteEntry> sites, CancellationToken cancellationToken = default)
        => ApplySitesAsync(sites, uninstall: false, cancellationToken);

    public Task UninstallAsync(IEnumerable<IisSiteEntry> sites, CancellationToken cancellationToken = default)
        => ApplySitesAsync(sites, uninstall: true, cancellationToken);

    private static async Task ApplySitesAsync(IEnumerable<IisSiteEntry> sites, bool uninstall, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(sites);
        var materialized = sites.Where(site => site is not null).ToList();
        if (materialized.Count == 0)
        {
            return;
        }

        var appCmdPath = ResolveAppCmdPath()
            ?? throw new PlatformNotSupportedException("appcmd.exe was not found. Install IIS management tools and the Web Server role.");

        foreach (var site in materialized)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var siteName = GetEffectiveSiteName(site);
            var poolName = GetEffectivePoolName(site);

            // Remove any pre-existing site/pool with the same name so re-installs
            // and uninstalls are idempotent. "Not found" failures here are expected
            // and safely ignored. Only delete the app pool if this site actually
            // owns/recreates it (CreateApplicationPool) — a site that merely
            // references a shared or pre-existing pool (e.g. IIS's built-in
            // "DefaultAppPool") must never have that pool torn down, or the site
            // is left pointing at a pool that no longer exists.
            await TryRunAppCmdAsync(appCmdPath, $"delete site \"{siteName}\"", cancellationToken).ConfigureAwait(false);
            if (site.CreateApplicationPool && !string.IsNullOrWhiteSpace(poolName))
            {
                await TryRunAppCmdAsync(appCmdPath, $"delete apppool \"{poolName}\"", cancellationToken).ConfigureAwait(false);
            }

            if (uninstall)
            {
                continue;
            }

            if (site.CreateApplicationPool && !string.IsNullOrWhiteSpace(poolName))
            {
                await RunAppCmdAsync(appCmdPath, $"add apppool /name:\"{poolName}\"", cancellationToken).ConfigureAwait(false);
            }

            var bindings = site.Bindings.Count == 0
                ? new List<IisSiteBindingEntry> { new() { Protocol = "http", BindingInformation = "*:80:" } }
                : site.Bindings;

            var bindingsArgument = string.Join(',', bindings.Select(b => $"{b.Protocol}/{b.BindingInformation}"));

            await RunAppCmdAsync(
                appCmdPath,
                $"add site /name:\"{siteName}\" /physicalPath:\"{site.PhysicalPath}\" /bindings:{bindingsArgument}",
                cancellationToken).ConfigureAwait(false);

            if (!string.IsNullOrWhiteSpace(poolName))
            {
                await TryRunAppCmdAsync(
                    appCmdPath,
                    $"set app \"{siteName}/\" /applicationPool:\"{poolName}\"",
                    cancellationToken).ConfigureAwait(false);
            }

            if (site.StartOnInstall)
            {
                await TryRunAppCmdAsync(appCmdPath, $"start site \"{siteName}\"", cancellationToken).ConfigureAwait(false);
            }
        }
    }

    private static string? ResolveAppCmdPath()
    {
        var path = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.Windows),
            "System32",
            "inetsrv",
            "appcmd.exe");

        return File.Exists(path) ? path : null;
    }

    /// <summary>
    /// Runs appcmd and throws with the real stderr/stdout text from IIS if it fails.
    /// </summary>
    private static async Task RunAppCmdAsync(string appCmdPath, string arguments, CancellationToken cancellationToken)
    {
        var (exitCode, standardOutput, standardError) = await ExecuteAsync(appCmdPath, arguments, cancellationToken).ConfigureAwait(false);
        if (exitCode != 0)
        {
            var detail = string.IsNullOrWhiteSpace(standardError) ? standardOutput : standardError;
            throw new InvalidOperationException(
                $"appcmd {arguments} failed (exit code {exitCode}): {detail.Trim()}");
        }
    }

    /// <summary>
    /// Runs appcmd but swallows failures — used for idempotent cleanup steps
    /// (deleting a site/pool that may not exist, starting a site, assigning a
    /// pool) where we don't want a missing prior state to abort the install.
    /// </summary>
    private static async Task TryRunAppCmdAsync(string appCmdPath, string arguments, CancellationToken cancellationToken)
    {
        try
        {
            await ExecuteAsync(appCmdPath, arguments, cancellationToken).ConfigureAwait(false);
        }
        catch
        {
            // Best-effort only.
        }
    }

    private static async Task<(int ExitCode, string StandardOutput, string StandardError)> ExecuteAsync(
        string fileName,
        string arguments,
        CancellationToken cancellationToken)
    {
        var psi = new ProcessStartInfo
        {
            FileName = fileName,
            Arguments = arguments,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };

        using var process = Process.Start(psi)
            ?? throw new InvalidOperationException($"Failed to launch '{fileName}'.");

        var stdOutTask = process.StandardOutput.ReadToEndAsync(cancellationToken);
        var stdErrTask = process.StandardError.ReadToEndAsync(cancellationToken);

        await process.WaitForExitAsync(cancellationToken).ConfigureAwait(false);

        var stdOut = await stdOutTask.ConfigureAwait(false);
        var stdErr = await stdErrTask.ConfigureAwait(false);

        return (process.ExitCode, stdOut, stdErr);
    }

    private static string GetEffectiveSiteName(IisSiteEntry site)
        => string.IsNullOrWhiteSpace(site.SiteName) ? throw new InvalidOperationException("Site name is required.") : site.SiteName;

    private static string GetEffectivePoolName(IisSiteEntry site)
        => string.IsNullOrWhiteSpace(site.ApplicationPoolName) ? site.SiteName : site.ApplicationPoolName;
}
using System.Runtime.InteropServices;
using ASPLShield.Core;
using Microsoft.Win32;
using System.Runtime.Versioning;

namespace ASPLShield.ServiceInstaller;

/// <summary>
/// Evaluates common Windows prerequisite checks for the installer pipeline.
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class WindowsPrerequisiteChecker : IPrerequisiteChecker
{
    public Task<bool> IsSatisfiedAsync(PrerequisiteEntry prerequisite, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(prerequisite);

        var satisfied = prerequisite.Type switch
        {
            PrerequisiteType.FileExists => CheckFileExists(prerequisite),
            PrerequisiteType.RegistryKey => CheckRegistryKey(prerequisite),
            PrerequisiteType.OperatingSystem => CheckOperatingSystem(prerequisite),
            PrerequisiteType.DotNetRuntime => CheckDotNetRuntime(prerequisite),
            PrerequisiteType.Iis => CheckIis(),
            _ => CheckFallback(prerequisite)
        };

        return Task.FromResult(satisfied);
    }

    private static bool CheckFallback(PrerequisiteEntry prerequisite)
    {
        if (!string.IsNullOrWhiteSpace(prerequisite.DetectionTarget))
        {
            if (File.Exists(prerequisite.DetectionTarget) || Directory.Exists(prerequisite.DetectionTarget))
            {
                return true;
            }

            if (TryOpenRegistryKey(prerequisite.DetectionTarget, out _))
            {
                return true;
            }
        }

        if (Version.TryParse(prerequisite.MinimumVersion ?? prerequisite.Version, out _))
        {
            return CheckDotNetRuntime(prerequisite);
        }

        return true;
    }

    private static bool CheckFileExists(PrerequisiteEntry prerequisite)
        => !string.IsNullOrWhiteSpace(prerequisite.DetectionTarget) && File.Exists(prerequisite.DetectionTarget);

    private static bool CheckRegistryKey(PrerequisiteEntry prerequisite)
    {
        if (string.IsNullOrWhiteSpace(prerequisite.DetectionTarget))
        {
            return false;
        }

        if (!TryOpenRegistryKey(prerequisite.DetectionTarget, out var key))
        {
            return false;
        }

        using (key)
        {
            if (string.IsNullOrWhiteSpace(prerequisite.ExpectedValue))
            {
                return true;
            }

            return string.Equals(key?.GetValue(string.Empty)?.ToString(), prerequisite.ExpectedValue, StringComparison.OrdinalIgnoreCase);
        }
    }

    private static bool CheckOperatingSystem(PrerequisiteEntry prerequisite)
    {
        if (!Version.TryParse(prerequisite.MinimumVersion ?? prerequisite.Version, out var minimumVersion))
        {
            return OperatingSystem.IsWindows();
        }

        var currentVersion = Environment.OSVersion.Version;
        return currentVersion >= minimumVersion;
    }

    private static bool CheckDotNetRuntime(PrerequisiteEntry prerequisite)
    {
        if (!Version.TryParse(prerequisite.MinimumVersion ?? prerequisite.Version, out var minimumVersion))
        {
            return RuntimeInformation.FrameworkDescription.StartsWith(".NET", StringComparison.OrdinalIgnoreCase);
        }

        var currentVersion = Environment.Version;
        return currentVersion >= minimumVersion;
    }

    public static bool IsIisManagementAvailable()
{
    if (!OperatingSystem.IsWindows())
        return false;

    try
    {
        // Check IIS installation registry key
        using var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\InetStp");

        if (key == null)
            return false;

        // Check that the IIS management DLL exists
        var dllPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.Windows),
            "System32",
            "inetsrv",
            "Microsoft.Web.Administration.dll");

        return File.Exists(dllPath);
    }
    catch
    {
        return false;
    }
}
    private static bool CheckIis()
        => IsIisManagementAvailable();

    private static bool TryOpenRegistryKey(string keyPath, out RegistryKey? key)
    {
        var prefixes = new (string Prefix, RegistryHive Hive)[]
        {
            ("HKEY_CURRENT_USER\\", RegistryHive.CurrentUser),
            ("HKCU\\", RegistryHive.CurrentUser),
            ("HKEY_LOCAL_MACHINE\\", RegistryHive.LocalMachine),
            ("HKLM\\", RegistryHive.LocalMachine),
            ("HKEY_CLASSES_ROOT\\", RegistryHive.ClassesRoot),
            ("HKCR\\", RegistryHive.ClassesRoot),
            ("HKEY_USERS\\", RegistryHive.Users),
            ("HKU\\", RegistryHive.Users),
            ("HKEY_CURRENT_CONFIG\\", RegistryHive.CurrentConfig),
            ("HKCC\\", RegistryHive.CurrentConfig)
        };

        foreach (var (prefix, hive) in prefixes)
        {
            if (!keyPath.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            var subKeyPath = keyPath[prefix.Length..];
            using var baseKey = RegistryKey.OpenBaseKey(hive, RegistryView.Default);
            key = baseKey.OpenSubKey(subKeyPath, writable: false);
            return key is not null;
        }

        key = Registry.CurrentUser.OpenSubKey(keyPath, writable: false);
        return key is not null;
    }
}

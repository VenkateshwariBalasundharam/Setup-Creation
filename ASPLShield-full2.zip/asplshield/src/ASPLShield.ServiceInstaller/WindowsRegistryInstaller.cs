using System.Globalization;
using ASPLShield.Core;
using Microsoft.Win32;
using System.Runtime.Versioning;

namespace ASPLShield.ServiceInstaller;

/// <summary>
/// Writes registry values for installer authoring scenarios.
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class WindowsRegistryInstaller : IRegistryInstaller
{
    public async Task InstallAsync(IEnumerable<RegistryEntry> entries, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(entries);

        await Task.Run(() =>
        {
            foreach (var entry in entries.Where(static entry => entry is not null))
            {
                cancellationToken.ThrowIfCancellationRequested();

                if (string.IsNullOrWhiteSpace(entry.KeyPath))
                {
                    throw new ArgumentException("Registry key path is required.");
                }

                var (root, subKeyPath) = ParseKeyPath(entry.RegistryRoot, entry.KeyPath);
                using var rootKey = RegistryKey.OpenBaseKey(root, RegistryView.Default);
                using var key = rootKey.CreateSubKey(subKeyPath, writable: true)
                    ?? throw new InvalidOperationException($"Failed to create registry key '{entry.KeyPath}'.");

                var valueName = string.IsNullOrWhiteSpace(entry.Name) ? string.Empty : entry.Name;
                var value = entry.Value ?? string.Empty;
                var valueKind = ParseValueKind(entry.ValueKind);
                key.SetValue(valueName, ConvertValue(value, valueKind), valueKind);
            }
        }, cancellationToken).ConfigureAwait(false);
    }

    public async Task UninstallAsync(IEnumerable<RegistryEntry> entries, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(entries);

        await Task.Run(() =>
        {
            foreach (var entry in entries.Where(static entry => entry is not null))
            {
                cancellationToken.ThrowIfCancellationRequested();

                if (string.IsNullOrWhiteSpace(entry.KeyPath))
                {
                    continue;
                }

                var (root, subKeyPath) = ParseKeyPath(entry.RegistryRoot, entry.KeyPath);
                using var rootKey = RegistryKey.OpenBaseKey(root, RegistryView.Default);
                using var key = rootKey.OpenSubKey(subKeyPath, writable: true);
                if (key is null)
                {
                    continue;
                }

                if (!string.IsNullOrWhiteSpace(entry.Name))
                {
                    try
                    {
                        key.DeleteValue(entry.Name, throwOnMissingValue: false);
                    }
                    catch
                    {
                    }
                    continue;
                }

                rootKey.DeleteSubKeyTree(subKeyPath, throwOnMissingSubKey: false);
            }
        }, cancellationToken).ConfigureAwait(false);
    }

    private static RegistryValueKind ParseValueKind(string? valueKind)
        => Enum.TryParse(valueKind, true, out RegistryValueKind parsed) ? parsed : RegistryValueKind.String;

    private static object ConvertValue(string value, RegistryValueKind kind)
        => kind switch
        {
            RegistryValueKind.DWord => int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var intValue) ? intValue : 0,
            RegistryValueKind.QWord => long.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var longValue) ? longValue : 0L,
            RegistryValueKind.MultiString => value.Split(new[] { '\r', '\n', ';' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries),
            RegistryValueKind.Binary => Convert.FromBase64String(value),
            _ => value
        };

    private static (RegistryHive Root, string SubKeyPath) ParseKeyPath(RegistryRootKind rootKind, string keyPath)
    {
        var normalized = keyPath.Trim();
        var prefixes = new (string Prefix, RegistryHive Hive)[]
        {
            ("HKEY_CURRENT_USER\\", RegistryHive.CurrentUser),
            ("HKCU\\", RegistryHive.CurrentUser),
            ("HKEY_LOCAL_MACHINE\\", RegistryHive.LocalMachine),
            ("HKLM\\", RegistryHive.LocalMachine),
            ("HKEY_CLASSES_ROOT\\", RegistryHive.ClassesRoot),
            ("HKCR\\", RegistryHive.ClassesRoot),
            ("HKEY_USERS\\", RegistryHive.Users),
            ("HKU\\", RegistryHive.Users),
            ("HKEY_CURRENT_CONFIG\\", RegistryHive.CurrentConfig),
            ("HKCC\\", RegistryHive.CurrentConfig)
        };

        foreach (var (prefix, hive) in prefixes)
        {
            if (normalized.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
            {
                return (hive, normalized[prefix.Length..]);
            }
        }

        return (MapRoot(rootKind), normalized);
    }

    private static RegistryHive MapRoot(RegistryRootKind rootKind)
        => rootKind switch
        {
            RegistryRootKind.LocalMachine => RegistryHive.LocalMachine,
            RegistryRootKind.ClassesRoot => RegistryHive.ClassesRoot,
            RegistryRootKind.Users => RegistryHive.Users,
            RegistryRootKind.CurrentConfig => RegistryHive.CurrentConfig,
            _ => RegistryHive.CurrentUser
        };
}

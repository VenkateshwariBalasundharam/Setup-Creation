using ASPLShield.Common;
using ASPLShield.Core;
using ASPLShield.PackageEngine;
using System.Diagnostics;

namespace ASPLShield.Build;

/// <summary>
/// Builds the ASPLShield package and bootstrapper artifacts.
/// </summary>
public sealed class AsplBuildEngine : IBuildEngine
{
    private readonly IPackageEngine _packageEngine;
    private readonly ProjectValidator _validator;
    private readonly IPrerequisiteChecker _prerequisiteChecker;
    private readonly IMsiGenerator _msiGenerator;
    private readonly IMsiCompiler _msiCompiler;
    private readonly INativeMsiDatabaseWriter _nativeDatabaseWriter;
    private readonly IDigitalSigner _digitalSigner;

    public AsplBuildEngine(IPackageEngine packageEngine, ProjectValidator validator, IPrerequisiteChecker prerequisiteChecker, IMsiGenerator msiGenerator, IMsiCompiler msiCompiler, INativeMsiDatabaseWriter nativeDatabaseWriter, IDigitalSigner digitalSigner)
    {
        _packageEngine = Guard.AgainstNull(packageEngine, nameof(packageEngine));
        _validator = Guard.AgainstNull(validator, nameof(validator));
        _prerequisiteChecker = Guard.AgainstNull(prerequisiteChecker, nameof(prerequisiteChecker));
        _msiGenerator = Guard.AgainstNull(msiGenerator, nameof(msiGenerator));
        _msiCompiler = Guard.AgainstNull(msiCompiler, nameof(msiCompiler));
        _nativeDatabaseWriter = Guard.AgainstNull(nativeDatabaseWriter, nameof(nativeDatabaseWriter));
        _digitalSigner = Guard.AgainstNull(digitalSigner, nameof(digitalSigner));
    }

    public async Task<BuildResult> BuildAsync(BuildRequest request, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        NormalizeFileEntryKinds(request.Project);

        var validation = _validator.Validate(request.Project);
        if (!validation.IsValid)
        {
            throw new InvalidOperationException(string.Join(Environment.NewLine, validation.Errors));
        }

        var outputDirectory = PathUtilities.EnsureDirectory(request.OutputDirectory);
        var packagePath = Path.Combine(outputDirectory, $"{SanitizeFileName(request.Project.ProductName)}.asplpkg");
        var stagingRoot = Path.Combine(Path.GetTempPath(), $"{Guid.NewGuid():N}.asplstage");
        Directory.CreateDirectory(stagingRoot);
        var warnings = new List<string>();

        AddAssetWarnings(request.Project, warnings);

        try
        {
            StageProjectFiles(request.Project, stagingRoot);
            await _packageEngine.CreatePackageAsync(request.Project, stagingRoot, packagePath, cancellationToken).ConfigureAwait(false);
        }
        finally
        {
            if (Directory.Exists(stagingRoot))
            {
                Directory.Delete(stagingRoot, recursive: true);
            }
        }

        var setupExePath = Path.Combine(outputDirectory, request.Project.Build.SetupExecutableName);
        var uninstallExePath = Path.Combine(outputDirectory, "uninstall.exe");

        await AddPrerequisiteWarningsAsync(request.Project, warnings, cancellationToken).ConfigureAwait(false);

        if (string.IsNullOrWhiteSpace(request.SetupProjectPath))
        {
            throw new InvalidOperationException("A setup project path must be provided.");
        }

        // Publish into a subfolder of the project's own output directory instead
        // of %TEMP%. A self-extracting single-file exe sitting in a random
        // %TEMP%\<guid> folder is a classic dropper heuristic and gets quarantined
        // by antivirus software on many machines. Publishing under a location the
        // user chose avoids that trigger on every machine, not just this one.
        var publishStagingRoot = Path.Combine(outputDirectory, ".buildstaging", $"{Guid.NewGuid():N}");
        Directory.CreateDirectory(publishStagingRoot);

        try
        {
            var setupPublishPath = await PublishProjectAsync(request.SetupProjectPath, "ASPLShield.Runtime", publishStagingRoot, cancellationToken).ConfigureAwait(false);
            var setupExe = await FindPublishedExecutableAsync(setupPublishPath, "ASPLShield.Runtime", cancellationToken).ConfigureAwait(false);
            await TrySignAsync(setupExe, warnings, cancellationToken).ConfigureAwait(false);

            string? uninstallExe = null;
            if (request.Project.Build.CreateUninstaller)
            {
                if (string.IsNullOrWhiteSpace(request.UninstallerProjectPath))
                {
                    throw new InvalidOperationException("An uninstaller project path must be provided when CreateUninstaller is enabled.");
                }

                var uninstallPublishPath = await PublishProjectAsync(request.UninstallerProjectPath, "ASPLShield.Uninstaller", publishStagingRoot, cancellationToken).ConfigureAwait(false);
                uninstallExe = await FindPublishedExecutableAsync(uninstallPublishPath, "ASPLShield.Uninstaller", cancellationToken).ConfigureAwait(false);
                await TrySignAsync(uninstallExe, warnings, cancellationToken).ConfigureAwait(false);
            }

            File.Copy(setupExe, setupExePath, overwrite: true);
            if (uninstallExe is not null)
            {
                File.Copy(uninstallExe, uninstallExePath, overwrite: true);
            }
        }
        finally
        {
            if (Directory.Exists(publishStagingRoot))
            {
                try
                {
                    Directory.Delete(publishStagingRoot, recursive: true);
                }
                catch (IOException)
                {
                    // Best-effort cleanup; a locked file here shouldn't fail the build.
                }
                catch (UnauthorizedAccessException)
                {
                    // Best-effort cleanup; a locked file here shouldn't fail the build.
                }
            }
        }

        string? msiAuthoringPath;
        string? msiDatabasePath = null;
        string? msiPath = null;

        if (request.Project.Build.MsiAuthoringMode == MsiAuthoringMode.NativePreview)
        {
            var scaffold = new NativeMsiAuthoringScaffold();
            var nativePlanDirectory = Path.Combine(outputDirectory, "NativeMsi");
            msiAuthoringPath = await scaffold.GeneratePlanAsync(request.Project, nativePlanDirectory, cancellationToken).ConfigureAwait(false);
            var nativePlan = await ReadNativePlanAsync(msiAuthoringPath, cancellationToken).ConfigureAwait(false);
            msiDatabasePath = await _nativeDatabaseWriter.WriteAsync(nativePlan, nativePlanDirectory, cancellationToken).ConfigureAwait(false);
            warnings.Add("Native MSI authoring is in preview mode. WiX compilation was skipped.");
        }
        else
        {
            msiAuthoringPath = await _msiGenerator.GenerateAsync(request.Project, cancellationToken).ConfigureAwait(false);

            try
            {
                msiPath = await _msiCompiler.CompileAsync(msiAuthoringPath, request.Project, cancellationToken).ConfigureAwait(false);
                if (msiPath is null)
                {
                    warnings.Add("WiX CLI was not found. MSI compilation was skipped.");
                }
            }
            catch (Exception ex)
            {
                warnings.Add($"MSI compilation failed: {ex.Message}");
            }
        }

        if (!request.Project.Build.CreateUninstaller)
        {
            warnings.Add("CreateUninstaller is disabled. The build output will not include a standalone uninstaller.");
        }

        if (!string.IsNullOrWhiteSpace(msiPath))
        {
            await TrySignAsync(msiPath, warnings, cancellationToken).ConfigureAwait(false);
        }

        return new BuildResult
        {
            PackagePath = packagePath,
            SetupExePath = setupExePath,
            UninstallExePath = request.Project.Build.CreateUninstaller ? uninstallExePath : null,
            MsiAuthoringPath = msiAuthoringPath,
            MsiDatabasePath = msiDatabasePath,
            MsiPath = msiPath,
            Warnings = warnings
        };
    }

    private static void AddAssetWarnings(InstallerProject project, List<string> warnings)
    {
        if (project.Build.IncludeIcon && string.IsNullOrWhiteSpace(project.Build.IconPath))
        {
            warnings.Add("Package icon is enabled but no icon path was configured.");
        }
        else if (project.Build.IncludeIcon && !File.Exists(project.Build.IconPath))
        {
            warnings.Add($"Package icon file was not found: {project.Build.IconPath}");
        }

        if (project.Build.IncludeLicense && string.IsNullOrWhiteSpace(project.Build.LicensePath))
        {
            warnings.Add("Package license is enabled but no license path was configured.");
        }
        else if (project.Build.IncludeLicense && !File.Exists(project.Build.LicensePath))
        {
            warnings.Add($"Package license file was not found: {project.Build.LicensePath}");
        }
    }

    private async Task TrySignAsync(string path, List<string> warnings, CancellationToken cancellationToken)
    {
        try
        {
            await _digitalSigner.SignAsync(path, cancellationToken).ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            warnings.Add($"Signing skipped for '{Path.GetFileName(path)}': {ex.Message}");
        }
    }

    private static async Task<NativeMsiAuthoringPlan> ReadNativePlanAsync(string planPath, CancellationToken cancellationToken)
    {
        await using var stream = File.OpenRead(planPath);
        return await System.Text.Json.JsonSerializer.DeserializeAsync<NativeMsiAuthoringPlan>(stream, cancellationToken: cancellationToken).ConfigureAwait(false)
            ?? throw new InvalidDataException("Native MSI authoring plan could not be read.");
    }

    private static string SanitizeFileName(string value)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var chars = value.Select(ch => invalid.Contains(ch) ? '_' : ch).ToArray();
        var sanitized = new string(chars).Trim();
        return string.IsNullOrWhiteSpace(sanitized) ? "ASPLShield" : sanitized;
    }

    /// <summary>
    /// The "Folder" flag on a file entry can be wrong (for example ticked by mistake on a plain file).
    /// The disk is the source of truth, so correct the flag before validating and staging.
    /// </summary>
    private static void NormalizeFileEntryKinds(InstallerProject project)
    {
        foreach (var file in project.Files)
        {
            if (string.IsNullOrWhiteSpace(file.SourcePath))
            {
                continue;
            }

            if (File.Exists(file.SourcePath))
            {
                file.IsFolder = false;
            }
            else if (Directory.Exists(file.SourcePath))
            {
                file.IsFolder = true;
            }
        }
    }

    private static void StageProjectFiles(InstallerProject project, string stagingRoot)
    {
        foreach (var file in project.Files)
        {
            if (string.IsNullOrWhiteSpace(file.SourcePath))
            {
                continue;
            }

            if (file.IsFolder)
            {
                var destination = Path.Combine(stagingRoot, file.DestinationPath);
                CopyDirectory(file.SourcePath, destination);
                continue;
            }

            var destinationFile = Path.Combine(stagingRoot, file.DestinationPath);
            Directory.CreateDirectory(Path.GetDirectoryName(destinationFile) ?? stagingRoot);
            File.Copy(file.SourcePath, destinationFile, overwrite: true);
        }
    }

    private static void CopyDirectory(string sourceDirectory, string destinationDirectory)
    {
        Directory.CreateDirectory(destinationDirectory);
        foreach (var directory in Directory.GetDirectories(sourceDirectory, "*", SearchOption.AllDirectories))
        {
            var relative = Path.GetRelativePath(sourceDirectory, directory);
            Directory.CreateDirectory(Path.Combine(destinationDirectory, relative));
        }

        foreach (var file in Directory.GetFiles(sourceDirectory, "*", SearchOption.AllDirectories))
        {
            var relative = Path.GetRelativePath(sourceDirectory, file);
            var destination = Path.Combine(destinationDirectory, relative);
            Directory.CreateDirectory(Path.GetDirectoryName(destination) ?? destinationDirectory);
            File.Copy(file, destination, overwrite: true);
        }
    }

    private static async Task<string> PublishProjectAsync(string projectPath, string projectName, string publishStagingRoot, CancellationToken cancellationToken)
    {
        if (!File.Exists(projectPath))
        {
            throw new FileNotFoundException("Project file not found.", projectPath);
        }

        var publishRoot = Path.Combine(publishStagingRoot, projectName.ToLowerInvariant());
        Directory.CreateDirectory(publishRoot);

        var psi = new ProcessStartInfo
        {
            FileName = "dotnet",
            Arguments = $"publish \"{projectPath}\" -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:PublishTrimmed=false -o \"{publishRoot}\"",
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };

        using var process = Process.Start(psi) ?? throw new InvalidOperationException("Failed to launch dotnet publish.");
        var outputTask = process.StandardOutput.ReadToEndAsync(cancellationToken);
        var errorTask = process.StandardError.ReadToEndAsync(cancellationToken);
        await process.WaitForExitAsync(cancellationToken).ConfigureAwait(false);
        var output = await outputTask.ConfigureAwait(false);
        var error = await errorTask.ConfigureAwait(false);

        if (process.ExitCode != 0)
        {
            throw new InvalidOperationException($"dotnet publish failed for project '{projectPath}'.{Environment.NewLine}{output}{Environment.NewLine}{error}");
        }

        return publishRoot;
    }

    private async Task AddPrerequisiteWarningsAsync(InstallerProject project, List<string> warnings, CancellationToken cancellationToken)
    {
        foreach (var prerequisite in project.Prerequisites)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var satisfied = await _prerequisiteChecker.IsSatisfiedAsync(prerequisite, cancellationToken).ConfigureAwait(false);
            if (!satisfied)
            {
                var prefix = prerequisite.Required ? "Required prerequisite missing" : "Optional prerequisite missing";
                warnings.Add($"{prefix}: {prerequisite.Name}");
            }
        }
    }

    private static async Task<string> FindPublishedExecutableAsync(string publishRoot, string projectName, CancellationToken cancellationToken)
    {
        // A freshly-published self-contained single-file .exe can be briefly
        // locked or quarantined by antivirus real-time scanning right after
        // dotnet publish writes it. Retry for a few seconds before giving up
        // instead of failing on the first missed check.
        for (var attempt = 0; attempt < 10; attempt++)
        {
            var match = Directory.GetFiles(publishRoot, "*.exe", SearchOption.TopDirectoryOnly)
                .FirstOrDefault(file => Path.GetFileNameWithoutExtension(file).Contains(projectName, StringComparison.OrdinalIgnoreCase))
                ?? Directory.GetFiles(publishRoot, "*.exe", SearchOption.TopDirectoryOnly).FirstOrDefault();

            if (match is not null && File.Exists(match))
            {
                return match;
            }

            await Task.Delay(500, cancellationToken).ConfigureAwait(false);
        }

        throw new FileNotFoundException(
            $"Published executable for '{projectName}' was not found in '{publishRoot}'. " +
            "If antivirus software is installed, add an exclusion for the Temp folder — " +
            "real-time protection can quarantine freshly published self-contained executables.",
            publishRoot);
    }
}

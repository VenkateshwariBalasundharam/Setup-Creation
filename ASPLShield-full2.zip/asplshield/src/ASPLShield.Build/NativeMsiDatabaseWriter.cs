using System.Text.Json;
using System.Runtime.Versioning;
using ASPLShield.Common;
using ASPLShield.Core;

namespace ASPLShield.Build;

/// <summary>
/// Writes a native MSI database preview through the Windows Installer API and keeps a JSON sidecar for Studio previewing.
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class NativeMsiDatabaseWriter : INativeMsiDatabaseWriter
{
    public async Task<string> WriteAsync(NativeMsiAuthoringPlan plan, string outputDirectory, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(plan);

        var directory = PathUtilities.EnsureDirectory(outputDirectory);
        var baseName = SanitizeFileName(plan.ProductName);
        var databasePath = Path.Combine(directory, $"{baseName}.native-msi-database.msi");
        var previewPath = GetPreviewPath(databasePath);

        var previewDatabase = BuildPreviewDatabase(plan);
        await WriteJsonPreviewAsync(previewPath, previewDatabase, cancellationToken).ConfigureAwait(false);
        try
        {
            CreateMsiDatabase(databasePath, plan, previewDatabase);
            return databasePath;
        }
        catch
        {
            if (File.Exists(databasePath))
            {
                File.Delete(databasePath);
            }

            var fallbackPath = Path.Combine(directory, $"{baseName}.native-msi-database.json");
            await WriteJsonPreviewAsync(fallbackPath, previewDatabase, cancellationToken).ConfigureAwait(false);
            return fallbackPath;
        }
    }

    private static NativeMsiDatabase BuildPreviewDatabase(NativeMsiAuthoringPlan plan)
    {
        return new NativeMsiDatabase
        {
            ProductName = plan.ProductName,
            Version = plan.Version,
            Publisher = plan.Publisher,
            InstallFolder = plan.InstallFolder,
            ProductCode = plan.ProductCode,
            UpgradeCode = plan.UpgradeCode,
            PackageCode = plan.PackageCode,
            Tables = plan.Tables.Select(table => new NativeMsiDatabaseTable
            {
                Name = table.Name,
                Rows = table.Rows.Select((row, index) => new NativeMsiDatabaseRow
                {
                    Index = index + 1,
                    Columns = new Dictionary<string, string>(row.Columns, StringComparer.OrdinalIgnoreCase)
                }).ToList()
            }).ToList(),
            Operations = BuildOperations(plan)
        };
    }

    private static async Task WriteJsonPreviewAsync(string previewPath, NativeMsiDatabase database, CancellationToken cancellationToken)
    {
        var json = JsonSerializer.Serialize(database, new JsonSerializerOptions { WriteIndented = true });
        await File.WriteAllTextAsync(previewPath, json, cancellationToken).ConfigureAwait(false);
    }

    private static void CreateMsiDatabase(string databasePath, NativeMsiAuthoringPlan plan, NativeMsiDatabase database)
    {
        if (File.Exists(databasePath))
        {
            File.Delete(databasePath);
        }

        var status = NativeMsiInterop.MsiOpenDatabaseW(databasePath, NativeMsiInterop.MsiCreatePersist, out var databaseHandle);
        ThrowOnError(status, "create the MSI database");

        try
        {
            EnsureDatabaseSchema(databaseHandle);
            WriteMetadata(databaseHandle, database);
            WriteCoreAuthoringTables(databaseHandle, plan);
            WriteTables(databaseHandle, database);
            WriteTableRows(databaseHandle, database);
            WriteOperations(databaseHandle, database);
            WriteSummaryInformation(databaseHandle, database);

            status = NativeMsiInterop.MsiDatabaseCommit(databaseHandle);
            ThrowOnError(status, "commit the MSI database");
        }
        finally
        {
            NativeMsiInterop.MsiCloseHandle(databaseHandle);
        }
    }

    private static void EnsureDatabaseSchema(IntPtr databaseHandle)
    {
        ExecuteSql(databaseHandle, "CREATE TABLE Property (Property CHAR(72) NOT NULL PRIMARY KEY, Value LONGCHAR)");
        ExecuteSql(databaseHandle, "CREATE TABLE Directory (Directory CHAR(72) NOT NULL PRIMARY KEY, Directory_Parent CHAR(72), DefaultDir CHAR(255))");
        ExecuteSql(databaseHandle, "CREATE TABLE Feature (Feature CHAR(72) NOT NULL PRIMARY KEY, Feature_Parent CHAR(72), Title CHAR(255), Description LONGCHAR, Display SHORT, Level SHORT, Directory_ CHAR(72), Attributes SHORT)");
        ExecuteSql(databaseHandle, "CREATE TABLE FeatureComponents (Feature_ CHAR(72) NOT NULL, Component_ CHAR(72) NOT NULL, PRIMARY KEY (Feature_, Component_))");
        ExecuteSql(databaseHandle, "CREATE TABLE Upgrade (UpgradeCode CHAR(72) NOT NULL PRIMARY KEY, VersionMin CHAR(72), VersionMax CHAR(72), Language CHAR(20), Attributes SHORT, Remove LONGCHAR, ActionProperty CHAR(72))");
        ExecuteSql(databaseHandle, "CREATE TABLE Component (Component CHAR(72) NOT NULL PRIMARY KEY, ComponentId CHAR(38), Directory_ CHAR(72), Attributes SHORT, Condition LONGCHAR, KeyPath CHAR(72))");
        ExecuteSql(databaseHandle, "CREATE TABLE File (File CHAR(72) NOT NULL PRIMARY KEY, Component_ CHAR(72), FileName CHAR(255), FileSize LONG, Version CHAR(72), Language CHAR(20), Attributes SHORT, Sequence INTEGER)");
        ExecuteSql(databaseHandle, "CREATE TABLE Shortcut (Shortcut CHAR(72) NOT NULL PRIMARY KEY, Directory_ CHAR(72), Name CHAR(255), Component_ CHAR(72), Target CHAR(72), Arguments LONGCHAR, Description LONGCHAR, Hotkey SHORT, Icon_ CHAR(72), IconIndex SHORT, ShowCmd SHORT, WkDir CHAR(72))");
        ExecuteSql(databaseHandle, "CREATE TABLE Registry (Registry CHAR(72) NOT NULL PRIMARY KEY, Root CHAR(72), Key LONGCHAR, Name CHAR(255), Value LONGCHAR, Component_ CHAR(72))");
        ExecuteSql(databaseHandle, "CREATE TABLE ServiceInstall (Name CHAR(72) NOT NULL PRIMARY KEY, DisplayName LONGCHAR, ServiceType INTEGER, StartType INTEGER, ErrorControl INTEGER, LoadOrderGroup LONGCHAR, Dependencies LONGCHAR, StartName LONGCHAR, Password LONGCHAR, Arguments LONGCHAR, Description LONGCHAR, Vital SHORT, Account LONGCHAR, Component_ CHAR(72))");
        ExecuteSql(databaseHandle, "CREATE TABLE ServiceControl (Name CHAR(72) NOT NULL PRIMARY KEY, Event INTEGER, Arguments LONGCHAR, Wait SHORT, Component_ CHAR(72))");
        ExecuteSql(databaseHandle, "CREATE TABLE ServiceConfig (ServiceConfig CHAR(72) NOT NULL PRIMARY KEY, ServiceName LONGCHAR, DisplayName LONGCHAR, AutoStart SHORT, DelayedAutoStart SHORT, AccountName LONGCHAR, Description LONGCHAR)");
        ExecuteSql(databaseHandle, "CREATE TABLE ServiceDependency (ServiceDependency CHAR(72) NOT NULL PRIMARY KEY, ServiceName LONGCHAR, Dependency LONGCHAR, Position INTEGER)");
        ExecuteSql(databaseHandle, "CREATE TABLE NativeIisSite (Site CHAR(72) NOT NULL PRIMARY KEY, SiteName LONGCHAR, PhysicalPath LONGCHAR, ApplicationPoolName LONGCHAR, CreateApplicationPool SHORT, StartOnInstall SHORT)");
        ExecuteSql(databaseHandle, "CREATE TABLE NativeIisApplicationPool (ApplicationPool CHAR(72) NOT NULL PRIMARY KEY, SiteName LONGCHAR, ApplicationPoolName LONGCHAR, CreateApplicationPool SHORT, StartOnInstall SHORT)");
        ExecuteSql(databaseHandle, "CREATE TABLE NativeIisBinding (Binding CHAR(72) NOT NULL PRIMARY KEY, SiteName LONGCHAR, Protocol LONGCHAR, BindingInformation LONGCHAR, Position INTEGER)");
        ExecuteSql(databaseHandle, "CREATE TABLE LaunchCondition (Condition LONGCHAR NOT NULL PRIMARY KEY, Description LONGCHAR)");
        ExecuteSql(databaseHandle, "CREATE TABLE ASPLProperty (PropertyKey CHAR(64) NOT NULL PRIMARY KEY, PropertyValue LONGCHAR)");
        ExecuteSql(databaseHandle, "CREATE TABLE ASPLTableMeta (TableName CHAR(128) NOT NULL PRIMARY KEY, RowCount INTEGER, Preview LONGCHAR)");
        ExecuteSql(databaseHandle, "CREATE TABLE ASPLTableRow (RowKey CHAR(200) NOT NULL PRIMARY KEY, TableName CHAR(128), RowIndex INTEGER, ColumnsJson LONGCHAR)");
        ExecuteSql(databaseHandle, "CREATE TABLE ASPLOperation (Sequence INTEGER NOT NULL PRIMARY KEY, Operation CHAR(64), TableName CHAR(128), PrimaryKey CHAR(255), PayloadJson LONGCHAR)");
    }

    private static void WriteMetadata(IntPtr databaseHandle, NativeMsiDatabase database)
    {
        var metadata = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            ["ProductName"] = database.ProductName,
            ["Version"] = database.Version,
            ["Publisher"] = database.Publisher,
            ["InstallFolder"] = database.InstallFolder,
            ["ProductCode"] = database.ProductCode,
            ["UpgradeCode"] = database.UpgradeCode,
            ["PackageCode"] = database.PackageCode,
            ["TableCount"] = database.Tables.Count.ToString(),
            ["OperationCount"] = database.Operations.Count.ToString()
        };

        foreach (var pair in metadata)
        {
            ExecuteSql(databaseHandle, $"INSERT INTO Property (Property, Value) VALUES ({SqlLiteral(pair.Key)}, {SqlLiteral(pair.Value)})");
            ExecuteSql(databaseHandle, $"INSERT INTO ASPLProperty (PropertyKey, PropertyValue) VALUES ({SqlLiteral(pair.Key)}, {SqlLiteral(pair.Value)})");
        }
    }

    private static void WriteCoreAuthoringTables(IntPtr databaseHandle, NativeMsiAuthoringPlan plan)
    {
        var directoryName = SanitizeFolderName(plan.ProductName);
        var fileComponentMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        ExecuteSql(databaseHandle, $"INSERT INTO Directory (Directory, Directory_Parent, DefaultDir) VALUES ('TARGETDIR', NULL, 'SourceDir')");
        ExecuteSql(databaseHandle, $"INSERT INTO Directory (Directory, Directory_Parent, DefaultDir) VALUES ('ProgramFilesFolder', 'TARGETDIR', 'PFiles')");
        ExecuteSql(databaseHandle, $"INSERT INTO Directory (Directory, Directory_Parent, DefaultDir) VALUES ('INSTALLFOLDER', 'ProgramFilesFolder', {SqlLiteral(directoryName)})");
        ExecuteSql(databaseHandle, $"INSERT INTO Directory (Directory, Directory_Parent, DefaultDir) VALUES ('DesktopFolder', 'TARGETDIR', 'DesktopFolder')");
        ExecuteSql(databaseHandle, $"INSERT INTO Directory (Directory, Directory_Parent, DefaultDir) VALUES ('ProgramMenuFolder', 'TARGETDIR', 'ProgramMenuFolder')");

        ExecuteSql(databaseHandle, $"INSERT INTO Feature (Feature, Feature_Parent, Title, Description, Display, Level, Directory_, Attributes) VALUES ('MainFeature', NULL, {SqlLiteral(plan.ProductName)}, {SqlLiteral($"{plan.ProductName} core application feature")}, 1, 1, 'INSTALLFOLDER', 0)");
        ExecuteSql(databaseHandle, $"INSERT INTO Upgrade (UpgradeCode, VersionMin, VersionMax, Language, Attributes, Remove, ActionProperty) VALUES ({SqlLiteral(plan.UpgradeCode)}, {SqlLiteral(plan.UpgradeVersionMin)}, {SqlLiteral(plan.UpgradeVersionMax)}, '', 0, {SqlLiteral(plan.ProductName)}, {SqlLiteral(plan.UpgradeActionProperty)})");

        foreach (var file in plan.Files.Select((value, index) => (value, index)))
        {
            var componentId = $"cmp_file_{file.index}";
            var fileId = $"fil_{file.index}";
            var destinationName = Path.GetFileName(string.IsNullOrWhiteSpace(file.value.DestinationPath) ? file.value.DisplayName : file.value.DestinationPath);
            var fileSize = file.value.SizeBytes > 0 ? file.value.SizeBytes : 0;

            ExecuteSql(databaseHandle, $"INSERT INTO Component (Component, ComponentId, Directory_, Attributes, Condition, KeyPath) VALUES ({SqlLiteral(componentId)}, {SqlLiteral(Guid.NewGuid().ToString("D"))}, 'INSTALLFOLDER', 0, NULL, {SqlLiteral(fileId)})");
            ExecuteSql(databaseHandle, $"INSERT INTO FeatureComponents (Feature_, Component_) VALUES ('MainFeature', {SqlLiteral(componentId)})");
            ExecuteSql(databaseHandle, $"INSERT INTO File (File, Component_, FileName, FileSize, Version, Language, Attributes, Sequence) VALUES ({SqlLiteral(fileId)}, {SqlLiteral(componentId)}, {SqlLiteral(destinationName)}, {fileSize}, '', '', 0, {file.index + 1})");
            fileComponentMap[file.value.DestinationPath] = componentId;
        }

        foreach (var shortcut in plan.Shortcuts.Select((value, index) => (value, index)))
        {
            var componentId = $"cmp_shortcut_{shortcut.index}";
            var shortcutId = $"shortcut_{shortcut.index}";
            var targetComponent = ResolveShortcutComponent(plan.Files, fileComponentMap, shortcut.value.TargetPath) ?? componentId;
            var directoryNameForShortcut = shortcut.value.Location.Equals("Desktop", StringComparison.OrdinalIgnoreCase) ? "DesktopFolder" : "ProgramMenuFolder";

            ExecuteSql(databaseHandle, $"INSERT INTO Component (Component, ComponentId, Directory_, Attributes, Condition, KeyPath) VALUES ({SqlLiteral(componentId)}, {SqlLiteral(Guid.NewGuid().ToString("D"))}, 'INSTALLFOLDER', 0, NULL, {SqlLiteral(shortcutId)})");
            ExecuteSql(databaseHandle, $"INSERT INTO FeatureComponents (Feature_, Component_) VALUES ('MainFeature', {SqlLiteral(componentId)})");
            ExecuteSql(databaseHandle, $"INSERT INTO Shortcut (Shortcut, Directory_, Name, Component_, Target, Arguments, Description, Hotkey, Icon_, IconIndex, ShowCmd, WkDir) VALUES ({SqlLiteral(shortcutId)}, {SqlLiteral(directoryNameForShortcut)}, {SqlLiteral(shortcut.value.Name)}, {SqlLiteral(componentId)}, {SqlLiteral(ResolveTargetFileName(shortcut.value.TargetPath))}, {SqlLiteral(shortcut.value.Arguments)}, {SqlLiteral(shortcut.value.Name)}, 0, NULL, 0, 1, {SqlLiteral(ResolveWorkingDirectory(shortcut.value.WorkingDirectory, plan.InstallFolder))})");
        }

        foreach (var entry in plan.RegistryEntries.Select((value, index) => (value, index)))
        {
            var componentId = $"cmp_registry_{entry.index}";
            var registryId = $"reg_{entry.index}";
            ExecuteSql(databaseHandle, $"INSERT INTO Component (Component, ComponentId, Directory_, Attributes, Condition, KeyPath) VALUES ({SqlLiteral(componentId)}, {SqlLiteral(Guid.NewGuid().ToString("D"))}, 'INSTALLFOLDER', 0, NULL, {SqlLiteral(registryId)})");
            ExecuteSql(databaseHandle, $"INSERT INTO FeatureComponents (Feature_, Component_) VALUES ('MainFeature', {SqlLiteral(componentId)})");
            ExecuteSql(databaseHandle, $"INSERT INTO Registry (Registry, Root, Key, Name, Value, Component_) VALUES ({SqlLiteral(registryId)}, {SqlLiteral(entry.value.RegistryRoot.ToString())}, {SqlLiteral(entry.value.KeyPath)}, {SqlLiteral(entry.value.Name)}, {SqlLiteral(entry.value.Value)}, {SqlLiteral(componentId)})");
        }

        foreach (var service in plan.Services.Select((value, index) => (value, index)))
        {
            var componentId = $"cmp_service_{service.index}";
            var serviceId = $"svc_{service.index}";
            var dependencies = string.Join(";", service.value.Dependencies.Where(static dependency => !string.IsNullOrWhiteSpace(dependency)));
            ExecuteSql(databaseHandle, $"INSERT INTO Component (Component, ComponentId, Directory_, Attributes, Condition, KeyPath) VALUES ({SqlLiteral(componentId)}, {SqlLiteral(Guid.NewGuid().ToString("D"))}, 'INSTALLFOLDER', 0, NULL, {SqlLiteral(serviceId)})");
            ExecuteSql(databaseHandle, $"INSERT INTO FeatureComponents (Feature_, Component_) VALUES ('MainFeature', {SqlLiteral(componentId)})");
            ExecuteSql(databaseHandle, $"INSERT INTO ServiceInstall (Name, DisplayName, ServiceType, StartType, ErrorControl, LoadOrderGroup, Dependencies, StartName, Password, Arguments, Description, Vital, Account, Component_) VALUES ({SqlLiteral(serviceId)}, {SqlLiteral(service.value.DisplayName)}, 16, {(service.value.AutoStart ? 2 : 3)}, 1, '', {SqlLiteral(dependencies)}, {SqlLiteral(service.value.AccountName ?? string.Empty)}, '', {SqlLiteral(service.value.Arguments ?? string.Empty)}, {SqlLiteral(service.value.Description ?? string.Empty)}, 1, {SqlLiteral(service.value.AccountName ?? string.Empty)}, {SqlLiteral(componentId)})");
            ExecuteSql(databaseHandle, $"INSERT INTO ServiceControl (Name, Event, Arguments, Wait, Component_) VALUES ({SqlLiteral(serviceId)}, 1, '', 1, {SqlLiteral(componentId)})");
            ExecuteSql(databaseHandle, $"INSERT INTO ServiceControl (Name, Event, Arguments, Wait, Component_) VALUES ({SqlLiteral(serviceId)}, 3, '', 1, {SqlLiteral(componentId)})");
            ExecuteSql(databaseHandle, $"INSERT INTO ServiceConfig (ServiceConfig, ServiceName, DisplayName, AutoStart, DelayedAutoStart, AccountName, Description) VALUES ({SqlLiteral($"svcconfig_{service.index}")}, {SqlLiteral(service.value.ServiceName)}, {SqlLiteral(service.value.DisplayName)}, {(service.value.AutoStart ? 1 : 0)}, {(service.value.DelayedAutoStart ? 1 : 0)}, {SqlLiteral(service.value.AccountName ?? string.Empty)}, {SqlLiteral(service.value.Description ?? string.Empty)})");

            for (var dependencyIndex = 0; dependencyIndex < service.value.Dependencies.Count; dependencyIndex++)
            {
                var dependency = service.value.Dependencies[dependencyIndex];
                if (string.IsNullOrWhiteSpace(dependency))
                {
                    continue;
                }

                ExecuteSql(databaseHandle, $"INSERT INTO ServiceDependency (ServiceDependency, ServiceName, Dependency, Position) VALUES ({SqlLiteral($"svcdep_{service.index}_{dependencyIndex}")}, {SqlLiteral(service.value.ServiceName)}, {SqlLiteral(dependency)}, {dependencyIndex})");
            }
        }

        foreach (var site in plan.IisSites.Select((value, index) => (value, index)))
        {
            var siteComponent = $"cmp_iis_{site.index}";
            ExecuteSql(databaseHandle, $"INSERT INTO Component (Component, ComponentId, Directory_, Attributes, Condition, KeyPath) VALUES ({SqlLiteral(siteComponent)}, {SqlLiteral(Guid.NewGuid().ToString("D"))}, 'INSTALLFOLDER', 0, NULL, {SqlLiteral(site.value.SiteName)})");
            ExecuteSql(databaseHandle, $"INSERT INTO FeatureComponents (Feature_, Component_) VALUES ('MainFeature', {SqlLiteral(siteComponent)})");
            ExecuteSql(databaseHandle, $"INSERT INTO NativeIisSite (Site, SiteName, PhysicalPath, ApplicationPoolName, CreateApplicationPool, StartOnInstall) VALUES ({SqlLiteral($"iis_{site.index}")}, {SqlLiteral(site.value.SiteName)}, {SqlLiteral(site.value.PhysicalPath)}, {SqlLiteral(site.value.ApplicationPoolName)}, {(site.value.CreateApplicationPool ? 1 : 0)}, {(site.value.StartOnInstall ? 1 : 0)})");
            ExecuteSql(databaseHandle, $"INSERT INTO NativeIisApplicationPool (ApplicationPool, SiteName, ApplicationPoolName, CreateApplicationPool, StartOnInstall) VALUES ({SqlLiteral($"iispool_{site.index}")}, {SqlLiteral(site.value.SiteName)}, {SqlLiteral(site.value.ApplicationPoolName)}, {(site.value.CreateApplicationPool ? 1 : 0)}, {(site.value.StartOnInstall ? 1 : 0)})");

            for (var bindingIndex = 0; bindingIndex < site.value.Bindings.Count; bindingIndex++)
            {
                var binding = site.value.Bindings[bindingIndex];
                ExecuteSql(databaseHandle, $"INSERT INTO NativeIisBinding (Binding, SiteName, Protocol, BindingInformation, Position) VALUES ({SqlLiteral($"iisbind_{site.index}_{bindingIndex}")}, {SqlLiteral(site.value.SiteName)}, {SqlLiteral(binding.Protocol)}, {SqlLiteral(binding.BindingInformation)}, {bindingIndex})");
            }
        }

        foreach (var prerequisite in plan.Prerequisites.Select((value, index) => (value, index)))
        {
            var condition = BuildLaunchConditionExpression(prerequisite.value);
            if (string.IsNullOrWhiteSpace(condition))
            {
                continue;
            }

            ExecuteSql(databaseHandle, $"INSERT INTO LaunchCondition (Condition, Description) VALUES ({SqlLiteral(condition)}, {SqlLiteral(BuildLaunchConditionDescription(prerequisite.value))})");
        }
    }

    private static void WriteTables(IntPtr databaseHandle, NativeMsiDatabase database)
    {
        foreach (var table in database.Tables)
        {
            var preview = table.Rows.Count == 0
                ? "No rows"
                : string.Join(" | ", table.Rows.First().Columns.Take(3).Select(pair => $"{pair.Key}={pair.Value}"));

            ExecuteSql(databaseHandle, $"INSERT INTO ASPLTableMeta (TableName, RowCount, Preview) VALUES ({SqlLiteral(table.Name)}, {table.Rows.Count}, {SqlLiteral(preview)})");
        }
    }

    private static void WriteTableRows(IntPtr databaseHandle, NativeMsiDatabase database)
    {
        foreach (var table in database.Tables)
        {
            foreach (var row in table.Rows)
            {
                var columnsJson = JsonSerializer.Serialize(row.Columns);
                var rowKey = $"{table.Name}:{row.Index}";
                ExecuteSql(databaseHandle, $"INSERT INTO ASPLTableRow (RowKey, TableName, RowIndex, ColumnsJson) VALUES ({SqlLiteral(rowKey)}, {SqlLiteral(table.Name)}, {row.Index}, {SqlLiteral(columnsJson)})");
            }
        }
    }

    private static void WriteOperations(IntPtr databaseHandle, NativeMsiDatabase database)
    {
        foreach (var operation in database.Operations)
        {
            var payloadJson = JsonSerializer.Serialize(operation.Payload);
            ExecuteSql(databaseHandle,
                $"INSERT INTO ASPLOperation (Sequence, Operation, TableName, PrimaryKey, PayloadJson) VALUES ({operation.Sequence}, {SqlLiteral(operation.Operation)}, {SqlLiteral(operation.Table)}, {SqlLiteral(operation.PrimaryKey)}, {SqlLiteral(payloadJson)})");
        }
    }

    private static void WriteSummaryInformation(IntPtr databaseHandle, NativeMsiDatabase database)
    {
        var status = NativeMsiInterop.MsiSummaryInfoCreate(databaseHandle, 5, out var summaryHandle);
        ThrowOnError(status, "create MSI summary information");

        try
        {
            // Keep the metadata coarse-grained and useful for preview tooling.
            status = NativeMsiInterop.MsiSummaryInfoPersist(summaryHandle);
            ThrowOnError(status, "persist MSI summary information");
        }
        finally
        {
            NativeMsiInterop.MsiCloseHandle(summaryHandle);
        }
    }

    private static void ExecuteSql(IntPtr databaseHandle, string query)
    {
        var status = NativeMsiInterop.MsiDatabaseOpenViewW(databaseHandle, query, out var viewHandle);
        ThrowOnError(status, $"open MSI view for query: {query}");

        try
        {
            status = NativeMsiInterop.MsiViewExecute(viewHandle, IntPtr.Zero);
            ThrowOnError(status, $"execute MSI query: {query}");
        }
        finally
        {
            NativeMsiInterop.MsiCloseHandle(viewHandle);
        }
    }

    private static void ThrowOnError(uint status, string action)
    {
        if (status == 0)
        {
            return;
        }

        throw new InvalidOperationException($"Failed to {action}. MSI error code: {status}.");
    }

    private static string SqlLiteral(string value)
    {
        var escaped = value.Replace("'", "''", StringComparison.Ordinal);
        return $"'{escaped}'";
    }

    private static string GetPreviewPath(string databasePath)
        => Path.Combine(Path.GetDirectoryName(databasePath) ?? string.Empty, $"{Path.GetFileNameWithoutExtension(databasePath)}.preview.json");

    private static string SanitizeFileName(string value)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var chars = value.Select(ch => invalid.Contains(ch) ? '_' : ch).ToArray();
        var sanitized = new string(chars).Trim();
        return string.IsNullOrWhiteSpace(sanitized) ? "ASPLShield" : sanitized;
    }

    private static string SanitizeFolderName(string value)
    {
        var invalid = Path.GetInvalidFileNameChars().Concat(new[] { '\\', '/' }).ToHashSet();
        var chars = value.Select(ch => invalid.Contains(ch) ? '_' : ch).ToArray();
        var sanitized = new string(chars).Trim();
        return string.IsNullOrWhiteSpace(sanitized) ? "ASPLShield" : sanitized;
    }

    private static List<NativeMsiDatabaseOperation> BuildOperations(NativeMsiAuthoringPlan plan)
    {
        var operations = new List<NativeMsiDatabaseOperation>();

        foreach (var table in plan.Tables)
        {
            for (var index = 0; index < table.Rows.Count; index++)
            {
                var row = table.Rows[index];
                operations.Add(new NativeMsiDatabaseOperation
                {
                    Sequence = operations.Count + 1,
                    Operation = "InsertRow",
                    Table = table.Name,
                    PrimaryKey = row.Columns.TryGetValue(table.Name, out var key) ? key : $"{table.Name}_{index + 1}",
                    Payload = new Dictionary<string, string>(row.Columns, StringComparer.OrdinalIgnoreCase)
                });
            }
        }

        return operations;
    }

    private static string? ResolveShortcutComponent(IEnumerable<NativeMsiFileAuthoring> files, IReadOnlyDictionary<string, string> fileComponentMap, string targetPath)
    {
        if (string.IsNullOrWhiteSpace(targetPath))
        {
            return null;
        }

        if (fileComponentMap.TryGetValue(targetPath, out var directMatch))
        {
            return directMatch;
        }

        foreach (var file in files)
        {
            if (string.Equals(file.DestinationPath, targetPath, StringComparison.OrdinalIgnoreCase) && fileComponentMap.TryGetValue(file.DestinationPath, out var componentId))
            {
                return componentId;
            }
        }

        return null;
    }

    private static string ResolveTargetFileName(string targetPath)
        => string.IsNullOrWhiteSpace(targetPath) ? "INSTALLFOLDER" : Path.GetFileName(targetPath);

    private static string ResolveWorkingDirectory(string workingDirectory, string installFolder)
        => string.IsNullOrWhiteSpace(workingDirectory) ? installFolder : workingDirectory;

    private static string BuildLaunchConditionExpression(NativeMsiPrerequisiteAuthoring prerequisite)
    {
        if (!prerequisite.Required)
        {
            return string.Empty;
        }

        var version = prerequisite.MinimumVersion ?? prerequisite.Version;
        return ParsePrerequisiteType(prerequisite.Type) switch
        {
            PrerequisiteType.FileExists when !string.IsNullOrWhiteSpace(prerequisite.DetectionTarget) => $"FILEEXISTS[{prerequisite.DetectionTarget}]",
            PrerequisiteType.RegistryKey when !string.IsNullOrWhiteSpace(prerequisite.DetectionTarget) => $"REGISTRYKEY[{prerequisite.DetectionTarget}]",
            PrerequisiteType.OperatingSystem when !string.IsNullOrWhiteSpace(version) => $"VersionNT >= {version}",
            PrerequisiteType.DotNetRuntime when !string.IsNullOrWhiteSpace(version) => $".NETRuntime >= {version}",
            PrerequisiteType.Iis => "IISMANAGEMENTTOOLS",
            _ => string.Empty
        };
    }

    private static string BuildLaunchConditionDescription(NativeMsiPrerequisiteAuthoring prerequisite)
    {
        var version = prerequisite.MinimumVersion ?? prerequisite.Version;
        return ParsePrerequisiteType(prerequisite.Type) switch
        {
            PrerequisiteType.FileExists when !string.IsNullOrWhiteSpace(prerequisite.DetectionTarget) => $"Install requires the file '{prerequisite.DetectionTarget}' to exist.",
            PrerequisiteType.RegistryKey when !string.IsNullOrWhiteSpace(prerequisite.DetectionTarget) => $"Install requires registry data at '{prerequisite.DetectionTarget}'.",
            PrerequisiteType.OperatingSystem when !string.IsNullOrWhiteSpace(version) => $"Install requires Windows {version} or later.",
            PrerequisiteType.DotNetRuntime when !string.IsNullOrWhiteSpace(version) => $"Install requires .NET runtime {version} or later.",
            PrerequisiteType.Iis => "Install requires IIS management tooling.",
            _ => prerequisite.Name
        };
    }

    private static PrerequisiteType ParsePrerequisiteType(string type)
        => Enum.TryParse<PrerequisiteType>(type, ignoreCase: true, out var parsed) ? parsed : PrerequisiteType.Unknown;
}

public sealed class NativeMsiDatabase
{
    public string ProductName { get; set; } = string.Empty;

    public string Version { get; set; } = string.Empty;

    public string Publisher { get; set; } = string.Empty;

    public string InstallFolder { get; set; } = string.Empty;

    public string ProductCode { get; set; } = string.Empty;

    public string UpgradeCode { get; set; } = string.Empty;

    public string PackageCode { get; set; } = string.Empty;

    public List<NativeMsiDatabaseTable> Tables { get; set; } = new();

    public List<NativeMsiDatabaseOperation> Operations { get; set; } = new();
}

public sealed class NativeMsiDatabaseTable
{
    public string Name { get; set; } = string.Empty;

    public List<NativeMsiDatabaseRow> Rows { get; set; } = new();
}

public sealed class NativeMsiDatabaseRow
{
    public int Index { get; set; }

    public Dictionary<string, string> Columns { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class NativeMsiDatabaseOperation
{
    public int Sequence { get; set; }

    public string Operation { get; set; } = string.Empty;

    public string Table { get; set; } = string.Empty;

    public string PrimaryKey { get; set; } = string.Empty;

    public Dictionary<string, string> Payload { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

using System.Diagnostics;
using ASPLShield.Common;
using ASPLShield.Core;

namespace ASPLShield.Build;

/// <summary>
/// Compiles WiX v4 authoring files into MSI packages when the WiX CLI is installed.
/// </summary>
public sealed class WixMsiCompiler : IMsiCompiler
{
    public async Task<string?> CompileAsync(string authoringPath, InstallerProject project, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(project);

        if (string.IsNullOrWhiteSpace(authoringPath) || !File.Exists(authoringPath))
        {
            throw new FileNotFoundException("WiX authoring file was not found.", authoringPath);
        }

        var wixCli = FindTool("wix");
        if (wixCli is null)
        {
            return null;
        }

        var outputDirectory = PathUtilities.EnsureDirectory(string.IsNullOrWhiteSpace(project.OutputFolder)
            ? Path.Combine(Path.GetTempPath(), "ASPLShield")
            : project.OutputFolder);

        var msiPath = Path.Combine(outputDirectory, $"{SanitizeFileName(project.ProductName)}.msi");

        // -ext WixToolset.UI.wixext enables WixUI_InstallDir and the
        // WixUIBannerBmp/WixUIDialogBmp/WixUILicenseRtf variables referenced
        // by WixMsiGenerator. Without this flag "wix build" will fail with an
        // unresolved-extension error as soon as the generator emits a
        // <ui:WixUI> reference. Run `wix extension add WixToolset.UI.wixext`
        // once on any machine that builds, if it isn't already installed.
        var arguments = $"build \"{authoringPath}\" -ext WixToolset.UI.wixext -o \"{msiPath}\"";

        var psi = new ProcessStartInfo
        {
            FileName = wixCli,
            Arguments = arguments,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };

        using var process = Process.Start(psi) ?? throw new InvalidOperationException("Failed to launch the WiX CLI.");
        var outputTask = process.StandardOutput.ReadToEndAsync(cancellationToken);
        var errorTask = process.StandardError.ReadToEndAsync(cancellationToken);
        await process.WaitForExitAsync(cancellationToken).ConfigureAwait(false);
        var output = await outputTask.ConfigureAwait(false);
        var error = await errorTask.ConfigureAwait(false);

        if (process.ExitCode != 0)
        {
            throw new InvalidOperationException($"WiX compilation failed.{Environment.NewLine}{output}{Environment.NewLine}{error}");
        }

        return File.Exists(msiPath) ? msiPath : null;
    }

    private static string? FindTool(string toolName)
    {
        var extensions = new[] { string.Empty, ".exe", ".cmd", ".bat" };
        var pathEnv = Environment.GetEnvironmentVariable("PATH") ?? string.Empty;
        var paths = pathEnv.Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        foreach (var folder in paths)
        {
            foreach (var extension in extensions)
            {
                var candidate = Path.Combine(folder, toolName + extension);
                if (File.Exists(candidate))
                {
                    return candidate;
                }
            }
        }

        return null;
    }

    private static string SanitizeFileName(string value)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var chars = value.Select(ch => invalid.Contains(ch) ? '_' : ch).ToArray();
        var sanitized = new string(chars).Trim();
        return string.IsNullOrWhiteSpace(sanitized) ? "ASPLShield" : sanitized;
    }
}
using ASPLShield.Core;

namespace ASPLShield.Build;

/// <summary>
/// Writes the native MSI authoring database preview used by the build pipeline.
/// </summary>
public interface INativeMsiDatabaseWriter
{
    Task<string> WriteAsync(NativeMsiAuthoringPlan plan, string outputDirectory, CancellationToken cancellationToken = default);
}

namespace ASPLShield.Build;

public sealed class BuildResult
{
    public required string PackagePath { get; init; }

    public required string SetupExePath { get; init; }

    public string? UninstallExePath { get; init; }

    public string? MsiAuthoringPath { get; init; }

    public string? MsiDatabasePath { get; init; }

    public string? MsiPath { get; init; }

    public IReadOnlyList<string> Warnings { get; init; } = Array.Empty<string>();
}

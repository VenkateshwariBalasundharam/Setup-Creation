using ASPLShield.Core;

namespace ASPLShield.Build;

/// <summary>
/// Validates the authoring project before packaging begins.
/// </summary>
public sealed class ProjectValidator
{
    public ProjectValidationResult Validate(InstallerProject project)
    {
        var result = new ProjectValidationResult();

        if (string.IsNullOrWhiteSpace(project.ProductName))
        {
            result.AddError("Product name is required.");
        }

        if (string.IsNullOrWhiteSpace(project.Version))
        {
            result.AddError("Version is required.");
        }

        if (string.IsNullOrWhiteSpace(project.OutputFolder))
        {
            result.AddError("Output folder is required.");
        }

        if (string.IsNullOrWhiteSpace(project.Build.SetupExecutableName))
        {
            result.AddError("Setup executable name is required.");
        }
        else if (!string.Equals(Path.GetFileName(project.Build.SetupExecutableName), project.Build.SetupExecutableName, StringComparison.Ordinal) ||
                 !project.Build.SetupExecutableName.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ||
                 project.Build.SetupExecutableName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
        {
            result.AddError("Setup executable name must be a valid .exe file name without a folder path.");
        }

        foreach (var registry in project.RegistryEntries.Where(entry => entry is not null))
        {
            if (string.IsNullOrWhiteSpace(registry.KeyPath))
            {
                result.AddError("Registry entries require a key path.");
            }

            if (string.IsNullOrWhiteSpace(registry.Name) && string.IsNullOrWhiteSpace(registry.Value))
            {
                result.AddError("Registry entries require either a value name or a value.");
            }
        }

        foreach (var prerequisite in project.Prerequisites.Where(entry => entry is not null))
        {
            if (string.IsNullOrWhiteSpace(prerequisite.Name))
            {
                result.AddError("Prerequisites require a name.");
            }

            if (prerequisite.Type is PrerequisiteType.FileExists or PrerequisiteType.RegistryKey &&
                string.IsNullOrWhiteSpace(prerequisite.DetectionTarget))
            {
                result.AddError($"Prerequisite '{prerequisite.Name}' requires a detection target.");
            }

            if (prerequisite.Type is PrerequisiteType.OperatingSystem or PrerequisiteType.DotNetRuntime &&
                string.IsNullOrWhiteSpace(prerequisite.MinimumVersion) &&
                string.IsNullOrWhiteSpace(prerequisite.Version))
            {
                result.AddError($"Prerequisite '{prerequisite.Name}' requires a minimum version.");
            }
        }

        foreach (var service in project.Services.Where(entry => entry is not null))
        {
            if (string.IsNullOrWhiteSpace(service.ServiceName))
            {
                result.AddError("Service entries require a service name.");
            }

            if (string.IsNullOrWhiteSpace(service.ExecutablePath))
            {
                result.AddError($"Service '{service.ServiceName}' requires an executable path.");
            }

            if (!string.IsNullOrWhiteSpace(service.AccountName) && string.IsNullOrWhiteSpace(service.AccountPassword) && service.AccountName.Contains('\\'))
            {
                result.AddError($"Service '{service.ServiceName}' should specify a password for domain accounts.");
            }
        }

        foreach (var site in project.IisSites.Where(entry => entry is not null))
        {
            if (string.IsNullOrWhiteSpace(site.SiteName))
            {
                result.AddError("IIS sites require a site name.");
            }

            if (site.Bindings.Count == 0)
            {
                result.AddError($"IIS site '{site.SiteName}' requires at least one binding.");
            }
        }

        return result;
    }
}

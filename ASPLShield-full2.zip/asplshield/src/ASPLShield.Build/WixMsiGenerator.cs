using System.Xml.Linq;
using System.Security.Cryptography;
using System.Text;
using ASPLShield.Common;
using ASPLShield.Core;

namespace ASPLShield.Build;

/// <summary>
/// Generates a WiX authoring file that can be compiled into an MSI in a later build step.
/// </summary>
public sealed class WixMsiGenerator : IMsiGenerator
{
    private static readonly XNamespace WixNamespace = "http://wixtoolset.org/schemas/v4/wxs";

    public async Task<string> GenerateAsync(InstallerProject project, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(project);
        ValidateProject(project);

        var outputDirectory = PathUtilities.EnsureDirectory(string.IsNullOrWhiteSpace(project.OutputFolder)
            ? Path.Combine(Path.GetTempPath(), "ASPLShield")
            : project.OutputFolder);

        var authoringPath = Path.Combine(outputDirectory, $"{SanitizeFileName(project.ProductName)}.wxs");
        var document = BuildDocument(project);
        await File.WriteAllTextAsync(authoringPath, document.ToString(), cancellationToken).ConfigureAwait(false);
        return authoringPath;
    }

    private static XDocument BuildDocument(InstallerProject project)
    {
        var productCode = CreateStableGuid($"{project.CompanyName}|{project.ProductName}|{project.Version}");
        var upgradeCode = CreateStableGuid($"{project.CompanyName}|{project.ProductName}");
        var upgradeActionProperty = string.IsNullOrWhiteSpace(project.Build.UpgradeActionProperty)
            ? $"ASPL_UPGRADE_{SanitizeIdentifier(project.ProductName)}"
            : project.Build.UpgradeActionProperty;
        var upgradeVersionMin = string.IsNullOrWhiteSpace(project.Build.UpgradeVersionMin) ? "0.0.0" : project.Build.UpgradeVersionMin;
        var upgradeVersionMax = string.IsNullOrWhiteSpace(project.Build.UpgradeVersionMax) ? project.Version : project.Build.UpgradeVersionMax;
        var launchConditions = BuildLaunchConditions(project);

        // Regular (non-folder) file entries get an explicit Component/File pair,
        // each with its own stable Id/Guid so they can be individually referenced
        // via ComponentRef later.
        var singleFiles = project.Files
            .Select((file, index) => (file, index))
            .Where(entry => !entry.file.IsFolder)
            .ToList();

        var components = singleFiles.Select(entry =>
            new XElement(WixNamespace + "Component",
                new XAttribute("Id", $"cmp_{entry.index}"),
                new XAttribute("Guid", CreateStableGuid($"{project.CompanyName}|{project.ProductName}|file|{entry.index}")),
                new XElement(WixNamespace + "File",
                    new XAttribute("Id", $"fil_{entry.index}"),
                    new XAttribute("Source", entry.file.SourcePath),
                    new XAttribute("KeyPath", "yes"))))
            .ToList();

        // Folder entries cannot be authored as a single File element — a File
        // Source must point to an actual file, not a directory. Instead, use
        // WiX's Files harvesting element, which globs every file under the
        // source folder and auto-generates a Component/File pair for each one.
        // Files elements generate their own components internally, so their
        // entries do not need (and cannot have) a matching ComponentRef.
        var folderFilesElements = project.Files
            .Where(file => file.IsFolder)
            .Select(file => new XElement(WixNamespace + "Files",
                new XAttribute("Include", Path.Combine(file.SourcePath, "**")),
                new XAttribute("Subdirectory", file.DestinationPath)))
            .ToList();

        // Shortcut/@Target must reference an installed file by its WiX File
        // Id (e.g. "[#fil_0]"), not a literal directory-token path string
        // like "[INSTALLFOLDER]\FernAndFigLauncher.exe". Unlike attributes
        // such as RegistryValue/@Value, Shortcut/@Target does not resolve
        // bracketed directory tokens as formatted properties — if it sees an
        // unresolved "[INSTALLFOLDER]" it falls back to treating the whole
        // string as a path relative to the shortcut's own component
        // directory (which is already INSTALLFOLDER), producing a doubled-up
        // path like "C:\...\FernAndFigLauncher\[INSTALLFOLDER]\App.exe".
        // Building this lookup lets each shortcut find the File Id that
        // corresponds to the same file it's meant to launch, by matching on
        // the destination file name.
        var fileIndexByDestinationName = singleFiles
            .Select(entry => (entry.index, fileName: Path.GetFileName(entry.file.DestinationPath)))
            .Where(entry => !string.IsNullOrWhiteSpace(entry.fileName))
            .GroupBy(entry => entry.fileName, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.First().index, StringComparer.OrdinalIgnoreCase);

        var shortcuts = project.Shortcuts.Select((shortcut, index) =>
        {
            // Match the shortcut's intended target to an authored file by
            // file name, then reference it as "[#fil_N]" so WiX resolves the
            // real installed path at runtime. If no matching file is found
            // (e.g. the shortcut points at something outside project.Files),
            // fall back to the raw string so authoring doesn't silently break,
            // though this fallback will reproduce the same resolution issue.
            var targetFileName = Path.GetFileName(shortcut.TargetPath);
            var targetAttributeValue = !string.IsNullOrWhiteSpace(targetFileName)
                && fileIndexByDestinationName.TryGetValue(targetFileName, out var matchedFileIndex)
                ? $"[#fil_{matchedFileIndex}]"
                : shortcut.TargetPath;

            var shortcutElement = new XElement(WixNamespace + "Shortcut",
                new XAttribute("Id", $"shortcut_{index}"),
                new XAttribute("Name", shortcut.Name),
                new XAttribute("Description", shortcut.Name),
                new XAttribute("Target", targetAttributeValue),
                // WiX needs the actual StandardDirectory Id (e.g. "DesktopFolder"),
                // not the raw enum name (e.g. "Desktop") — map it explicitly.
                new XAttribute("Directory", ResolveStandardDirectoryId(shortcut.Location)));

            // WiX rejects an Arguments attribute that is present but empty —
            // omit it entirely when there are no arguments to pass.
            if (!string.IsNullOrWhiteSpace(shortcut.Arguments))
            {
                shortcutElement.Add(new XAttribute("Arguments", shortcut.Arguments));
            }

            // Shortcut/@WorkingDirectory expects a plain Directory Id (an
            // identifier), not a bracketed/formatted property reference like
            // "[INSTALLFOLDER]". Strip any surrounding brackets before using it.
            var workingDirectory = NormalizeDirectoryReference(shortcut.WorkingDirectory);
            if (!string.IsNullOrWhiteSpace(workingDirectory))
            {
                shortcutElement.Add(new XAttribute("WorkingDirectory", workingDirectory));
            }

            return new XElement(WixNamespace + "Component",
                new XAttribute("Id", $"cmp_shortcut_{index}"),
                new XAttribute("Guid", CreateStableGuid($"{project.CompanyName}|{project.ProductName}|shortcut|{index}")),
                shortcutElement);
        }).ToList();

        var uninstallRegistryComponent = new XElement(WixNamespace + "Component",
            new XAttribute("Id", "cmp_uninstall_metadata"),
            new XAttribute("Guid", CreateStableGuid($"{project.CompanyName}|{project.ProductName}|uninstall")),
            new XElement(WixNamespace + "RegistryValue",
                new XAttribute("Root", "HKLM"),
                new XAttribute("Key", $"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\{productCode}"),
                new XAttribute("Name", "DisplayName"),
                new XAttribute("Type", "string"),
                new XAttribute("Value", project.ProductName),
                new XAttribute("KeyPath", "yes")),
            new XElement(WixNamespace + "RegistryValue",
                new XAttribute("Root", "HKLM"),
                new XAttribute("Key", $"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\{productCode}"),
                new XAttribute("Name", "Publisher"),
                new XAttribute("Type", "string"),
                new XAttribute("Value", project.CompanyName)),
            new XElement(WixNamespace + "RegistryValue",
                new XAttribute("Root", "HKLM"),
                new XAttribute("Key", $"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\{productCode}"),
                new XAttribute("Name", "DisplayVersion"),
                new XAttribute("Type", "string"),
                new XAttribute("Value", project.Version)),
            new XElement(WixNamespace + "RegistryValue",
                new XAttribute("Root", "HKLM"),
                new XAttribute("Key", $"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\{productCode}"),
                new XAttribute("Name", "InstallLocation"),
                new XAttribute("Type", "string"),
                new XAttribute("Value", project.InstallationFolder)),
            new XElement(WixNamespace + "RegistryValue",
                new XAttribute("Root", "HKLM"),
                new XAttribute("Key", $"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\{productCode}"),
                new XAttribute("Name", "UninstallString"),
                new XAttribute("Type", "string"),
                new XAttribute("Value", $"[SystemFolder]msiexec.exe /x {productCode}")),
            new XElement(WixNamespace + "RegistryValue",
                new XAttribute("Root", "HKLM"),
                new XAttribute("Key", $"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\{productCode}"),
                new XAttribute("Name", "QuietUninstallString"),
                new XAttribute("Type", "string"),
                new XAttribute("Value", $"[SystemFolder]msiexec.exe /x {productCode} /qn")),
            new XElement(WixNamespace + "RegistryValue",
                new XAttribute("Root", "HKLM"),
                new XAttribute("Key", $"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\{productCode}"),
                new XAttribute("Name", "NoModify"),
                new XAttribute("Type", "integer"),
                new XAttribute("Value", "1")),
            new XElement(WixNamespace + "RegistryValue",
                new XAttribute("Root", "HKLM"),
                new XAttribute("Key", $"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\{productCode}"),
                new XAttribute("Name", "NoRepair"),
                new XAttribute("Type", "integer"),
                new XAttribute("Value", "1")));

        var upgradeElement = new XElement(WixNamespace + "Upgrade",
            new XAttribute("Id", upgradeCode),
            new XElement(WixNamespace + "UpgradeVersion",
                new XAttribute("Minimum", upgradeVersionMin),
                new XAttribute("IncludeMinimum", "yes"),
                new XAttribute("Maximum", upgradeVersionMax),
                new XAttribute("IncludeMaximum", "no"),
                new XAttribute("Property", upgradeActionProperty)));

        // Collect every Component Id that must be referenced from ProductComponents
        // via ComponentRef (modern WiX schema requires ComponentGroup to reference
        // Components, not contain them). Folder entries are excluded here since
        // Files harvesting generates its own components implicitly.
        var componentIds = new List<string>();
        componentIds.AddRange(singleFiles.Select(entry => $"cmp_{entry.index}"));
        componentIds.AddRange(Enumerable.Range(0, project.Shortcuts.Count).Select(index => $"cmp_shortcut_{index}"));
        componentIds.Add("cmp_uninstall_metadata");

        var componentRefs = componentIds.Select(id =>
            new XElement(WixNamespace + "ComponentRef", new XAttribute("Id", id)));

        var packageElement = new XElement(WixNamespace + "Package",
            new XAttribute("Name", project.ProductName),
            new XAttribute("Manufacturer", project.CompanyName),
            new XAttribute("Version", project.Version),
            new XAttribute("UpgradeCode", upgradeCode),
            new XAttribute("ProductCode", productCode),
            new XElement(WixNamespace + "SummaryInformation",
                new XAttribute("Description", project.Publisher)),
            new XElement(WixNamespace + "MajorUpgrade",
                new XAttribute("DowngradeErrorMessage", $"A newer version of {project.ProductName} is already installed.")),
            upgradeElement,
            new XElement(WixNamespace + "MediaTemplate"),
            new XElement(WixNamespace + "Feature",
                new XAttribute("Id", "MainFeature"),
                new XAttribute("Title", project.ProductName),
                new XAttribute("Level", "1"),
                new XElement(WixNamespace + "ComponentGroupRef", new XAttribute("Id", "ProductComponents"))),
            // Launch elements (launch conditions) are direct children of Package.
            launchConditions);

        // WiX v4+ requires well-known system folders (Desktop, Start Menu, etc.)
        // to be explicitly declared via StandardDirectory before anything can
        // reference their Id — unlike WiX v3, they are not implicitly available.
        // INSTALLFOLDER is handled separately below since it needs a *nested*
        // Directory element (with a real Name) under its own root, not a bare
        // StandardDirectory declaration.
        var standardDirectoryIds = project.Shortcuts
            .Select(shortcut => ResolveStandardDirectoryId(shortcut.Location))
            .Where(id => id != "INSTALLFOLDER")
            .Distinct()
            .ToList();

        var standardDirectoryElements = standardDirectoryIds
            .Select(id => new XElement(WixNamespace + "StandardDirectory", new XAttribute("Id", id)));

        // INSTALLFOLDER must be declared as a real Directory nested under a
        // root StandardDirectory (e.g. ProgramFilesFolder), with a Name that
        // resolves project.InstallationFolder's token (e.g. "[ProgramFiles]")
        // into the correct WiX standard-directory Id, and the remainder of
        // the path into the Name attribute. Previously this was never
        // declared at all, which caused the literal string "[INSTALLFOLDER]"
        // to be used as a folder name on disk instead of resolving to a real
        // path such as "C:\Program Files\FernAndFigLauncher".
        var (installRootId, installFolderName) = ResolveInstallationFolder(project.InstallationFolder, project.ProductName);

        var installFolderDirectory = new XElement(WixNamespace + "StandardDirectory",
            new XAttribute("Id", installRootId),
            new XElement(WixNamespace + "Directory",
                new XAttribute("Id", "INSTALLFOLDER"),
                new XAttribute("Name", installFolderName)));

        // Fragment is a sibling of Package — both live directly under the Wix root —
        // it must NOT be nested inside Package.
        var fragmentElement = new XElement(WixNamespace + "Fragment",
            installFolderDirectory,
            standardDirectoryElements,
            new XElement(WixNamespace + "DirectoryRef",
                new XAttribute("Id", "INSTALLFOLDER"),
                // Component elements live directly under DirectoryRef.
                components,
                uninstallRegistryComponent,
                shortcuts),
            // ComponentGroup is a sibling of DirectoryRef (both live in the Fragment),
            // and references the Components above via ComponentRef rather than
            // containing them. Directory="INSTALLFOLDER" gives the group (and
            // any Files-harvested components inside it) a default install location.
            new XElement(WixNamespace + "ComponentGroup",
                new XAttribute("Id", "ProductComponents"),
                new XAttribute("Directory", "INSTALLFOLDER"),
                componentRefs,
                // Folder entries are harvested here via Files rather than
                // referenced via ComponentRef, since Files auto-generates and
                // auto-includes its own components into this group.
                folderFilesElements,
                new XComment($"Prerequisites authored: {project.Prerequisites.Count}."),
                new XComment($"Launch conditions authored: {launchConditions.Count}."),
                new XComment($"Registry entries authored: {project.RegistryEntries.Count}."),
                new XComment($"Services authored: {project.Services.Count}.")));

        return new XDocument(
            new XDeclaration("1.0", "utf-8", "yes"),
            new XElement(WixNamespace + "Wix",
                new XAttribute(XNamespace.Xmlns + "wix", WixNamespace),
                packageElement,
                fragmentElement));
    }

    private static IReadOnlyList<XElement> BuildLaunchConditions(InstallerProject project)
    {
        return project.Prerequisites
            .Select(prerequisite => BuildLaunchCondition(prerequisite))
            .Where(element => element is not null)
            .Select(element => element!)
            .ToList();
    }

    private static XElement? BuildLaunchCondition(PrerequisiteEntry prerequisite)
    {
        if (!prerequisite.Required)
        {
            return null;
        }

        var version = prerequisite.MinimumVersion ?? prerequisite.Version;
        var condition = prerequisite.Type switch
        {
            PrerequisiteType.FileExists when !string.IsNullOrWhiteSpace(prerequisite.DetectionTarget) => $"FILEEXISTS[{prerequisite.DetectionTarget}]",
            PrerequisiteType.RegistryKey when !string.IsNullOrWhiteSpace(prerequisite.DetectionTarget) => $"REGISTRYKEY[{prerequisite.DetectionTarget}]",
            PrerequisiteType.OperatingSystem when !string.IsNullOrWhiteSpace(version) => $"VersionNT >= {version}",
            PrerequisiteType.DotNetRuntime when !string.IsNullOrWhiteSpace(version) => $".NETRuntime >= {version}",
            PrerequisiteType.Iis => "IISMANAGEMENTTOOLS",
            _ => string.Empty
        };

        if (string.IsNullOrWhiteSpace(condition))
        {
            return null;
        }

        var message = prerequisite.Type switch
        {
            PrerequisiteType.FileExists when !string.IsNullOrWhiteSpace(prerequisite.DetectionTarget) => $"Install requires the file '{prerequisite.DetectionTarget}' to exist.",
            PrerequisiteType.RegistryKey when !string.IsNullOrWhiteSpace(prerequisite.DetectionTarget) => $"Install requires registry data at '{prerequisite.DetectionTarget}'.",
            PrerequisiteType.OperatingSystem when !string.IsNullOrWhiteSpace(version) => $"Install requires Windows {version} or later.",
            PrerequisiteType.DotNetRuntime when !string.IsNullOrWhiteSpace(version) => $"Install requires .NET runtime {version} or later.",
            PrerequisiteType.Iis => "Install requires IIS management tooling.",
            _ => prerequisite.Name
        };

        // Modern WiX (v4+) uses the "Launch" element with a Condition attribute,
        // not the legacy "LaunchCondition" element (which isn't a valid source
        // element name — LaunchCondition is only the name of the compiled MSI table).
        return new XElement(WixNamespace + "Launch",
            new XAttribute("Condition", condition),
            new XAttribute("Message", message));
    }

    private static string CreateStableGuid(string seed)
    {
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(seed));
        Span<byte> guidBytes = stackalloc byte[16];
        bytes.AsSpan(0, 16).CopyTo(guidBytes);
        guidBytes[7] = (byte)((guidBytes[7] & 0x0F) | 0x50);
        guidBytes[8] = (byte)((guidBytes[8] & 0x3F) | 0x80);
        return new Guid(guidBytes).ToString("D");
    }

    /// <summary>
    /// Strips bracket formatting (e.g. "[INSTALLFOLDER]") from a directory
    /// reference. Several WiX attributes such as Shortcut/@WorkingDirectory
    /// expect a plain Directory Id, not a formatted/bracketed property
    /// reference — those brackets are only valid inside formatted-string
    /// contexts like RegistryValue values, not identifier attributes.
    /// </summary>
    private static string NormalizeDirectoryReference(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return string.Empty;
        }

        var trimmed = value.Trim();
        if (trimmed.StartsWith('[') && trimmed.EndsWith(']') && trimmed.Length > 2)
        {
            return trimmed[1..^1];
        }

        return trimmed;
    }

    /// <summary>
    /// Resolves the project's InstallationFolder value (e.g.
    /// "[ProgramFiles]\FernAndFigLauncher") into the WiX StandardDirectory Id
    /// that should serve as its root (e.g. "ProgramFilesFolder"), and the
    /// remaining path segment that becomes the INSTALLFOLDER directory's
    /// Name attribute (e.g. "FernAndFigLauncher").
    ///
    /// If the value has no recognized bracketed root token, or is missing
    /// entirely, this falls back to ProgramFilesFolder + the product name so
    /// INSTALLFOLDER always resolves to a real, sensible location rather than
    /// producing a broken or literal path on disk.
    /// </summary>
    private static (string RootDirectoryId, string FolderName) ResolveInstallationFolder(string? installationFolder, string productName)
    {
        var fallbackName = string.IsNullOrWhiteSpace(productName) ? "ASPLShieldApp" : productName;
        var trimmed = (installationFolder ?? string.Empty).Trim();

        if (trimmed.StartsWith('['))
        {
            var closeBracket = trimmed.IndexOf(']');
            if (closeBracket > 0)
            {
                var token = trimmed[1..closeBracket];
                var remainder = trimmed[(closeBracket + 1)..].TrimStart('\\', '/');

                var rootId = token switch
                {
                    "ProgramFiles" => "ProgramFilesFolder",
                    "ProgramFiles64" => "ProgramFiles64Folder",
                    "ProgramFilesX86" => "ProgramFilesFolder",
                    "CommonFiles" => "CommonFilesFolder",
                    "CommonFiles64" => "CommonFiles64Folder",
                    "AppData" => "AppDataFolder",
                    "LocalAppData" => "LocalAppDataFolder",
                    "System" => "SystemFolder",
                    "System64" => "System64Folder",
                    "Windows" => "WindowsFolder",
                    _ => "ProgramFilesFolder"
                };

                var folderName = string.IsNullOrWhiteSpace(remainder) ? fallbackName : remainder;
                return (rootId, folderName);
            }
        }

        // No bracketed token at all (e.g. blank, or a raw path was typed) —
        // fall back to a safe, real default instead of letting a malformed
        // value flow through as a literal directory name.
        return ("ProgramFilesFolder", fallbackName);
    }

    /// <summary>
    /// Maps a shortcut's Location value to the actual WiX StandardDirectory Id
    /// that must be used in Shortcut/@Directory. The raw enum name (e.g.
    /// "Desktop") is not a valid Directory Id on its own — WiX's well-known
    /// folder Ids follow their own naming convention (e.g. "DesktopFolder").
    /// </summary>
    private static string ResolveStandardDirectoryId<TLocation>(TLocation location)
        where TLocation : notnull
    {
        return location.ToString() switch
        {
            "Desktop" => "DesktopFolder",
            "StartMenu" => "ProgramMenuFolder",
            _ => "INSTALLFOLDER"
        };
    }

    /// <summary>
    /// Produces a WiX-legal identifier fragment (ASCII letters, digits,
    /// underscores, periods only — see WIX0014) from a display string such as
    /// a product name. Any other character (including "&amp;", spaces already
    /// normalized to "_", punctuation, etc.) is replaced with an underscore so
    /// generated identifiers like the UpgradeVersion/@Property value never
    /// fail WiX's identifier validation.
    /// </summary>
    private static string SanitizeIdentifier(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return "ASPLSHIELD";
        }

        var upper = value.ToUpperInvariant();
        var chars = upper.Select(ch =>
            (ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9') || ch == '_' || ch == '.'
                ? ch
                : '_').ToArray();

        var sanitized = new string(chars);

        // Identifiers must begin with a letter or underscore, not a digit.
        if (sanitized.Length > 0 && char.IsDigit(sanitized[0]))
        {
            sanitized = "_" + sanitized;
        }

        return string.IsNullOrWhiteSpace(sanitized) ? "ASPLSHIELD" : sanitized;
    }

    private static string SanitizeFileName(string value)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var chars = value.Select(ch => invalid.Contains(ch) ? '_' : ch).ToArray();
        var sanitized = new string(chars).Trim();
        return string.IsNullOrWhiteSpace(sanitized) ? "ASPLShield" : sanitized;
    }

    private static void ValidateProject(InstallerProject project)
    {
        if (string.IsNullOrWhiteSpace(project.ProductName))
        {
            throw new InvalidOperationException("Product name is required for WiX authoring.");
        }

        if (string.IsNullOrWhiteSpace(project.Version))
        {
            throw new InvalidOperationException("Version is required for WiX authoring.");
        }

        if (project.Files.Any(file => !file.IsFolder && !File.Exists(file.SourcePath)))
        {
            throw new FileNotFoundException("One or more file sources could not be found.");
        }

        if (project.Files.Any(file => file.IsFolder && !Directory.Exists(file.SourcePath)))
        {
            throw new DirectoryNotFoundException("One or more folder sources could not be found.");
        }

        if (project.Files.Any(file => string.IsNullOrWhiteSpace(file.DestinationPath)))
        {
            throw new InvalidOperationException("Every file or folder entry needs a destination path.");
        }

        if (project.Shortcuts.Any(shortcut => string.IsNullOrWhiteSpace(shortcut.Name) || string.IsNullOrWhiteSpace(shortcut.TargetPath)))
        {
            throw new InvalidOperationException("Every shortcut requires a name and target path.");
        }
    }
}
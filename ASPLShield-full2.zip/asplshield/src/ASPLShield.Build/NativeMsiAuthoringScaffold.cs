using System.Text.Json;
using ASPLShield.Common;
using ASPLShield.Core;

namespace ASPLShield.Build;

/// <summary>
/// Native MSI authoring plan generator for the Windows Installer API path.
/// The current build still uses the WiX toolchain, but this class captures the
/// data we will need when moving to an MSI COM/API authoring path.
/// </summary>
public sealed class NativeMsiAuthoringScaffold
{
    public async Task<string> GeneratePlanAsync(InstallerProject project, string outputDirectory, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(project);

        var directory = PathUtilities.EnsureDirectory(outputDirectory);
        var planPath = Path.Combine(directory, $"{SanitizeFileName(project.ProductName)}.native-msi-plan.json");
        var plan = new NativeMsiAuthoringPlan
        {
            ProductName = project.ProductName,
            CompanyName = project.CompanyName,
            Version = project.Version,
            Publisher = project.Publisher,
            InstallFolder = project.InstallationFolder,
            ProductCode = CreateStableGuid($"{project.CompanyName}|{project.ProductName}|{project.Version}"),
            UpgradeCode = CreateStableGuid($"{project.CompanyName}|{project.ProductName}"),
            PackageCode = CreateStableGuid($"{project.CompanyName}|{project.ProductName}|{project.Version}|package"),
            UpgradeVersionMin = string.IsNullOrWhiteSpace(project.Build.UpgradeVersionMin) ? "0.0.0" : project.Build.UpgradeVersionMin,
            UpgradeVersionMax = project.Version,
            UpgradeActionProperty = $"ASPL_UPGRADE_{project.ProductName.ToUpperInvariant().Replace(' ', '_')}",
            FileCount = project.Files.Count,
            ShortcutCount = project.Shortcuts.Count,
            RegistryCount = project.RegistryEntries.Count,
            ServiceCount = project.Services.Count,
            IisSiteCount = project.IisSites.Count,
            Files = project.Files.Select(file => new NativeMsiFileAuthoring
            {
                DisplayName = file.DisplayName,
                SourcePath = file.SourcePath,
                DestinationPath = file.DestinationPath,
                IsFolder = file.IsFolder,
                SizeBytes = file.SizeBytes
            }).ToList(),
            Shortcuts = project.Shortcuts.Select(shortcut => new NativeMsiShortcutAuthoring
            {
                Name = shortcut.Name,
                TargetPath = shortcut.TargetPath,
                Arguments = shortcut.Arguments,
                WorkingDirectory = shortcut.WorkingDirectory,
                Location = shortcut.Location.ToString()
            }).ToList(),
            RegistryEntries = project.RegistryEntries.Select(entry => new NativeMsiRegistryAuthoring
            {
                RegistryRoot = entry.RegistryRoot.ToString(),
                KeyPath = entry.KeyPath,
                Name = entry.Name,
                Value = entry.Value,
                ValueKind = entry.ValueKind
            }).ToList(),
            Services = project.Services.Select(service => new NativeMsiServiceAuthoring
            {
                ServiceName = service.ServiceName,
                DisplayName = service.DisplayName,
                ExecutablePath = service.ExecutablePath,
                Arguments = service.Arguments,
                Description = service.Description,
                AccountName = service.AccountName,
                AutoStart = service.AutoStart,
                DelayedAutoStart = service.DelayedAutoStart,
                Dependencies = service.Dependencies.ToList()
            }).ToList(),
            IisSites = project.IisSites.Select(site => new NativeMsiIisSiteAuthoring
            {
                SiteName = site.SiteName,
                PhysicalPath = site.PhysicalPath,
                ApplicationPoolName = site.ApplicationPoolName,
                CreateApplicationPool = site.CreateApplicationPool,
                StartOnInstall = site.StartOnInstall,
                Bindings = site.Bindings.Select(binding => new NativeMsiIisBindingAuthoring
                {
                    Protocol = binding.Protocol,
                    BindingInformation = binding.BindingInformation
                }).ToList()
            }).ToList(),
            Prerequisites = project.Prerequisites.Select(prerequisite => new NativeMsiPrerequisiteAuthoring
            {
                Name = prerequisite.Name,
                Version = prerequisite.Version,
                Required = prerequisite.Required,
                Description = prerequisite.Description,
                Type = prerequisite.Type.ToString(),
                DetectionTarget = prerequisite.DetectionTarget,
                MinimumVersion = prerequisite.MinimumVersion,
                ExpectedValue = prerequisite.ExpectedValue
            }).ToList(),
            Tables = BuildTables(project)
        };

        var json = JsonSerializer.Serialize(plan, new JsonSerializerOptions { WriteIndented = true });
        await File.WriteAllTextAsync(planPath, json, cancellationToken).ConfigureAwait(false);
        return planPath;
    }

    private static string SanitizeFileName(string value)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var chars = value.Select(ch => invalid.Contains(ch) ? '_' : ch).ToArray();
        var sanitized = new string(chars).Trim();
        return string.IsNullOrWhiteSpace(sanitized) ? "ASPLShield" : sanitized;
    }

    private static List<NativeMsiTableAuthoring> BuildTables(InstallerProject project)
    {
        var tables = new List<NativeMsiTableAuthoring>
        {
            new()
            {
                Name = "Property",
                Rows = new List<NativeMsiTableRow>
                {
                    Row(("Property", "ProductName"), ("Value", project.ProductName)),
                    Row(("Property", "Manufacturer"), ("Value", project.CompanyName)),
                    Row(("Property", "ProductVersion"), ("Value", project.Version)),
                    Row(("Property", "Publisher"), ("Value", project.Publisher)),
                    Row(("Property", "InstallFolder"), ("Value", project.InstallationFolder))
                }
            },
            new()
            {
                Name = "Feature",
                Rows = new List<NativeMsiTableRow>
                {
                    Row(("Feature", "MainFeature"), ("Title", project.ProductName), ("Level", "1"))
                }
            },
            new()
            {
                Name = "Upgrade",
                Rows = new List<NativeMsiTableRow>
                {
                    Row(
                        ("UpgradeCode", CreateStableGuid($"{project.CompanyName}|{project.ProductName}")),
                        ("VersionMin", "0.0.0"),
                        ("VersionMax", project.Version),
                        ("Language", string.Empty),
                        ("Attributes", "0"),
                        ("Remove", project.ProductName),
                        ("ActionProperty", $"ASPL_UPGRADE_{project.ProductName.ToUpperInvariant().Replace(' ', '_')}"))
                }
            },
            new()
            {
                Name = "Directory",
                Rows = new List<NativeMsiTableRow>
                {
                    Row(("Directory", "TARGETDIR"), ("Parent", string.Empty), ("DefaultDir", "SourceDir")),
                    Row(("Directory", "ProgramFilesFolder"), ("Parent", "TARGETDIR"), ("DefaultDir", "PFiles")),
                    Row(("Directory", "INSTALLFOLDER"), ("Parent", "ProgramFilesFolder"), ("DefaultDir", SanitizeFolderName(project.ProductName)))
                }
            },
            new()
            {
                Name = "Component",
                Rows = project.Files.Select((file, index) => Row(
                    ("Component", $"cmp_{index}"),
                    ("Directory_", "INSTALLFOLDER"),
                    ("Guid", CreateStableGuid($"{project.CompanyName}|{project.ProductName}|file|{index}")),
                    ("KeyPath", "file"))).ToList()
            },
            new()
            {
                Name = "File",
                Rows = project.Files.Select((file, index) => Row(
                    ("File", $"fil_{index}"),
                    ("Component_", $"cmp_{index}"),
                    ("FileName", file.DestinationPath),
                    ("Source", file.SourcePath))).ToList()
            },
            new()
            {
                Name = "Shortcut",
                Rows = project.Shortcuts.Select((shortcut, index) => Row(
                    ("Shortcut", $"shortcut_{index}"),
                    ("Directory_", shortcut.Location.ToString()),
                    ("Name", shortcut.Name),
                    ("Target", shortcut.TargetPath),
                    ("Arguments", shortcut.Arguments),
                    ("WorkingDirectory", shortcut.WorkingDirectory))).ToList()
            },
            new()
            {
                Name = "Registry",
                Rows = project.RegistryEntries.Select((entry, index) => Row(
                    ("Registry", $"reg_{index}"),
                    ("Root", entry.RegistryRoot.ToString()),
                    ("Key", entry.KeyPath),
                    ("Name", entry.Name),
                    ("Value", entry.Value),
                    ("Type", entry.ValueKind))).ToList()
            },
            new()
            {
                Name = "ServiceInstall",
                Rows = project.Services.Select((service, index) => Row(
                    ("ServiceInstall", $"svc_{index}"),
                    ("ServiceName", service.ServiceName),
                    ("DisplayName", service.DisplayName),
                    ("StartType", service.AutoStart ? "auto" : "demand"),
                    ("AccountName", service.AccountName ?? string.Empty),
                    ("DelayedAutoStart", service.DelayedAutoStart ? "yes" : "no"),
                    ("Dependencies", string.Join(",", service.Dependencies.Where(static dep => !string.IsNullOrWhiteSpace(dep)))))).ToList()
            },
            new()
            {
                Name = "ServiceControl",
                Rows = project.Services.Select((service, index) => Row(
                    ("ServiceControl", $"svcctl_{index}"),
                    ("ServiceName", service.ServiceName),
                    ("Event", "stop/uninstall"),
                    ("Wait", "yes"))).ToList()
            },
            new()
            {
                Name = "ServiceConfig",
                Rows = project.Services.Select((service, index) => Row(
                    ("ServiceConfig", $"svcconfig_{index}"),
                    ("ServiceName", service.ServiceName),
                    ("DisplayName", service.DisplayName),
                    ("AutoStart", service.AutoStart ? "yes" : "no"),
                    ("DelayedAutoStart", service.DelayedAutoStart ? "yes" : "no"),
                    ("AccountName", service.AccountName ?? string.Empty),
                    ("Description", service.Description ?? string.Empty))).ToList()
            },
            new()
            {
                Name = "ServiceDependency",
                Rows = project.Services.SelectMany((service, serviceIndex) => service.Dependencies.Select((dependency, dependencyIndex) => Row(
                    ("ServiceDependency", $"svcdep_{serviceIndex}_{dependencyIndex}"),
                    ("ServiceName", service.ServiceName),
                    ("Dependency", dependency),
                    ("Position", dependencyIndex.ToString())))).ToList()
            },
            new()
            {
                Name = "NativeIisSite",
                Rows = project.IisSites.Select((site, index) => Row(
                    ("Site", $"iis_{index}"),
                    ("SiteName", site.SiteName),
                    ("PhysicalPath", site.PhysicalPath),
                    ("ApplicationPoolName", site.ApplicationPoolName),
                    ("CreateApplicationPool", site.CreateApplicationPool ? "yes" : "no"),
                    ("StartOnInstall", site.StartOnInstall ? "yes" : "no"))).ToList()
            },
            new()
            {
                Name = "NativeIisApplicationPool",
                Rows = project.IisSites.Select((site, index) => Row(
                    ("ApplicationPool", $"iispool_{index}"),
                    ("SiteName", site.SiteName),
                    ("ApplicationPoolName", site.ApplicationPoolName),
                    ("CreateApplicationPool", site.CreateApplicationPool ? "yes" : "no"),
                    ("StartOnInstall", site.StartOnInstall ? "yes" : "no"))).ToList()
            },
            new()
            {
                Name = "NativeIisBinding",
                Rows = project.IisSites.SelectMany((site, siteIndex) => site.Bindings.Select((binding, bindingIndex) => Row(
                    ("Binding", $"iisbind_{siteIndex}_{bindingIndex}"),
                    ("SiteName", site.SiteName),
                    ("Protocol", binding.Protocol),
                    ("BindingInformation", binding.BindingInformation),
                    ("Position", bindingIndex.ToString())))).ToList()
            },
            new()
            {
                Name = "LaunchCondition",
                Rows = BuildLaunchConditions(project)
            },
            new()
            {
                Name = "Prerequisite",
                Rows = project.Prerequisites.Select((prerequisite, index) => Row(
                    ("Prerequisite", $"prereq_{index}"),
                    ("Name", prerequisite.Name),
                    ("Version", prerequisite.Version),
                    ("Required", prerequisite.Required ? "yes" : "no"),
                    ("Description", prerequisite.Description ?? string.Empty),
                    ("Type", prerequisite.Type.ToString()),
                    ("DetectionTarget", prerequisite.DetectionTarget ?? string.Empty),
                    ("MinimumVersion", prerequisite.MinimumVersion ?? string.Empty),
                    ("ExpectedValue", prerequisite.ExpectedValue ?? string.Empty))).ToList()
            }
        };

        return tables;
    }

    private static List<NativeMsiTableRow> BuildLaunchConditions(InstallerProject project)
    {
        return project.Prerequisites.Select((prerequisite, index) =>
        {
            var condition = BuildLaunchConditionExpression(prerequisite);
            if (string.IsNullOrWhiteSpace(condition))
            {
                return null;
            }

            return Row(
                ("LaunchCondition", $"launch_{index}"),
                ("Condition", condition),
                ("Description", BuildLaunchConditionDescription(prerequisite)),
                ("Prerequisite", prerequisite.Name),
                ("Required", prerequisite.Required ? "yes" : "no"),
                ("Type", prerequisite.Type.ToString()),
                ("DetectionTarget", prerequisite.DetectionTarget ?? string.Empty),
                ("MinimumVersion", prerequisite.MinimumVersion ?? prerequisite.Version ?? string.Empty),
                ("ExpectedValue", prerequisite.ExpectedValue ?? string.Empty));
        }).Where(row => row is not null).Select(row => row!).ToList();
    }

    private static string BuildLaunchConditionExpression(PrerequisiteEntry prerequisite)
    {
        if (!prerequisite.Required)
        {
            return string.Empty;
        }

        return prerequisite.Type switch
        {
            PrerequisiteType.FileExists when !string.IsNullOrWhiteSpace(prerequisite.DetectionTarget) => $"FILEEXISTS[{prerequisite.DetectionTarget}]",
            PrerequisiteType.RegistryKey when !string.IsNullOrWhiteSpace(prerequisite.DetectionTarget) => $"REGISTRYKEY[{prerequisite.DetectionTarget}]",
            PrerequisiteType.OperatingSystem when !string.IsNullOrWhiteSpace(prerequisite.MinimumVersion ?? prerequisite.Version) => $"VersionNT >= {prerequisite.MinimumVersion ?? prerequisite.Version}",
            PrerequisiteType.DotNetRuntime when !string.IsNullOrWhiteSpace(prerequisite.MinimumVersion ?? prerequisite.Version) => $".NETRuntime >= {prerequisite.MinimumVersion ?? prerequisite.Version}",
            PrerequisiteType.Iis => "IISMANAGEMENTTOOLS",
            _ => string.Empty
        };
    }

    private static string BuildLaunchConditionDescription(PrerequisiteEntry prerequisite)
    {
        return prerequisite.Type switch
        {
            PrerequisiteType.FileExists when !string.IsNullOrWhiteSpace(prerequisite.DetectionTarget) => $"Install requires the file '{prerequisite.DetectionTarget}' to exist.",
            PrerequisiteType.RegistryKey when !string.IsNullOrWhiteSpace(prerequisite.DetectionTarget) => $"Install requires registry data at '{prerequisite.DetectionTarget}'.",
            PrerequisiteType.OperatingSystem => $"Install requires Windows {prerequisite.MinimumVersion ?? prerequisite.Version} or later.",
            PrerequisiteType.DotNetRuntime => $"Install requires .NET runtime {prerequisite.MinimumVersion ?? prerequisite.Version} or later.",
            PrerequisiteType.Iis => "Install requires IIS management tooling.",
            _ => prerequisite.Name
        };
    }

    private static NativeMsiTableRow Row(params (string Column, string? Value)[] values)
        => new()
        {
            Columns = values.ToDictionary(value => value.Column, value => value.Value ?? string.Empty, StringComparer.OrdinalIgnoreCase)
        };

    private static string SanitizeFolderName(string value)
    {
        var invalid = Path.GetInvalidFileNameChars().Concat(new[] { '\\', '/' }).ToHashSet();
        var chars = value.Select(ch => invalid.Contains(ch) ? '_' : ch).ToArray();
        var sanitized = new string(chars).Trim();
        return string.IsNullOrWhiteSpace(sanitized) ? "ASPLShield" : sanitized;
    }

    private static string CreateStableGuid(string seed)
    {
        var bytes = System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(seed));
        Span<byte> guidBytes = stackalloc byte[16];
        bytes.AsSpan(0, 16).CopyTo(guidBytes);
        guidBytes[7] = (byte)((guidBytes[7] & 0x0F) | 0x50);
        guidBytes[8] = (byte)((guidBytes[8] & 0x3F) | 0x80);
        return new Guid(guidBytes).ToString("D");
    }
}

/// <summary>
/// Structured preview of a future native MSI authoring model.
/// </summary>
public sealed class NativeMsiAuthoringPlan
{
    public string ProductName { get; set; } = string.Empty;

    public string CompanyName { get; set; } = string.Empty;

    public string Version { get; set; } = string.Empty;

    public string Publisher { get; set; } = string.Empty;

    public string InstallFolder { get; set; } = string.Empty;

    public string ProductCode { get; set; } = string.Empty;

    public string UpgradeCode { get; set; } = string.Empty;

    public string PackageCode { get; set; } = string.Empty;

    public string UpgradeVersionMin { get; set; } = "0.0.0";

    public string UpgradeVersionMax { get; set; } = string.Empty;

    public string UpgradeActionProperty { get; set; } = string.Empty;

    public int FileCount { get; set; }

    public int ShortcutCount { get; set; }

    public int RegistryCount { get; set; }

    public int ServiceCount { get; set; }

    public int IisSiteCount { get; set; }

    public List<NativeMsiFileAuthoring> Files { get; set; } = new();

    public List<NativeMsiShortcutAuthoring> Shortcuts { get; set; } = new();

    public List<NativeMsiRegistryAuthoring> RegistryEntries { get; set; } = new();

    public List<NativeMsiServiceAuthoring> Services { get; set; } = new();

    public List<NativeMsiIisSiteAuthoring> IisSites { get; set; } = new();

    public List<NativeMsiPrerequisiteAuthoring> Prerequisites { get; set; } = new();

    public List<NativeMsiTableAuthoring> Tables { get; set; } = new();
}

public sealed class NativeMsiTableAuthoring
{
    public string Name { get; set; } = string.Empty;

    public List<NativeMsiTableRow> Rows { get; set; } = new();
}

public sealed class NativeMsiTableRow
{
    public Dictionary<string, string> Columns { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class NativeMsiFileAuthoring
{
    public string DisplayName { get; set; } = string.Empty;

    public string SourcePath { get; set; } = string.Empty;

    public string DestinationPath { get; set; } = string.Empty;

    public bool IsFolder { get; set; }

    public long SizeBytes { get; set; }
}

public sealed class NativeMsiShortcutAuthoring
{
    public string Name { get; set; } = string.Empty;

    public string TargetPath { get; set; } = string.Empty;

    public string Arguments { get; set; } = string.Empty;

    public string WorkingDirectory { get; set; } = string.Empty;

    public string Location { get; set; } = string.Empty;
}

public sealed class NativeMsiRegistryAuthoring
{
    public string RegistryRoot { get; set; } = string.Empty;

    public string KeyPath { get; set; } = string.Empty;

    public string Name { get; set; } = string.Empty;

    public string Value { get; set; } = string.Empty;

    public string ValueKind { get; set; } = "String";
}

public sealed class NativeMsiServiceAuthoring
{
    public string ServiceName { get; set; } = string.Empty;

    public string DisplayName { get; set; } = string.Empty;

    public string ExecutablePath { get; set; } = string.Empty;

    public string Arguments { get; set; } = string.Empty;

    public string? Description { get; set; }

    public string? AccountName { get; set; }

    public bool AutoStart { get; set; }

    public bool DelayedAutoStart { get; set; }

    public List<string> Dependencies { get; set; } = new();
}

public sealed class NativeMsiIisSiteAuthoring
{
    public string SiteName { get; set; } = string.Empty;

    public string PhysicalPath { get; set; } = string.Empty;

    public string ApplicationPoolName { get; set; } = string.Empty;

    public bool CreateApplicationPool { get; set; }

    public bool StartOnInstall { get; set; }

    public List<NativeMsiIisBindingAuthoring> Bindings { get; set; } = new();
}

public sealed class NativeMsiIisBindingAuthoring
{
    public string Protocol { get; set; } = "http";

    public string BindingInformation { get; set; } = "*:80:";
}

public sealed class NativeMsiPrerequisiteAuthoring
{
    public string Name { get; set; } = string.Empty;

    public string Version { get; set; } = string.Empty;

    public bool Required { get; set; } = true;

    public string? Description { get; set; }

    public string Type { get; set; } = string.Empty;

    public string? DetectionTarget { get; set; }

    public string? MinimumVersion { get; set; }

    public string? ExpectedValue { get; set; }
}

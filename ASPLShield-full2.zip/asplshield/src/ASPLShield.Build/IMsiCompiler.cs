using ASPLShield.Core;

namespace ASPLShield.Build;

/// <summary>
/// Compiles WiX authoring into a distributable MSI package when the WiX toolchain is available.
/// </summary>
public interface IMsiCompiler
{
    Task<string?> CompileAsync(string authoringPath, InstallerProject project, CancellationToken cancellationToken = default);
}

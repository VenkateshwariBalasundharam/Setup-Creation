using ASPLShield.Core;

namespace ASPLShield.Build;

public interface IBuildEngine
{
    Task<BuildResult> BuildAsync(BuildRequest request, CancellationToken cancellationToken = default);
}

using System.Diagnostics;
using ASPLShield.Common;
using ASPLShield.Core;

namespace ASPLShield.Build;

/// <summary>
/// Optional Windows code signing adapter that uses signtool when signing material is configured.
/// </summary>
public sealed class WindowsDigitalSigner : IDigitalSigner
{
    public async Task<string> SignAsync(string filePath, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(filePath))
        {
            throw new ArgumentException("A file path is required.", nameof(filePath));
        }

        if (!File.Exists(filePath))
        {
            throw new FileNotFoundException("The file to sign was not found.", filePath);
        }

        var settings = IntegrationSettingsLoader.Current;
        var certPath = settings.SigningCertificatePath ?? Environment.GetEnvironmentVariable("ASPLSHIELD_SIGNING_CERT");
        if (string.IsNullOrWhiteSpace(certPath) || !File.Exists(certPath))
        {
            return filePath;
        }

        var password = settings.SigningCertificatePassword ?? Environment.GetEnvironmentVariable("ASPLSHIELD_SIGNING_PASSWORD") ?? string.Empty;
        var timestampUrl = settings.SigningTimestampUrl ?? Environment.GetEnvironmentVariable("ASPLSHIELD_TIMESTAMP_URL");
        var signtool = settings.SigningToolPath ?? FindTool("signtool");
        if (signtool is null)
        {
            return filePath;
        }

        var psi = new ProcessStartInfo
        {
            FileName = signtool,
            Arguments = BuildArguments(certPath, password, timestampUrl, filePath),
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };

        using var process = Process.Start(psi) ?? throw new InvalidOperationException("Failed to launch signtool.");
        var outputTask = process.StandardOutput.ReadToEndAsync(cancellationToken);
        var errorTask = process.StandardError.ReadToEndAsync(cancellationToken);
        await process.WaitForExitAsync(cancellationToken).ConfigureAwait(false);
        var output = await outputTask.ConfigureAwait(false);
        var error = await errorTask.ConfigureAwait(false);

        if (process.ExitCode != 0)
        {
            throw new InvalidOperationException($"Code signing failed.{Environment.NewLine}{output}{Environment.NewLine}{error}");
        }

        return filePath;
    }

    private static string BuildArguments(string certPath, string password, string? timestampUrl, string filePath)
    {
        var arguments = new List<string>
        {
            "sign",
            "/fd",
            "sha256",
            "/f",
            Quote(certPath)
        };

        if (!string.IsNullOrWhiteSpace(password))
        {
            arguments.Add("/p");
            arguments.Add(Quote(password));
        }

        if (!string.IsNullOrWhiteSpace(timestampUrl))
        {
            arguments.Add("/tr");
            arguments.Add(Quote(timestampUrl));
            arguments.Add("/td");
            arguments.Add("sha256");
        }

        arguments.Add(Quote(filePath));
        return string.Join(" ", arguments);
    }

    private static string Quote(string value) => $"\"{value.Replace("\"", "\\\"", StringComparison.Ordinal)}\"";

    private static string? FindTool(string toolName)
    {
        var extensions = new[] { string.Empty, ".exe", ".cmd", ".bat" };
        var pathEnv = Environment.GetEnvironmentVariable("PATH") ?? string.Empty;
        var paths = pathEnv.Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        foreach (var folder in paths)
        {
            foreach (var extension in extensions)
            {
                var candidate = Path.Combine(folder, toolName + extension);
                if (File.Exists(candidate))
                {
                    return candidate;
                }
            }
        }

        return null;
    }
}

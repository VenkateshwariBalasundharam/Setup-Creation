using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using Microsoft.Win32.SafeHandles;

namespace ASPLShield.Build;

/// <summary>
/// Native Windows Installer API entry points used by the future MSI authoring backend.
/// </summary>
[SupportedOSPlatform("windows")]
internal static class NativeMsiInterop
{
    internal const int MsiOpenDatabaseModeDirect = 2;
    internal const int MsiPersist = 1;
    internal const int MsiViewModifyInsert = 1;
    internal const string MsiCreatePersist = "CREATE";

    [DllImport("msi.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    internal static extern uint MsiOpenDatabaseW(string databasePath, string persist, out IntPtr databaseHandle);

    [DllImport("msi.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    internal static extern uint MsiDatabaseOpenViewW(IntPtr databaseHandle, string query, out IntPtr viewHandle);

    [DllImport("msi.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    internal static extern uint MsiViewExecute(IntPtr viewHandle, IntPtr recordHandle);

    [DllImport("msi.dll", SetLastError = true)]
    internal static extern uint MsiViewFetch(IntPtr viewHandle, out IntPtr recordHandle);

    [DllImport("msi.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    internal static extern uint MsiRecordSetStringW(IntPtr recordHandle, uint field, string value);

    [DllImport("msi.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    internal static extern uint MsiRecordGetStringW(IntPtr recordHandle, uint field, System.Text.StringBuilder valueBuffer, ref uint valueBufferSize);

    [DllImport("msi.dll", SetLastError = true)]
    internal static extern uint MsiCreateRecord(uint fieldCount, out IntPtr recordHandle);

    [DllImport("msi.dll", SetLastError = true)]
    internal static extern uint MsiDatabaseCommit(IntPtr databaseHandle);

    [DllImport("msi.dll", SetLastError = true)]
    internal static extern uint MsiCloseHandle(IntPtr handle);

    [DllImport("msi.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    internal static extern uint MsiSummaryInfoCreate(IntPtr databaseHandle, uint updateCount, out IntPtr summaryHandle);

    [DllImport("msi.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    internal static extern uint MsiSummaryInfoPersist(IntPtr summaryHandle);

}

/// <summary>
/// Lightweight disposable wrapper around an MSI database handle.
/// </summary>
[SupportedOSPlatform("windows")]
internal sealed class NativeMsiDatabaseHandle : SafeHandle
{
    public NativeMsiDatabaseHandle() : base(IntPtr.Zero, ownsHandle: true)
    {
    }

    public override bool IsInvalid => handle == IntPtr.Zero;

    protected override bool ReleaseHandle() => NativeMsiInterop.MsiCloseHandle(handle) == 0;
}

/// <summary>
/// Lightweight disposable wrapper around an MSI view handle.
/// </summary>
[SupportedOSPlatform("windows")]
internal sealed class NativeMsiViewHandle : SafeHandle
{
    public NativeMsiViewHandle() : base(IntPtr.Zero, ownsHandle: true)
    {
    }

    public override bool IsInvalid => handle == IntPtr.Zero;

    protected override bool ReleaseHandle() => NativeMsiInterop.MsiCloseHandle(handle) == 0;
}

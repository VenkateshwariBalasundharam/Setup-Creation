using ASPLShield.Core;

namespace ASPLShield.Build;

public sealed class BuildRequest
{
    public required InstallerProject Project { get; init; }

    public required string OutputDirectory { get; init; }

    public string? SetupProjectPath { get; init; }

    public string? UninstallerProjectPath { get; init; }
}

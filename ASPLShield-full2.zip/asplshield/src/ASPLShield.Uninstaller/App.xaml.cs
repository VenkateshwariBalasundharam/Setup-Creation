using System.Diagnostics;
using System.Windows;
using ASPLShield.PackageEngine;

namespace ASPLShield.Uninstaller;

public partial class App : System.Windows.Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        var quiet = e.Args.Any(arg => arg.Equals("--quiet", StringComparison.OrdinalIgnoreCase) || arg.Equals("/quiet", StringComparison.OrdinalIgnoreCase));

        IUninstallerService service = new UninstallerService(new AsplPackageEngine());
        try
        {
            var installFolder = service.ResolveInstallFolder(e.Args);
            if (string.IsNullOrWhiteSpace(installFolder))
            {
                if (!quiet)
                {
                    System.Windows.MessageBox.Show("Unable to locate an installed product to uninstall.", "ASPLShield Uninstaller", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                Shutdown();
                return;
            }

            if (IsRunningInsideFolder(installFolder))
            {
                RelaunchFromTemp(e.Args);
                Shutdown();
                return;
            }

            if (quiet)
            {
                // Silent/scripted uninstall: no window, same behavior as before.
                service.UninstallAsync(installFolder).GetAwaiter().GetResult();
                Shutdown();
                return;
            }

            RunWithProgressWindow(service, installFolder);
        }
        catch (Exception ex)
        {
            if (!quiet)
            {
                System.Windows.MessageBox.Show(ex.Message, "ASPLShield Uninstaller", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            Shutdown();
        }
    }

    private void RunWithProgressWindow(IUninstallerService service, string installFolder)
    {
        var window = new MainWindow();
        MainWindow = window;
        window.Show();

        var progress = new Progress<string>(message => window.ViewModel.ReportProgress(message));

        // Fire-and-forget on purpose: the UI thread must stay free to render progress.
        // The window itself only closes once ReportSuccess/ReportFailure enables the
        // Close button, so we never exit before the user has seen the result.
        RunUninstallAsync(service, installFolder, progress, window);
    }

    private async void RunUninstallAsync(IUninstallerService service, string installFolder, IProgress<string> progress, MainWindow window)
    {
        try
        {
            var productName = await service.UninstallAsync(installFolder, progress).ConfigureAwait(true);
            var displayName = string.IsNullOrWhiteSpace(productName) ? "The application" : productName;
            window.ViewModel.ReportSuccess($"{displayName} has been successfully removed from your computer.");
        }
        catch (TimeoutException ex)
        {
            window.ViewModel.ReportFailure($"{ex.Message} Check Task Manager, or the IIS/Services consoles, for anything still holding a lock.");
        }
        catch (Exception ex)
        {
            window.ViewModel.ReportFailure($"Uninstall could not complete: {ex.Message}");
        }
    }

    private static bool IsRunningInsideFolder(string folder)
    {
        var processPath = Environment.ProcessPath;
        return !string.IsNullOrWhiteSpace(processPath) &&
               Path.GetFullPath(processPath).StartsWith(Path.GetFullPath(folder), StringComparison.OrdinalIgnoreCase);
    }

    private static void RelaunchFromTemp(string[] args)
    {
        var currentProcessPath = Environment.ProcessPath ?? throw new InvalidOperationException("The current process path could not be determined.");
        var tempPath = Path.Combine(Path.GetTempPath(), $"{Guid.NewGuid():N}.exe");
        File.Copy(currentProcessPath, tempPath, overwrite: true);

        var psi = new ProcessStartInfo
        {
            FileName = tempPath,
            Arguments = string.Join(" ", args.Select(QuoteArgument)),
            UseShellExecute = false,
            WorkingDirectory = Path.GetDirectoryName(tempPath) ?? Path.GetTempPath()
        };

        Process.Start(psi);
    }

    private static string QuoteArgument(string value)
        => value.Any(char.IsWhiteSpace) ? $"\"{value.Replace("\"", "\\\"", StringComparison.Ordinal)}\"" : value;
}
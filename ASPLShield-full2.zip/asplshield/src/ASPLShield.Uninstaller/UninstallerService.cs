using Microsoft.Win32;
using System.Text.Json;
using ASPLShield.Core;
using ASPLShield.PackageEngine;
using ASPLShield.ServiceInstaller;

namespace ASPLShield.Uninstaller;

public interface IUninstallerService
{
    string? ResolveInstallFolder(string[] args);

    /// <summary>Uninstalls the product at <paramref name="installFolder"/> and returns its display name, if known.</summary>
    Task<string?> UninstallAsync(string installFolder, IProgress<string>? progress = null, CancellationToken cancellationToken = default);
}

public sealed class InstallationState
{
    public string ProductName { get; set; } = string.Empty;

    public string ProductVersion { get; set; } = string.Empty;

    public string Publisher { get; set; } = string.Empty;

    public string InstallFolder { get; set; } = string.Empty;

    public string PackagePath { get; set; } = string.Empty;

    public string? UpdateFeedUri { get; set; }

    public List<string> ShortcutPaths { get; set; } = new();
}

public sealed class UninstallerService : IUninstallerService
{
    private static readonly TimeSpan StepTimeout = TimeSpan.FromSeconds(60);

    private readonly IPackageEngine _packageEngine;
    private readonly string _logRoot = Path.Combine(Path.GetTempPath(), "ASPLShield", "Logs");

    public UninstallerService(IPackageEngine? packageEngine = null)
    {
        _packageEngine = packageEngine ?? new AsplPackageEngine();
    }

    public string? ResolveInstallFolder(string[] args)
        => InstalledProductLocator.ResolveInstallFolder(args, AppContext.BaseDirectory);

    public async Task<string?> UninstallAsync(string installFolder, IProgress<string>? progress = null, CancellationToken cancellationToken = default)
    {
        progress?.Report("Preparing to uninstall...");

        var statePath = Path.Combine(installFolder, "asplshield.installstate.json");
        if (!File.Exists(statePath))
        {
            progress?.Report("Removing installation files...");
            await TryDeleteInstallFolderAsync(installFolder, progress, cancellationToken).ConfigureAwait(false);
            return null;
        }

        var state = JsonSerializer.Deserialize<InstallationState>(await File.ReadAllTextAsync(statePath, cancellationToken).ConfigureAwait(true));
        if (state is null)
        {
            progress?.Report("Removing installation files...");
            await TryDeleteInstallFolderAsync(installFolder, progress, cancellationToken).ConfigureAwait(false);
            return null;
        }

        await WriteLogAsync("uninstall.log", $"Uninstall started for '{state.ProductName} {state.ProductVersion}' published by '{state.Publisher}'.", cancellationToken).ConfigureAwait(false);

        await RemovePackageConfigurationAsync(state.PackagePath, progress, cancellationToken).ConfigureAwait(true);

        progress?.Report("Removing shortcuts...");
        foreach (var shortcutPath in state.ShortcutPaths)
        {
            await TryDeleteFileAsync(shortcutPath, cancellationToken).ConfigureAwait(false);
        }

        CleanupShortcutFolders(state.ShortcutPaths);

        progress?.Report("Removing installation files...");
        await TryDeleteInstallFolderAsync(installFolder, progress, cancellationToken).ConfigureAwait(false);

        progress?.Report("Cleaning up registry entries...");
        RemoveUninstallInformation(state.ProductName, installFolder);

        progress?.Report("Uninstall complete.");
        await WriteLogAsync("uninstall.log", $"Uninstall completed for '{state.ProductName} {state.ProductVersion}' from '{state.InstallFolder}'.", cancellationToken).ConfigureAwait(false);

        return state.ProductName;
    }

    /// <summary>
    /// Runs an operation with a hard timeout. If the operation doesn't complete in time,
    /// this throws a TimeoutException instead of letting the caller hang indefinitely.
    /// Note: the underlying operation may keep running in the background if it doesn't
    /// observe the cancellation token, but the UI is freed to report the failure.
    /// </summary>
    private static async Task RunWithTimeoutAsync(string stepDescription, Func<CancellationToken, Task> operation, CancellationToken cancellationToken)
    {
        using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeoutCts.CancelAfter(StepTimeout);

        var operationTask = operation(timeoutCts.Token);
        var completed = await Task.WhenAny(operationTask, Task.Delay(Timeout.Infinite, timeoutCts.Token).ContinueWith(_ => (Task?)null, TaskScheduler.Default)).ConfigureAwait(false);

        if (completed != operationTask)
        {
            cancellationToken.ThrowIfCancellationRequested();
            throw new TimeoutException($"'{stepDescription}' did not complete within {StepTimeout.TotalSeconds:0} seconds and appears to be stuck.");
        }

        await operationTask.ConfigureAwait(false);
    }

    private async Task RemovePackageConfigurationAsync(string packagePath, IProgress<string>? progress, CancellationToken cancellationToken)
    {
        if (!File.Exists(packagePath))
        {
            return;
        }

        AsplPackageInfo? package = null;
        try
        {
            package = await _packageEngine.ReadPackageAsync(packagePath, cancellationToken).ConfigureAwait(true);
        }
        catch (Exception ex)
        {
            await WriteLogAsync("uninstall.log", $"Package metadata could not be read for uninstall: {ex.Message}", cancellationToken).ConfigureAwait(false);
        }

        if (package is null)
        {
            return;
        }

        progress?.Report("Removing registry entries...");
        await RunWithTimeoutAsync("Remove registry entries", ct => new WindowsRegistryInstaller().UninstallAsync(package.Manifest.RegistryEntries.Select(entry => new RegistryEntry
        {
            RegistryRoot = entry.RegistryRoot,
            KeyPath = entry.KeyPath,
            Name = entry.Name,
            Value = entry.Value,
            ValueKind = entry.ValueKind
        }), ct), cancellationToken).ConfigureAwait(true);

        foreach (var service in package.Manifest.Services)
        {
            if (!string.IsNullOrWhiteSpace(service.ServiceName))
            {
                progress?.Report($"Stopping and removing service '{service.ServiceName}'...");
                await RunWithTimeoutAsync($"Stop service '{service.ServiceName}'", ct => new WindowsServiceInstaller().UninstallAsync(service.ServiceName, ct), cancellationToken).ConfigureAwait(true);
            }
        }

        if (package.Manifest.IisSites.Count > 0)
        {
            progress?.Report("Removing IIS site and application pool...");
            await RunWithTimeoutAsync("Remove IIS site", ct => new WindowsIisInstaller().UninstallAsync(package.Manifest.IisSites.Select(site => new IisSiteEntry
            {
                SiteName = site.SiteName,
                PhysicalPath = site.PhysicalPath,
                ApplicationPoolName = site.ApplicationPoolName,
                CreateApplicationPool = site.CreateApplicationPool,
                StartOnInstall = site.StartOnInstall,
                Bindings = site.Bindings.Select(binding => new IisSiteBindingEntry
                {
                    Protocol = binding.Protocol,
                    BindingInformation = binding.BindingInformation
                }).ToList()
            }), ct), cancellationToken).ConfigureAwait(true);
        }
    }

    private async Task TryDeleteInstallFolderAsync(string installFolder, IProgress<string>? progress, CancellationToken cancellationToken)
    {
        try
        {
            if (Directory.Exists(installFolder))
            {
                ClearReadOnlyAttributes(installFolder);
                await RunWithTimeoutAsync("Delete install folder", _ =>
                    Task.Run(() => Directory.Delete(installFolder, recursive: true)),
                    cancellationToken).ConfigureAwait(false);
            }
        }
        catch (Exception ex)
        {
            progress?.Report($"Warning: could not fully remove {installFolder} ({ex.Message}).");
            await WriteLogAsync("uninstall.log", $"Failed to delete install folder '{installFolder}': {ex.Message}", cancellationToken).ConfigureAwait(false);
        }
    }

    private static void RemoveUninstallInformation(string productName, string installFolder)
    {
        var keyPath = $@"Software\Microsoft\Windows\CurrentVersion\Uninstall\ASPLShield_{SanitizeRegistrySegment(productName)}";
        TryDeleteSubKeyTree(Registry.CurrentUser, keyPath);
        TryDeleteSubKeyTree(Registry.LocalMachine, keyPath);
        TryDeleteMatchingSubKey(Registry.CurrentUser, productName, installFolder);
        TryDeleteMatchingSubKey(Registry.LocalMachine, productName, installFolder);
    }

    private static void TryDeleteSubKeyTree(RegistryKey root, string keyPath)
    {
        try
        {
            root.DeleteSubKeyTree(keyPath, throwOnMissingSubKey: false);
        }
        catch (UnauthorizedAccessException)
        {
        }
    }

    private static void TryDeleteMatchingSubKey(RegistryKey root, string productName, string installFolder)
    {
        try
        {
            using var uninstallRoot = root.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Uninstall", writable: true);
            if (uninstallRoot is null)
            {
                return;
            }

            foreach (var subKeyName in uninstallRoot.GetSubKeyNames())
            {
                if (!subKeyName.StartsWith("ASPLShield_", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                using var subKey = uninstallRoot.OpenSubKey(subKeyName, writable: true);
                var displayName = subKey?.GetValue("DisplayName") as string;
                var installLocation = subKey?.GetValue("InstallLocation") as string;
                if (!string.Equals(displayName, productName, StringComparison.OrdinalIgnoreCase) &&
                    !string.Equals(installLocation, installFolder, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                uninstallRoot.DeleteSubKeyTree(subKeyName, throwOnMissingSubKey: false);
            }
        }
        catch
        {
        }
    }

    private static void CleanupShortcutFolders(IEnumerable<string> shortcutPaths)
    {
        var desktopRoot = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
        var startMenuProgramsRoot = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Programs");

        foreach (var shortcutPath in shortcutPaths)
        {
            var folder = Path.GetDirectoryName(shortcutPath);
            if (string.IsNullOrWhiteSpace(folder))
            {
                continue;
            }

            if (folder.StartsWith(desktopRoot, StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            if (!folder.StartsWith(startMenuProgramsRoot, StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            DeleteEmptyParents(folder, startMenuProgramsRoot);
        }
    }

    private async Task TryDeleteFileAsync(string path, CancellationToken cancellationToken)
    {
        try
        {
            if (File.Exists(path))
            {
                ClearReadOnlyAttributes(path);
                File.Delete(path);
            }
        }
        catch (Exception ex)
        {
            await WriteLogAsync("uninstall.log", $"Failed to delete shortcut '{path}': {ex.Message}", cancellationToken).ConfigureAwait(false);
        }
    }

    private static void DeleteEmptyParents(string path, string stopAt)
    {
        var current = path;
        while (!string.IsNullOrWhiteSpace(current) &&
               current.StartsWith(stopAt, StringComparison.OrdinalIgnoreCase) &&
               !string.Equals(current, stopAt, StringComparison.OrdinalIgnoreCase))
        {
            try
            {
                if (Directory.Exists(current) && Directory.GetFileSystemEntries(current).Length == 0)
                {
                    Directory.Delete(current, recursive: false);
                }
                else
                {
                    break;
                }
            }
            catch
            {
                return;
            }

            current = Directory.GetParent(current)?.FullName ?? string.Empty;
        }
    }

    private async Task WriteLogAsync(string logFileName, string message, CancellationToken cancellationToken)
    {
        try
        {
            Directory.CreateDirectory(_logRoot);
            var logPath = Path.Combine(_logRoot, logFileName);
            var line = $"[{DateTime.UtcNow:O}] {message}{Environment.NewLine}";
            await File.AppendAllTextAsync(logPath, line, cancellationToken).ConfigureAwait(false);
        }
        catch
        {
        }
    }

    private static void ClearReadOnlyAttributes(string path)
    {
        if (File.Exists(path))
        {
            var fileAttributes = File.GetAttributes(path);
            if (fileAttributes.HasFlag(FileAttributes.ReadOnly))
            {
                File.SetAttributes(path, fileAttributes & ~FileAttributes.ReadOnly);
            }

            return;
        }

        if (!Directory.Exists(path))
        {
            return;
        }

        foreach (var file in Directory.EnumerateFiles(path, "*", SearchOption.AllDirectories))
        {
            var attributes = File.GetAttributes(file);
            if (attributes.HasFlag(FileAttributes.ReadOnly))
            {
                File.SetAttributes(file, attributes & ~FileAttributes.ReadOnly);
            }
        }
    }

    private static string SanitizeRegistrySegment(string value)
    {
        var invalid = new HashSet<char>(new[] { '\\', '/', ':', '*', '?', '"', '<', '>', '|', '\0' });
        var chars = value.Select(ch => char.IsControl(ch) || invalid.Contains(ch) ? '_' : ch).ToArray();
        var sanitized = new string(chars).Trim();
        return string.IsNullOrWhiteSpace(sanitized) ? "ASPLShield" : sanitized;
    }
}
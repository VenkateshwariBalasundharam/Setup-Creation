using System.Windows;
using ASPLShield.Common;

namespace ASPLShield.Uninstaller;

public sealed class UninstallerWindowViewModel : ObservableObject
{
    private string _headerText = "Preparing to uninstall...";
    private string _footerText = "Please wait while ASPLShield is removed from your computer.";
    private string _statusText = "Preparing to uninstall...";
    private string _resultTitle = string.Empty;
    private bool _isInProgress = true;
    private bool _isFinished;
    private bool _isError;

    public string HeaderText
    {
        get => _headerText;
        set => SetProperty(ref _headerText, value);
    }

    public string FooterText
    {
        get => _footerText;
        set => SetProperty(ref _footerText, value);
    }

    public string StatusText
    {
        get => _statusText;
        set => SetProperty(ref _statusText, value);
    }

    public string ResultTitle
    {
        get => _resultTitle;
        set => SetProperty(ref _resultTitle, value);
    }

    public bool IsInProgress
    {
        get => _isInProgress;
        set => SetProperty(ref _isInProgress, value);
    }

    public bool IsFinished
    {
        get => _isFinished;
        set => SetProperty(ref _isFinished, value);
    }

    public bool IsError
    {
        get => _isError;
        set => SetProperty(ref _isError, value);
    }

    public RelayCommand CloseCommand { get; }

    public UninstallerWindowViewModel(Action closeAction)
    {
        CloseCommand = new RelayCommand(_ => closeAction(), _ => IsFinished);
    }

    public void ReportProgress(string message)
    {
        StatusText = message;
        HeaderText = message;
    }

    public void ReportSuccess(string message)
    {
        IsInProgress = false;
        IsFinished = true;
        IsError = false;
        ResultTitle = "Uninstall Complete";
        StatusText = message;
        HeaderText = "Uninstall complete";
        FooterText = "You may now close this window.";
        CloseCommand.RaiseCanExecuteChanged();
    }

    public void ReportFailure(string message)
    {
        IsInProgress = false;
        IsFinished = true;
        IsError = true;
        ResultTitle = "Uninstall Failed";
        StatusText = message;
        HeaderText = "Uninstall failed";
        FooterText = "You may now close this window.";
        CloseCommand.RaiseCanExecuteChanged();
    }
}

public partial class MainWindow : Window
{
    public UninstallerWindowViewModel ViewModel { get; }

    public MainWindow()
    {
        InitializeComponent();
        ViewModel = new UninstallerWindowViewModel(Close);
        DataContext = ViewModel;
    }
}

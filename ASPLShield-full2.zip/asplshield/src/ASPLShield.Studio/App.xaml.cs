using ASPLShield.Build;
using ASPLShield.Common;
using ASPLShield.Core;
using ASPLShield.PackageEngine;
using ASPLShield.UpdateEngine;
using ASPLShield.ServiceInstaller;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.IO;

namespace ASPLShield.Studio;

public partial class App : System.Windows.Application
{
    public IServiceProvider Services { get; private set; } = null!;

    // Single click on a tree row toggles its own expand/collapse state immediately.
    // Uses the bubbling MouseLeftButtonDown event, so the row actually under the
    // cursor (the deepest TreeViewItem in the visual tree) handles the click first;
    // marking it Handled stops the click from also toggling any parent row.
    private void TreeViewItem_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (sender is not TreeViewItem item)
        {
            return;
        }

        if (item.HasItems)
        {
            item.IsExpanded = !item.IsExpanded;
        }

        item.IsSelected = true;
        e.Handled = true;
    }

    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        // A crash during startup previously just flashed and closed the window with
        // no visible error: OnStartup is 'async void', so any exception thrown after
        // the first 'await' becomes an unhandled exception that WPF terminates the
        // process on (silently, outside the debugger). These handlers make sure a
        // startup (or any) crash is logged and shown to the user instead.
        DispatcherUnhandledException += (_, args) =>
        {
            LogAndShowCrash(args.Exception);
            args.Handled = true;
            Shutdown(-1);
        };
        AppDomain.CurrentDomain.UnhandledException += (_, args) =>
        {
            LogAndShowCrash(args.ExceptionObject as Exception ?? new Exception(args.ExceptionObject?.ToString() ?? "Unknown fatal error."));
        };
        TaskScheduler.UnobservedTaskException += (_, args) =>
        {
            LogAndShowCrash(args.Exception);
            args.SetObserved();
        };

        try
        {
            var services = new ServiceCollection();
            ConfigureServices(services);
            Services = services.BuildServiceProvider();

            await Services.GetRequiredService<StudioDatabaseInitializer>().InitializeAsync().ConfigureAwait(true);
            Environment.SetEnvironmentVariable("ASPLSHIELD_INTEGRATION_CONFIG", FileIntegrationSettingsStore.GetPath());
            var themeService = Services.GetRequiredService<IStudioThemeService>();
            var settingsStore = Services.GetRequiredService<IStudioSettingsStore>();
            var savedTheme = await settingsStore.GetThemeAsync().ConfigureAwait(true);
            if (savedTheme is not null)
            {
                themeService.ApplyTheme(savedTheme.Value);
            }

            await Services.GetRequiredService<IntegrationSettingsViewModel>().LoadAsync().ConfigureAwait(true);

            var mainWindow = Services.GetRequiredService<MainWindow>();
            mainWindow.Show();
        }
        catch (Exception ex)
        {
            LogAndShowCrash(ex);
            Shutdown(-1);
        }
    }

    private static void LogAndShowCrash(Exception ex)
    {
        string logPath = string.Empty;
        try
        {
            var logDirectory = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "ASPLShield",
                "logs");
            Directory.CreateDirectory(logDirectory);
            logPath = Path.Combine(logDirectory, "startup-crash.log");
            File.AppendAllText(logPath, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {ex}\n\n");
        }
        catch
        {
            // Best-effort logging only; still show the message box below even if
            // writing the log itself fails (e.g. disk full, permissions).
        }

        var detail = string.IsNullOrEmpty(logPath)
            ? string.Empty
            : $"\n\nFull details were written to:\n{logPath}";

        System.Windows.MessageBox.Show(
            $"ASPLShield Studio failed to start.\n\n{ex.GetType().Name}: {ex.Message}{detail}",
            "ASPLShield Studio - Startup Error",
            MessageBoxButton.OK,
            MessageBoxImage.Error);
    }

    private static void ConfigureServices(IServiceCollection services)
    {
        services.AddLogging(builder => builder.SetMinimumLevel(LogLevel.Information));

        services.AddSingleton<IProjectSerializer, XmlProjectSerializer>();
        services.AddSingleton<IPackageEngine, AsplPackageEngine>();
        services.AddSingleton<ProjectValidator>();
        services.AddSingleton<INativeMsiDatabaseWriter, NativeMsiDatabaseWriter>();
        services.AddSingleton<IBuildEngine, AsplBuildEngine>();
        services.AddSingleton<IRegistryInstaller, WindowsRegistryInstaller>();
        services.AddSingleton<IIisInstaller, WindowsIisInstaller>();
        services.AddSingleton<IServiceInstaller, WindowsServiceInstaller>();
        services.AddSingleton<IPrerequisiteChecker, WindowsPrerequisiteChecker>();
        services.AddSingleton<IMsiGenerator, WixMsiGenerator>();
        services.AddSingleton<IMsiCompiler, WixMsiCompiler>();
        services.AddSingleton<IDigitalSigner, WindowsDigitalSigner>();
        services.AddSingleton<IAutoUpdater, UpdateEngineClient>();
        services.AddSingleton<UpdateEngineClient>();
        services.AddSingleton<IStudioThemeService, StudioThemeService>();
        services.AddSingleton<IStudioSettingsStore, SqliteStudioSettingsStore>();
        services.AddSingleton<IIntegrationSettingsStore, FileIntegrationSettingsStore>();
        services.AddSingleton<IStudioLogMonitorService, StudioLogMonitorService>();
        services.AddSingleton<IProjectValidationService, ProjectValidationService>();
        services.AddSingleton<IIisWarningService, IisWarningService>();
        services.AddSingleton<IStudioBuildWorkflowService, StudioBuildWorkflowService>();
        services.AddSingleton<IStudioNativePreviewService, StudioNativePreviewService>();
        services.AddSingleton<IStudioProjectSessionService, StudioProjectSessionService>();
        services.AddSingleton<IStudioRefreshService, StudioRefreshService>();
        services.AddSingleton<StudioThemeViewModel>();
        services.AddSingleton<IntegrationSettingsViewModel>();
        services.AddSingleton<IStudioSqliteConnectionFactory, StudioSqliteConnectionFactory>();
        services.AddSingleton<IStudioShellService, StudioShellService>();
        services.AddSingleton<StudioDatabaseInitializer>();
        services.AddSingleton<IProjectRepository, SqliteProjectRepository>();
        services.AddSingleton<IFileDialogService, WpfFileDialogService>();
        services.AddSingleton<INewProjectDialogService, NewProjectDialogService>();
        services.AddSingleton<ISelectPrerequisiteDialogService, SelectPrerequisiteDialogService>();

        services.AddTransient<ProjectExplorerViewModel>();
        services.AddTransient<FileSystemEditorViewModel>();
        services.AddTransient<ShortcutEditorViewModel>();
        services.AddTransient<IisEditorViewModel>();
        services.AddTransient<RegistryEditorViewModel>();
        services.AddTransient<ServiceEditorViewModel>();
        services.AddTransient<PropertiesViewModel>();
        services.AddTransient<BuildOutputViewModel>();
        services.AddSingleton<MainViewModel>();

        services.AddTransient<NewProjectWizardWindow>();
        services.AddTransient<SelectPrerequisiteWindow>();
        services.AddSingleton<MainWindow>();
    }
}
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using WpfUserControl = System.Windows.Controls.UserControl;

namespace ASPLShield.Studio.Controls;

public partial class FeatureTreeDropDown : WpfUserControl, INotifyPropertyChanged
{
    public static readonly DependencyProperty FeaturesProperty =
        DependencyProperty.Register(nameof(Features), typeof(System.Collections.ObjectModel.ObservableCollection<FeatureTreeNode>),
            typeof(FeatureTreeDropDown), new PropertyMetadata(null, OnFeaturesChanged));

    /// <summary>The root feature nodes to display.</summary>
    public System.Collections.ObjectModel.ObservableCollection<FeatureTreeNode>? Features
    {
        get => (System.Collections.ObjectModel.ObservableCollection<FeatureTreeNode>?)GetValue(FeaturesProperty);
        set => SetValue(FeaturesProperty, value);
    }

    /// <summary>
    /// True = checking one feature auto-unchecks every other node (for "Assign to Feature").
    /// False (default) = multiple features may be checked at once (for "Filter by Feature").
    /// </summary>
    public bool SingleSelect { get; set; }

    public static readonly DependencyProperty PlaceholderTextProperty =
        DependencyProperty.Register(nameof(PlaceholderText), typeof(string), typeof(FeatureTreeDropDown),
            new PropertyMetadata("Feature Independent"));

    /// <summary>Text shown when nothing is checked.</summary>
    public string PlaceholderText
    {
        get => (string)GetValue(PlaceholderTextProperty);
        set => SetValue(PlaceholderTextProperty, value);
    }

    /// <summary>Raised whenever a check state changes anywhere in the tree.</summary>
    public event EventHandler? SelectionChanged;

    public FeatureTreeDropDown()
    {
        InitializeComponent();
    }

    private static void OnFeaturesChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        var ctrl = (FeatureTreeDropDown)d;
        if (e.NewValue is System.Collections.ObjectModel.ObservableCollection<FeatureTreeNode> newCol)
        {
            foreach (var n in newCol)
            {
                HookAll(n, ctrl);
            }
        }

        ctrl.RaiseSummaryChanged();
    }

    private static void HookAll(FeatureTreeNode node, FeatureTreeDropDown ctrl)
    {
        node.PropertyChanged += (s, e) =>
        {
            if (e.PropertyName != nameof(FeatureTreeNode.IsChecked))
            {
                return;
            }

            if (ctrl.SingleSelect && s is FeatureTreeNode changed && changed.IsChecked == true)
            {
                // Only one node may stay checked - clear every other one.
                foreach (var other in ctrl.Features!.SelectMany(f => f.Flatten()))
                {
                    if (!ReferenceEquals(other, changed) && other.IsChecked != false)
                    {
                        other.SetIsChecked(false, updateChildren: true, updateParent: true);
                    }
                }
            }

            ctrl.RaiseSummaryChanged();
            ctrl.SelectionChanged?.Invoke(ctrl, EventArgs.Empty);
        };

        foreach (var c in node.Children)
        {
            HookAll(c, ctrl);
        }
    }

    /// <summary>All nodes currently checked true (not indeterminate).</summary>
    public IEnumerable<FeatureTreeNode> CheckedFeatures =>
        Features?.SelectMany(f => f.Flatten()).Where(f => f.IsChecked == true) ?? Enumerable.Empty<FeatureTreeNode>();

    public string SummaryText
    {
        get
        {
            var names = CheckedFeatures.Select(f => f.Label).ToList();
            return names.Count switch
            {
                0 => PlaceholderText,
                1 => names[0],
                _ => $"{names.Count} features selected"
            };
        }
    }

    public void ClearSelection()
    {
        if (Features is null)
        {
            return;
        }

        foreach (var n in Features)
        {
            n.SetIsChecked(false, updateChildren: true, updateParent: true);
        }
    }

    private void RaiseSummaryChanged() =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SummaryText)));

    public event PropertyChangedEventHandler? PropertyChanged;
}

using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using MediaColor = System.Windows.Media.Color;

namespace ASPLShield.Studio.Converters;

/// <summary>
/// Converts a hex color string (e.g. "#1A73E8") into a <see cref="SolidColorBrush"/> for preview
/// swatches such as the Installer Branding accent color picker. Blank or unparsable input falls
/// back to a neutral gray swatch rather than throwing or leaving the swatch blank.
/// </summary>
public sealed class HexToBrushConverter : IValueConverter
{
    private static readonly SolidColorBrush FallbackBrush = CreateFrozen(MediaColor.FromRgb(0xC8, 0xD7, 0xE8));

    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        var hex = value as string;
        if (string.IsNullOrWhiteSpace(hex))
        {
            return FallbackBrush;
        }

        try
        {
            var converted = System.Windows.Media.ColorConverter.ConvertFromString(hex);
            if (converted is MediaColor color)
            {
                return CreateFrozen(color);
            }
        }
        catch (FormatException)
        {
            // Fall through to the fallback swatch while the user is still typing.
        }

        return FallbackBrush;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => throw new NotSupportedException("HexToBrushConverter only supports one-way binding.");

    private static SolidColorBrush CreateFrozen(MediaColor color)
    {
        var brush = new SolidColorBrush(color);
        brush.Freeze();
        return brush;
    }
}


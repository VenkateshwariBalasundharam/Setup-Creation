using ASPLShield.Common;
using System.Collections.ObjectModel;
using ASPLShield.Core;

namespace ASPLShield.Studio;

public sealed class NewProjectWizardViewModel : ObservableObject
{
    private readonly IProjectRepository _projectRepository;
    private readonly IFileDialogService? _fileDialogs;
    private string _setupExecutableName = ProjectBuildSettings.DefaultSetupExecutableName;
    private string _productName = "Sample App";
    private string _companyName = "ASPL";
    private string _version = "1.0.0";
    private string _publisher = "ASPL";
    private string _installationFolder = @"[ProgramFiles]\SampleApp";
    private string _outputFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "ASPLShieldBuild");
    private ProjectTemplateEntry? _selectedTemplate;
    private string _templateStatus = "No templates loaded.";

    public NewProjectWizardViewModel(IProjectRepository projectRepository, IFileDialogService? fileDialogs = null)
    {
        _projectRepository = projectRepository;
        _fileDialogs = fileDialogs;
        BrowseOutputFolderCommand = new RelayCommand(_ => BrowseOutputFolder(), _ => _fileDialogs is not null);
        CreateCommand = new RelayCommand(_ => IsConfirmed = true);
        CancelCommand = new RelayCommand(_ => IsConfirmed = false);
        RefreshTemplatesCommand = new AsyncRelayCommand(_ => LoadTemplatesAsync());
        ApplyTemplateCommand = new AsyncRelayCommand(_ => ApplySelectedTemplateAsync(), _ => SelectedTemplate is not null);
    }

    public string ProductName { get => _productName; set => SetProperty(ref _productName, value); }

    public string CompanyName { get => _companyName; set => SetProperty(ref _companyName, value); }

    public string Version { get => _version; set => SetProperty(ref _version, value); }

    public string Publisher { get => _publisher; set => SetProperty(ref _publisher, value); }

    public string InstallationFolder { get => _installationFolder; set => SetProperty(ref _installationFolder, value); }

    public string OutputFolder { get => _outputFolder; set => SetProperty(ref _outputFolder, value); }

    public string SetupExecutableName
    {
        get => _setupExecutableName;
        set => SetProperty(ref _setupExecutableName, ProjectBuildSettings.NormalizeSetupExecutableName(value));
    }

    public bool IsConfirmed { get; set; }

    public RelayCommand BrowseOutputFolderCommand { get; }

    private void BrowseOutputFolder()
    {
        var path = _fileDialogs?.SelectFolder("Select the folder where Setup.exe and the package will be created", OutputFolder);
        if (!string.IsNullOrWhiteSpace(path))
        {
            OutputFolder = path;
        }
    }

    public ObservableCollection<ProjectTemplateEntry> Templates { get; } = new();

    public ProjectTemplateEntry? SelectedTemplate
    {
        get => _selectedTemplate;
        set
        {
            if (SetProperty(ref _selectedTemplate, value))
            {
                ApplyTemplateCommand.RaiseCanExecuteChanged();
            }
        }
    }

    public string TemplateStatus
    {
        get => _templateStatus;
        private set => SetProperty(ref _templateStatus, value);
    }

    public RelayCommand CreateCommand { get; }

    public RelayCommand CancelCommand { get; }

    public AsyncRelayCommand RefreshTemplatesCommand { get; }

    public AsyncRelayCommand ApplyTemplateCommand { get; }

    public async Task LoadTemplatesAsync()
    {
        var templates = await _projectRepository.GetTemplatesAsync().ConfigureAwait(true);
        Templates.Clear();
        foreach (var template in templates)
        {
            Templates.Add(template);
        }

        TemplateStatus = templates.Count == 0
            ? "No templates saved yet."
            : $"{templates.Count} template{(templates.Count == 1 ? string.Empty : "s")} available.";
    }

    public async Task ApplySelectedTemplateAsync()
    {
        if (SelectedTemplate is null)
        {
            return;
        }

        var project = await _projectRepository.LoadProjectAsync(SelectedTemplate.TemplatePath).ConfigureAwait(true);
        if (project is null)
        {
            TemplateStatus = $"Template file missing: {SelectedTemplate.TemplatePath}";
            return;
        }

        ProductName = project.ProductName;
        CompanyName = project.CompanyName;
        Version = project.Version;
        Publisher = project.Publisher;
        InstallationFolder = project.InstallationFolder;
        OutputFolder = project.OutputFolder;
        SetupExecutableName = project.Build.SetupExecutableName;
        TemplateStatus = $"Applied template: {SelectedTemplate.Name}";
    }

    public InstallerProject CreateProject()
    {
        var project = ProjectFactory.Create(ProductName, CompanyName, Version, Publisher, InstallationFolder, OutputFolder);
        project.Build.SetupExecutableName = ProjectBuildSettings.NormalizeSetupExecutableName(SetupExecutableName);
        return project;
    }
}

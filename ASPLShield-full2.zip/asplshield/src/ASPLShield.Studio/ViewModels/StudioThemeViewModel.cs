using System.Collections.ObjectModel;
using ASPLShield.Common;
using WpfBrush = System.Windows.Media.Brush;

namespace ASPLShield.Studio;

public sealed class StudioThemeOption : ObservableObject
{
    private readonly IStudioThemeService _themeService;
    private StudioThemeKind _kind;

    public StudioThemeOption(IStudioThemeService themeService, StudioThemeKind kind, string displayName, WpfBrush previewBrush)
    {
        _themeService = themeService;
        _kind = kind;
        DisplayName = displayName;
        PreviewBrush = previewBrush;
    }

    public string DisplayName { get; }

    public WpfBrush PreviewBrush { get; }

    public bool IsSelected => _themeService.CurrentTheme == Kind;

    public StudioThemeKind Kind
    {
        get => _kind;
        set
        {
            if (SetProperty(ref _kind, value))
            {
                _themeService.ApplyTheme(value);
                OnPropertyChanged(nameof(IsSelected));
            }
        }
    }

    internal void RefreshSelectionState()
        => OnPropertyChanged(nameof(IsSelected));
}

public sealed class StudioThemeViewModel : ObservableObject
{
    private readonly IStudioThemeService _themeService;
    private readonly IStudioSettingsStore _settingsStore;
    private StudioThemeKind _selectedTheme;

    public StudioThemeViewModel(IStudioThemeService themeService, IStudioSettingsStore settingsStore)
    {
        _themeService = themeService;
        _settingsStore = settingsStore;
        Options = new ObservableCollection<StudioThemeOption>(
            _themeService.AvailableThemes.Select(kind => new StudioThemeOption(_themeService, kind, kind switch
            {
                StudioThemeKind.LightBlue => "Light Blue",
                StudioThemeKind.Midnight => "Midnight",
                StudioThemeKind.Sandstone => "Sandstone",
                StudioThemeKind.Blush => "Light Pink",
                _ => kind.ToString()
            }, _themeService.GetPreviewBrush(kind))));

        _selectedTheme = _themeService.CurrentTheme;
        SelectThemeCommand = new RelayCommand(parameter =>
        {
            if (parameter is StudioThemeOption option)
            {
                SelectedTheme = option.Kind;
            }
            else if (parameter is StudioThemeKind themeKind)
            {
                SelectedTheme = themeKind;
            }
        });
    }

    public ObservableCollection<StudioThemeOption> Options { get; }

    public RelayCommand SelectThemeCommand { get; }

    public StudioThemeKind SelectedTheme
    {
        get => _selectedTheme;
        set
        {
            if (SetProperty(ref _selectedTheme, value))
            {
                _themeService.ApplyTheme(value);
                foreach (var option in Options)
                {
                    option.RefreshSelectionState();
                }
                _ = _settingsStore.SetThemeAsync(value);
            }
        }
    }
}
using System.Collections.ObjectModel;
using ASPLShield.Common;

namespace ASPLShield.Studio;

/// <summary>
/// Backs the "Select Files to Add" dialog shown from the Files tab's Add Folder button. Presents
/// a checkable folder/file tree rooted at the chosen folder so the person can pick specific files
/// out of a large directory (e.g. a subset of C:\Windows\System32) instead of importing everything.
/// </summary>
public sealed class SelectFolderFilesViewModel : ObservableObject
{
    public SelectFolderFilesViewModel(string rootPath)
    {
        RootPath = rootPath;

        var rootName = Path.GetFileName(rootPath.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
        Root = new FolderPickerNode(rootPath, string.IsNullOrEmpty(rootName) ? rootPath : rootName, isDirectory: true, parent: null);
        Root.IsExpanded = true;

        RootItems = new ObservableCollection<FolderPickerNode> { Root };

        SelectAllCommand = new RelayCommand(_ => Root.IsChecked = true);
        SelectNoneCommand = new RelayCommand(_ => Root.IsChecked = false);
    }

    public string RootPath { get; }

    public FolderPickerNode Root { get; }

    public ObservableCollection<FolderPickerNode> RootItems { get; }

    public RelayCommand SelectAllCommand { get; }

    public RelayCommand SelectNoneCommand { get; }

    public bool IsConfirmed { get; set; }

    /// <summary>
    /// Walks the tree's checked state and returns every selected file as an (absolute source path,
    /// path relative to <see cref="RootPath"/> using '/' separators) pair. A directory that is fully
    /// checked but was never expanded in the UI is read straight from disk rather than requiring the
    /// whole subtree to have been loaded first.
    /// </summary>
    public List<(string FullPath, string RelativePath)> GetSelectedFiles()
    {
        var results = new List<(string, string)>();
        foreach (var child in Root.Children)
        {
            Collect(child, results);
        }

        return results;
    }

    private void Collect(FolderPickerNode node, List<(string FullPath, string RelativePath)> results)
    {
        if (node.IsPlaceholder || node.IsChecked == false)
        {
            return;
        }

        if (!node.IsDirectory)
        {
            results.Add((node.FullPath, ToRelativePath(node.FullPath)));
            return;
        }

        if (node.IsChecked == true && !node.ChildrenLoaded)
        {
            foreach (var file in EnumerateFilesSafe(node.FullPath))
            {
                results.Add((file, ToRelativePath(file)));
            }

            return;
        }

        foreach (var child in node.Children)
        {
            Collect(child, results);
        }
    }

    private string ToRelativePath(string fullPath)
        => Path.GetRelativePath(RootPath, fullPath).Replace('\\', '/');

    private static List<string> EnumerateFilesSafe(string path)
    {
        var results = new List<string>();
        var pending = new Stack<string>();
        pending.Push(path);

        while (pending.Count > 0)
        {
            var current = pending.Pop();

            try
            {
                results.AddRange(Directory.GetFiles(current));

                foreach (var directory in Directory.GetDirectories(current))
                {
                    pending.Push(directory);
                }
            }
            catch (UnauthorizedAccessException)
            {
            }
            catch (IOException)
            {
            }
        }

        return results;
    }
}

using System.Collections.ObjectModel;
using ASPLShield.Common;

namespace ASPLShield.Studio;

/// <summary>
/// A single folder or file node in the "Select Files to Add" tree (Files tab &gt; Add Folder).
/// Mirrors the tri-state checking behaviour of <see cref="FeatureTreeNode"/>, but is backed by
/// the real filesystem instead of project data, and loads a directory's children lazily — only
/// when the node is expanded — so pointing the picker at something like C:\Windows\System32
/// doesn't walk the entire subtree up front.
/// </summary>
public sealed class FolderPickerNode : ObservableObject
{
    private bool? _isChecked;
    private bool _isExpanded;
    private bool _childrenLoaded;

    public FolderPickerNode(string fullPath, string name, bool isDirectory, FolderPickerNode? parent, bool initiallyChecked = false)
    {
        FullPath = fullPath;
        Name = name;
        IsDirectory = isDirectory;
        Parent = parent;
        _isChecked = initiallyChecked;

        if (isDirectory)
        {
            // A single dummy child gives the TreeViewItem an expand arrow before we know
            // whether the directory actually has anything in it.
            Children.Add(new FolderPickerNode(string.Empty, "Loading…", false, this) { IsPlaceholder = true });
        }
    }

    public string FullPath { get; }

    public string Name { get; }

    public bool IsDirectory { get; }

    public FolderPickerNode? Parent { get; }

    public bool IsPlaceholder { get; private init; }

    public ObservableCollection<FolderPickerNode> Children { get; } = new();

    /// <summary>True once <see cref="Children"/> reflects the real directory contents (or the load failed/was empty).</summary>
    public bool ChildrenLoaded => _childrenLoaded;

    public string IconText => IsDirectory ? "FD" : "FI";

    public bool? IsChecked
    {
        get => _isChecked;
        set => SetIsChecked(value, updateChildren: true, updateParent: true);
    }

    public bool IsExpanded
    {
        get => _isExpanded;
        set
        {
            if (SetProperty(ref _isExpanded, value) && value && IsDirectory && !_childrenLoaded)
            {
                LoadChildren();
            }
        }
    }

    public void SetIsChecked(bool? value, bool updateChildren, bool updateParent)
    {
        if (value == _isChecked)
        {
            return;
        }

        _isChecked = value;

        if (updateChildren && _isChecked.HasValue)
        {
            foreach (var child in Children)
            {
                if (child.IsPlaceholder)
                {
                    continue;
                }

                child.SetIsChecked(_isChecked, updateChildren: true, updateParent: false);
            }
        }

        if (updateParent)
        {
            Parent?.RecomputeFromChildren();
        }

        OnPropertyChanged(nameof(IsChecked));
    }

    private void RecomputeFromChildren()
    {
        bool? state = null;
        var first = true;

        foreach (var child in Children)
        {
            if (child.IsPlaceholder)
            {
                continue;
            }

            if (first)
            {
                state = child.IsChecked;
                first = false;
            }
            else if (state != child.IsChecked)
            {
                state = null;
                break;
            }
        }

        if (!first)
        {
            SetIsChecked(state, updateChildren: false, updateParent: true);
        }
    }

    private void LoadChildren()
    {
        Children.Clear();

        try
        {
            var directories = Directory.EnumerateDirectories(FullPath)
                .OrderBy(d => Path.GetFileName(d), StringComparer.OrdinalIgnoreCase);

            foreach (var directory in directories)
            {
                Children.Add(new FolderPickerNode(directory, Path.GetFileName(directory), true, this, _isChecked ?? false));
            }

            var files = Directory.EnumerateFiles(FullPath)
                .OrderBy(f => Path.GetFileName(f), StringComparer.OrdinalIgnoreCase);

            foreach (var file in files)
            {
                Children.Add(new FolderPickerNode(file, Path.GetFileName(file), false, this, _isChecked ?? false));
            }
        }
        catch (UnauthorizedAccessException)
        {
            // A restricted subfolder (common under system directories) — leave it empty
            // rather than failing the whole tree.
        }
        catch (IOException)
        {
        }

        _childrenLoaded = true;
    }
}

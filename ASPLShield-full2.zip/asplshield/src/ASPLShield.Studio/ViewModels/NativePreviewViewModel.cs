using System.Collections.ObjectModel;
using ASPLShield.Build;
using ASPLShield.Common;
using ASPLShield.Core;

namespace ASPLShield.Studio;

public sealed class NativePreviewViewModel : ObservableObject
{
    private string _planPath = string.Empty;
    private string _databasePath = string.Empty;
    private string _summary = "No native preview plan available.";
    private NativePreviewTableViewModel? _selectedTable;
    private NativePreviewOperationViewModel? _selectedOperation;

    public NativePreviewViewModel()
    {
        AddOperationCommand = new RelayCommand(_ => AddOperation(), _ => true);
        RemoveOperationCommand = new RelayCommand(_ => RemoveSelectedOperation(), _ => SelectedOperation is not null);
        MoveOperationUpCommand = new RelayCommand(_ => MoveSelectedOperation(-1), _ => CanMoveSelectedOperation(-1));
        MoveOperationDownCommand = new RelayCommand(_ => MoveSelectedOperation(1), _ => CanMoveSelectedOperation(1));
    }

    public string PlanPath
    {
        get => _planPath;
        private set => SetProperty(ref _planPath, value);
    }

    public string DatabasePath
    {
        get => _databasePath;
        private set => SetProperty(ref _databasePath, value);
    }

    public string Summary
    {
        get => _summary;
        private set => SetProperty(ref _summary, value);
    }

    public ObservableCollection<NativePreviewTableViewModel> Tables { get; } = new();

    public ObservableCollection<NativePreviewRowViewModel> SelectedRows { get; } = new();

    public ObservableCollection<string> Highlights { get; } = new();

    public ObservableCollection<NativePreviewOperationViewModel> Operations { get; } = new();

    public RelayCommand AddOperationCommand { get; }

    public RelayCommand RemoveOperationCommand { get; }

    public RelayCommand MoveOperationUpCommand { get; }

    public RelayCommand MoveOperationDownCommand { get; }

    public NativePreviewTableViewModel? SelectedTable
    {
        get => _selectedTable;
        set
        {
            if (SetProperty(ref _selectedTable, value))
            {
                SyncSelectedRows();
            }
        }
    }

    public NativePreviewOperationViewModel? SelectedOperation
    {
        get => _selectedOperation;
        set
        {
            if (SetProperty(ref _selectedOperation, value))
            {
                RemoveOperationCommand.RaiseCanExecuteChanged();
                MoveOperationUpCommand.RaiseCanExecuteChanged();
                MoveOperationDownCommand.RaiseCanExecuteChanged();
            }
        }
    }

    public void Refresh()
    {
        OnPropertyChanged(nameof(PlanPath));
        OnPropertyChanged(nameof(DatabasePath));
        OnPropertyChanged(nameof(Summary));
        OnPropertyChanged(nameof(Tables));
        OnPropertyChanged(nameof(SelectedRows));
        OnPropertyChanged(nameof(Highlights));
        OnPropertyChanged(nameof(Operations));
        OnPropertyChanged(nameof(SelectedTable));
        OnPropertyChanged(nameof(SelectedOperation));
    }

    public void ApplyPlan(NativeMsiAuthoringPlan plan, string planPath, string? databasePath)
    {
        PlanPath = planPath;
        DatabasePath = databasePath ?? string.Empty;
        Summary = $"{plan.ProductName} {plan.Version} | {plan.Tables.Count} tables | {plan.FileCount} files | {plan.ShortcutCount} shortcuts | {plan.RegistryCount} registry entries | {plan.ServiceCount} services | {plan.IisSiteCount} IIS sites";

        Highlights.Clear();
        Highlights.Add($"Install folder: {plan.InstallFolder}");
        Highlights.Add($"Publisher: {plan.Publisher}");
        Highlights.Add($"Company: {plan.CompanyName}");

        Tables.Clear();
        foreach (var table in plan.Tables)
        {
            Tables.Add(new NativePreviewTableViewModel
            {
                Name = table.Name,
                RowCount = table.Rows.Count,
                Preview = table.Rows.Count == 0 ? "No rows" : string.Join(" | ", table.Rows.First().Columns.Take(3).Select(pair => $"{pair.Key}={pair.Value}")),
                Rows = new ObservableCollection<NativePreviewRowViewModel>(table.Rows.Select((row, index) => new NativePreviewRowViewModel
                {
                    Index = index + 1,
                    ColumnCount = row.Columns.Count,
                    Summary = string.Join(" | ", row.Columns.Select(pair => $"{pair.Key}={pair.Value}"))
                }))
            });
        }

        SelectedTable = Tables.FirstOrDefault();
        SyncSelectedRows();
        Operations.Clear();
        foreach (var operation in plan.Tables.SelectMany(table => table.Rows.Select((row, index) => new NativePreviewOperationViewModel
        {
            Sequence = Operations.Count + 1,
            Operation = "InsertRow",
            Table = table.Name,
            PrimaryKey = row.Columns.TryGetValue(table.Name, out var key) ? key : $"{table.Name}_{index + 1}",
            Summary = string.Join(" | ", row.Columns.Select(pair => $"{pair.Key}={pair.Value}"))
        })))
        {
            Operations.Add(operation);
        }
        SelectedOperation = Operations.FirstOrDefault();
        OnPropertyChanged(nameof(PlanPath));
        OnPropertyChanged(nameof(DatabasePath));
        OnPropertyChanged(nameof(Summary));
        OnPropertyChanged(nameof(Tables));
        OnPropertyChanged(nameof(SelectedRows));
        OnPropertyChanged(nameof(Highlights));
        OnPropertyChanged(nameof(Operations));
        OnPropertyChanged(nameof(SelectedTable));
        OnPropertyChanged(nameof(SelectedOperation));
    }

    public void ApplyDatabase(NativeMsiDatabase database, string planPath, string databasePath)
    {
        var plan = new NativeMsiAuthoringPlan
        {
            ProductName = database.ProductName,
            Version = database.Version,
            Publisher = database.Publisher,
            InstallFolder = database.InstallFolder,
            Tables = database.Tables.Select(table => new NativeMsiTableAuthoring
            {
                Name = table.Name,
                Rows = table.Rows.Select(row => new NativeMsiTableRow
                {
                    Columns = new Dictionary<string, string>(row.Columns, StringComparer.OrdinalIgnoreCase)
                }).ToList()
            }).ToList(),
            FileCount = database.Tables.FirstOrDefault(table => table.Name.Equals("File", StringComparison.OrdinalIgnoreCase))?.Rows.Count ?? 0,
            ShortcutCount = database.Tables.FirstOrDefault(table => table.Name.Equals("Shortcut", StringComparison.OrdinalIgnoreCase))?.Rows.Count ?? 0,
            RegistryCount = database.Tables.FirstOrDefault(table => table.Name.Equals("Registry", StringComparison.OrdinalIgnoreCase))?.Rows.Count ?? 0,
            ServiceCount = database.Tables.FirstOrDefault(table => table.Name.Equals("ServiceInstall", StringComparison.OrdinalIgnoreCase))?.Rows.Count ?? 0,
            IisSiteCount = database.Tables.FirstOrDefault(table => table.Name.Equals("NativeIisSite", StringComparison.OrdinalIgnoreCase))?.Rows.Count ?? 0
        };

        ApplyPlan(plan, planPath, databasePath);

        Operations.Clear();
        foreach (var operation in database.Operations)
        {
            Operations.Add(new NativePreviewOperationViewModel
            {
                Sequence = operation.Sequence,
                Operation = operation.Operation,
                Table = operation.Table,
                PrimaryKey = operation.PrimaryKey,
                Summary = string.Join(" | ", operation.Payload.Select(pair => $"{pair.Key}={pair.Value}"))
            });
        }
        SelectedOperation = Operations.FirstOrDefault();
        OnPropertyChanged(nameof(Operations));
    }

    public void Clear()
    {
        PlanPath = string.Empty;
        DatabasePath = string.Empty;
        Summary = "No native preview plan available.";
        Highlights.Clear();
        Tables.Clear();
        SelectedRows.Clear();
        Operations.Clear();
        SelectedTable = null;
        SelectedOperation = null;
        OnPropertyChanged(nameof(PlanPath));
        OnPropertyChanged(nameof(DatabasePath));
        OnPropertyChanged(nameof(Summary));
        OnPropertyChanged(nameof(Tables));
        OnPropertyChanged(nameof(SelectedRows));
        OnPropertyChanged(nameof(Highlights));
        OnPropertyChanged(nameof(Operations));
        OnPropertyChanged(nameof(SelectedTable));
        OnPropertyChanged(nameof(SelectedOperation));
    }

    private void SyncSelectedRows()
    {
        SelectedRows.Clear();
        if (SelectedTable is null)
        {
            return;
        }

        foreach (var row in SelectedTable.Rows)
        {
            SelectedRows.Add(row);
        }
    }

    private void AddOperation()
    {
        var operation = new NativePreviewOperationViewModel
        {
            Sequence = Operations.Count + 1,
            Operation = "InsertRow",
            Table = SelectedTable?.Name ?? "Property",
            PrimaryKey = string.Empty,
            Summary = string.Empty
        };

        Operations.Add(operation);
        SelectedOperation = operation;
        RenumberOperations();
        OnPropertyChanged(nameof(Operations));
    }

    private void RemoveSelectedOperation()
    {
        if (SelectedOperation is null)
        {
            return;
        }

        Operations.Remove(SelectedOperation);
        RenumberOperations();
        SelectedOperation = Operations.FirstOrDefault();
        OnPropertyChanged(nameof(Operations));
    }

    private bool CanMoveSelectedOperation(int delta)
    {
        if (SelectedOperation is null)
        {
            return false;
        }

        var index = Operations.IndexOf(SelectedOperation);
        return delta < 0 ? index > 0 : index >= 0 && index < Operations.Count - 1;
    }

    private void MoveSelectedOperation(int delta)
    {
        if (SelectedOperation is null)
        {
            return;
        }

        var index = Operations.IndexOf(SelectedOperation);
        var newIndex = index + delta;
        if (index < 0 || newIndex < 0 || newIndex >= Operations.Count)
        {
            return;
        }

        Operations.Move(index, newIndex);
        RenumberOperations();
        OnPropertyChanged(nameof(Operations));
        MoveOperationUpCommand.RaiseCanExecuteChanged();
        MoveOperationDownCommand.RaiseCanExecuteChanged();
    }

    private void RenumberOperations()
    {
        for (var i = 0; i < Operations.Count; i++)
        {
            Operations[i].Sequence = i + 1;
        }
    }

    public void LoadFromProject(InstallerProject project)
    {
        ArgumentNullException.ThrowIfNull(project);

        MergePersistedOperations(project.NativePreviewOperations);
        OnPropertyChanged(nameof(Operations));
        OnPropertyChanged(nameof(SelectedOperation));
    }

    public void SaveToProject(InstallerProject project)
    {
        ArgumentNullException.ThrowIfNull(project);

        project.NativePreviewOperations.Clear();
        foreach (var operation in Operations)
        {
            project.NativePreviewOperations.Add(ToEntry(operation));
        }
    }

    public void MergePersistedOperations(IEnumerable<NativePreviewOperationEntry> persistedOperations)
    {
        if (!Operations.Any())
        {
            foreach (var entry in persistedOperations.OrderBy(entry => entry.Sequence))
            {
                Operations.Add(FromEntry(entry));
            }

            SelectedOperation = Operations.FirstOrDefault();
            OnPropertyChanged(nameof(Operations));
            return;
        }

        var lookup = persistedOperations
            .GroupBy(entry => entry.Sequence)
            .ToDictionary(group => group.Key, group => group.First());

        var changed = false;
        foreach (var operation in Operations)
        {
            if (!lookup.TryGetValue(operation.Sequence, out var persisted))
            {
                continue;
            }

            operation.Operation = persisted.Operation;
            operation.Table = persisted.Table;
            operation.PrimaryKey = persisted.PrimaryKey;
            operation.Summary = persisted.Summary;
            changed = true;
        }

        if (changed)
        {
            OnPropertyChanged(nameof(Operations));
            OnPropertyChanged(nameof(SelectedOperation));
        }
    }

    private static NativePreviewOperationEntry ToEntry(NativePreviewOperationViewModel operation)
        => new()
        {
            Sequence = operation.Sequence,
            Operation = operation.Operation,
            Table = operation.Table,
            PrimaryKey = operation.PrimaryKey,
            Summary = operation.Summary
        };

    private static NativePreviewOperationViewModel FromEntry(NativePreviewOperationEntry entry)
        => new()
        {
            Sequence = entry.Sequence,
            Operation = entry.Operation,
            Table = entry.Table,
            PrimaryKey = entry.PrimaryKey,
            Summary = entry.Summary
        };
}

public sealed class NativePreviewOperationViewModel : ObservableObject
{
    private int _sequence;
    private string _operation = string.Empty;
    private string _table = string.Empty;
    private string _primaryKey = string.Empty;
    private string _summary = string.Empty;

    public int Sequence
    {
        get => _sequence;
        set => SetProperty(ref _sequence, value);
    }

    public string Operation
    {
        get => _operation;
        set => SetProperty(ref _operation, value);
    }

    public string Table
    {
        get => _table;
        set => SetProperty(ref _table, value);
    }

    public string PrimaryKey
    {
        get => _primaryKey;
        set => SetProperty(ref _primaryKey, value);
    }

    public string Summary
    {
        get => _summary;
        set => SetProperty(ref _summary, value);
    }
}

public sealed class NativePreviewTableViewModel : ObservableObject
{
    private string _name = string.Empty;
    private int _rowCount;
    private string _preview = string.Empty;

    public string Name
    {
        get => _name;
        set => SetProperty(ref _name, value);
    }

    public int RowCount
    {
        get => _rowCount;
        set => SetProperty(ref _rowCount, value);
    }

    public string Preview
    {
        get => _preview;
        set => SetProperty(ref _preview, value);
    }

    public ObservableCollection<NativePreviewRowViewModel> Rows { get; set; } = new();
}

public sealed class NativePreviewRowViewModel : ObservableObject
{
    private int _index;
    private int _columnCount;
    private string _summary = string.Empty;

    public int Index
    {
        get => _index;
        set => SetProperty(ref _index, value);
    }

    public int ColumnCount
    {
        get => _columnCount;
        set => SetProperty(ref _columnCount, value);
    }

    public string Summary
    {
        get => _summary;
        set => SetProperty(ref _summary, value);
    }
}

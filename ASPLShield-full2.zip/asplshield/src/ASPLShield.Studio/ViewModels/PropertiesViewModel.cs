using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using ASPLShield.Build;
using ASPLShield.Common;
using ASPLShield.Core;

namespace ASPLShield.Studio;

public sealed class PropertiesViewModel : ObservableObject
{
    public PropertiesViewModel(
        IIntegrationSettingsStore integrationSettingsStore,
        IFileDialogService fileDialogs,
        ISelectPrerequisiteDialogService selectPrerequisiteDialogService)
    {
        ProjectEditor = new ProjectPropertiesEditorViewModel();
        FileEditor = new FilePropertiesEditorViewModel();
        ShortcutEditor = new ShortcutPropertiesEditorViewModel();
        PrerequisiteEditor = new PrerequisiteEditorViewModel(selectPrerequisiteDialogService);
        BuildEditor = new BuildPropertiesEditorViewModel(fileDialogs);
        Integration = new IntegrationSettingsViewModel(integrationSettingsStore);
        NativePreview = new NativePreviewViewModel();
    }

    public ProjectPropertiesEditorViewModel ProjectEditor { get; }

    public FilePropertiesEditorViewModel FileEditor { get; }

    public ShortcutPropertiesEditorViewModel ShortcutEditor { get; }

    public PrerequisiteEditorViewModel PrerequisiteEditor { get; }

    public BuildPropertiesEditorViewModel BuildEditor { get; }

    public IntegrationSettingsViewModel Integration { get; }

    public NativePreviewViewModel NativePreview { get; }

    public void Bind(
        Func<InstallerProject> projectAccessor,
        Func<InstallerFile?> selectedFileAccessor,
        Func<InstallerShortcut?> selectedShortcutAccessor)
    {
        ProjectEditor.Bind(projectAccessor);
        FileEditor.Bind(selectedFileAccessor);
        ShortcutEditor.Bind(selectedShortcutAccessor);
        PrerequisiteEditor.Bind(projectAccessor);
        BuildEditor.Bind(projectAccessor);
        Refresh();
    }

    public string ProjectSummary => ProjectEditor.Project is null
        ? "No project loaded"
        : $"{ProjectEditor.Project.ProductName} {ProjectEditor.Project.Version} by {ProjectEditor.Project.Publisher}";

    public void Refresh()
    {
        ProjectEditor.Refresh();
        FileEditor.Refresh();
        ShortcutEditor.Refresh();
        PrerequisiteEditor.Refresh();
        BuildEditor.Refresh();
        // Integration settings are refreshed separately to avoid feeding the
        // parent refresh loop back into MainViewModel.RefreshAll().
        Integration.Refresh(false);
        NativePreview.Refresh();
        OnPropertyChanged(nameof(ProjectSummary));
        OnPropertyChanged(nameof(ProjectEditor));
        OnPropertyChanged(nameof(FileEditor));
        OnPropertyChanged(nameof(ShortcutEditor));
        OnPropertyChanged(nameof(PrerequisiteEditor));
        OnPropertyChanged(nameof(BuildEditor));
        OnPropertyChanged(nameof(Integration));
        OnPropertyChanged(nameof(NativePreview));
    }

    public void NotifyChanged() => Refresh();
}

public sealed class ProjectPropertiesEditorViewModel : ObservableObject
{
    private Func<InstallerProject>? _projectAccessor;
    private bool _productNameError;
    private bool _companyNameError;
    private bool _versionError;
    private bool _publisherError;
    private bool _installationFolderError;
    private bool _outputFolderError;

    public void Bind(Func<InstallerProject> projectAccessor)
    {
        _projectAccessor = projectAccessor;
    }

    public InstallerProject? Project => _projectAccessor?.Invoke();

    public string? ProductName
    {
        get => Project?.ProductName;
        set
        {
            if (Project is not null && value is not null)
            {
                Project.ProductName = value;
                OnPropertyChanged();
            }
        }
    }

    public string? CompanyName
    {
        get => Project?.CompanyName;
        set
        {
            if (Project is not null && value is not null)
            {
                Project.CompanyName = value;
                OnPropertyChanged();
            }
        }
    }

    public string? Version
    {
        get => Project?.Version;
        set
        {
            if (Project is not null && value is not null)
            {
                Project.Version = value;
                OnPropertyChanged();
            }
        }
    }

    public string? Publisher
    {
        get => Project?.Publisher;
        set
        {
            if (Project is not null && value is not null)
            {
                Project.Publisher = value;
                OnPropertyChanged();
            }
        }
    }

    public string? InstallationFolder
    {
        get => Project?.InstallationFolder;
        set
        {
            if (Project is not null && value is not null)
            {
                Project.InstallationFolder = value;
                OnPropertyChanged();
            }
        }
    }

    public string? OutputFolder
    {
        get => Project?.OutputFolder;
        set
        {
            if (Project is not null && value is not null)
            {
                Project.OutputFolder = value;
                OnPropertyChanged();
            }
        }
    }

    public bool ProductNameError { get => _productNameError; set => SetProperty(ref _productNameError, value); }

    public bool CompanyNameError { get => _companyNameError; set => SetProperty(ref _companyNameError, value); }

    public bool VersionError { get => _versionError; set => SetProperty(ref _versionError, value); }

    public bool PublisherError { get => _publisherError; set => SetProperty(ref _publisherError, value); }

    public bool InstallationFolderError { get => _installationFolderError; set => SetProperty(ref _installationFolderError, value); }

    public bool OutputFolderError { get => _outputFolderError; set => SetProperty(ref _outputFolderError, value); }

    public bool HasErrors => ProductNameError || CompanyNameError || VersionError || PublisherError || InstallationFolderError || OutputFolderError;

    public void Refresh()
    {
        OnPropertyChanged(nameof(Project));
        OnPropertyChanged(nameof(ProductName));
        OnPropertyChanged(nameof(CompanyName));
        OnPropertyChanged(nameof(Version));
        OnPropertyChanged(nameof(Publisher));
        OnPropertyChanged(nameof(InstallationFolder));
        OnPropertyChanged(nameof(OutputFolder));
        OnPropertyChanged(nameof(HasErrors));
    }
}

public sealed class FilePropertiesEditorViewModel : ObservableObject
{
    private Func<InstallerFile?>? _selectedFileAccessor;
    private bool _displayNameError;
    private bool _sourcePathError;
    private bool _destinationPathError;

    public void Bind(Func<InstallerFile?> selectedFileAccessor)
    {
        _selectedFileAccessor = selectedFileAccessor;
    }

    public InstallerFile? SelectedFile => _selectedFileAccessor?.Invoke();

    public string? DisplayName
    {
        get => SelectedFile?.DisplayName;
        set
        {
            if (SelectedFile is not null && value is not null)
            {
                SelectedFile.DisplayName = value;
                OnPropertyChanged();
            }
        }
    }

    public string? SourcePath
    {
        get => SelectedFile?.SourcePath;
        set
        {
            if (SelectedFile is not null && value is not null)
            {
                SelectedFile.SourcePath = value;
                OnPropertyChanged();
            }
        }
    }

    public string? DestinationPath
    {
        get => SelectedFile?.DestinationPath;
        set
        {
            if (SelectedFile is not null && value is not null)
            {
                SelectedFile.DestinationPath = value;
                OnPropertyChanged();
            }
        }
    }

    public long? SizeBytes
    {
        get => SelectedFile?.SizeBytes;
        set
        {
            if (SelectedFile is not null && value.HasValue)
            {
                SelectedFile.SizeBytes = value.Value;
                OnPropertyChanged();
            }
        }
    }

    public bool? IsFolder
    {
        get => SelectedFile?.IsFolder;
        set
        {
            if (SelectedFile is not null && value.HasValue)
            {
                SelectedFile.IsFolder = value.Value;
                OnPropertyChanged();
            }
        }
    }

    public bool DisplayNameError { get => _displayNameError; set => SetProperty(ref _displayNameError, value); }

    public bool SourcePathError { get => _sourcePathError; set => SetProperty(ref _sourcePathError, value); }

    public bool DestinationPathError { get => _destinationPathError; set => SetProperty(ref _destinationPathError, value); }

    public bool HasSelection => SelectedFile is not null;

    public bool HasErrors => DisplayNameError || SourcePathError || DestinationPathError;

    public void Refresh()
    {
        OnPropertyChanged(nameof(SelectedFile));
        OnPropertyChanged(nameof(HasSelection));
        OnPropertyChanged(nameof(DisplayName));
        OnPropertyChanged(nameof(SourcePath));
        OnPropertyChanged(nameof(DestinationPath));
        OnPropertyChanged(nameof(SizeBytes));
        OnPropertyChanged(nameof(IsFolder));
        OnPropertyChanged(nameof(HasErrors));
    }
}

public sealed class ShortcutPropertiesEditorViewModel : ObservableObject
{
    private Func<InstallerShortcut?>? _selectedShortcutAccessor;
    private bool _nameError;
    private bool _targetPathError;

    public void Bind(Func<InstallerShortcut?> selectedShortcutAccessor)
    {
        _selectedShortcutAccessor = selectedShortcutAccessor;
    }

    public InstallerShortcut? SelectedShortcut => _selectedShortcutAccessor?.Invoke();

    public string? Name
    {
        get => SelectedShortcut?.Name;
        set
        {
            if (SelectedShortcut is not null && value is not null)
            {
                SelectedShortcut.Name = value;
                OnPropertyChanged();
            }
        }
    }

    public string? TargetPath
    {
        get => SelectedShortcut?.TargetPath;
        set
        {
            if (SelectedShortcut is not null && value is not null)
            {
                SelectedShortcut.TargetPath = value;
                OnPropertyChanged();
            }
        }
    }

    public string? Arguments
    {
        get => SelectedShortcut?.Arguments;
        set
        {
            if (SelectedShortcut is not null && value is not null)
            {
                SelectedShortcut.Arguments = value;
                OnPropertyChanged();
            }
        }
    }

    public string? WorkingDirectory
    {
        get => SelectedShortcut?.WorkingDirectory;
        set
        {
            if (SelectedShortcut is not null && value is not null)
            {
                SelectedShortcut.WorkingDirectory = value;
                OnPropertyChanged();
            }
        }
    }

    public string? Location
    {
        get => SelectedShortcut?.Location.ToString();
        set
        {
            if (SelectedShortcut is not null && Enum.TryParse<ShortcutLocation>(value, true, out var parsed))
            {
                SelectedShortcut.Location = parsed;
                OnPropertyChanged();
            }
        }
    }

    public bool NameError { get => _nameError; set => SetProperty(ref _nameError, value); }

    public bool TargetPathError { get => _targetPathError; set => SetProperty(ref _targetPathError, value); }

    public bool HasSelection => SelectedShortcut is not null;

    public bool HasErrors => NameError || TargetPathError;

    public void Refresh()
    {
        OnPropertyChanged(nameof(SelectedShortcut));
        OnPropertyChanged(nameof(HasSelection));
        OnPropertyChanged(nameof(Name));
        OnPropertyChanged(nameof(TargetPath));
        OnPropertyChanged(nameof(Arguments));
        OnPropertyChanged(nameof(WorkingDirectory));
        OnPropertyChanged(nameof(Location));
        OnPropertyChanged(nameof(HasErrors));
    }
}

public sealed class PrerequisiteEditorViewModel : ObservableObject
{
    private readonly ISelectPrerequisiteDialogService? _selectPrerequisiteDialogService;
    private Func<InstallerProject>? _projectAccessor;
    private PrerequisiteEntry? _selectedPrerequisite;
    private static readonly IReadOnlyList<string> TypeOptionsValue = Enum.GetNames<PrerequisiteType>();

    public event EventHandler? Changed;

    public ObservableCollection<PrerequisiteEntry> Prerequisites { get; } = new();

    public IReadOnlyList<string> TypeOptions => TypeOptionsValue;

    public RelayCommand AddPrerequisiteCommand { get; }

    public RelayCommand RemovePrerequisiteCommand { get; }

    public PrerequisiteEditorViewModel(ISelectPrerequisiteDialogService? selectPrerequisiteDialogService = null)
    {
        _selectPrerequisiteDialogService = selectPrerequisiteDialogService;
        AddPrerequisiteCommand = new RelayCommand(_ => AddPrerequisite(), _ => Project is not null);
        RemovePrerequisiteCommand = new RelayCommand(_ => RemovePrerequisite(), _ => SelectedPrerequisite is not null);
    }

    public InstallerProject? Project => _projectAccessor?.Invoke();

    public PrerequisiteEntry? SelectedPrerequisite
    {
        get => _selectedPrerequisite;
        set
        {
            if (SetProperty(ref _selectedPrerequisite, value))
            {
                NotifySelectionChanged();
            }
        }
    }

    public string? Name
    {
        get => SelectedPrerequisite?.Name;
        set
        {
            if (SelectedPrerequisite is not null && value is not null)
            {
                SelectedPrerequisite.Name = value;
                NotifyPrerequisiteUpdated();
            }
        }
    }

    public string? Version
    {
        get => SelectedPrerequisite?.Version;
        set
        {
            if (SelectedPrerequisite is not null && value is not null)
            {
                SelectedPrerequisite.Version = value;
                NotifyPrerequisiteUpdated();
            }
        }
    }

    public bool Required
    {
        get => SelectedPrerequisite?.Required ?? true;
        set
        {
            if (SelectedPrerequisite is not null)
            {
                SelectedPrerequisite.Required = value;
                NotifyPrerequisiteUpdated();
            }
        }
    }

    public string? Description
    {
        get => SelectedPrerequisite?.Description;
        set
        {
            if (SelectedPrerequisite is not null)
            {
                SelectedPrerequisite.Description = value;
                NotifyPrerequisiteUpdated();
            }
        }
    }

    public string TypeText
    {
        get => SelectedPrerequisite?.Type.ToString() ?? PrerequisiteType.Unknown.ToString();
        set
        {
            if (SelectedPrerequisite is not null && Enum.TryParse<PrerequisiteType>(value, true, out var parsed))
            {
                SelectedPrerequisite.Type = parsed;
                NotifyPrerequisiteUpdated();
            }
        }
    }

    public string TypeSummary => SelectedPrerequisite?.Type.ToString() ?? PrerequisiteType.Unknown.ToString();

    public string RemediationHint => SelectedPrerequisite?.Type switch
    {
        PrerequisiteType.FileExists => "Provide a file path that must exist before install.",
        PrerequisiteType.RegistryKey => "Provide a registry key path to detect the prerequisite.",
        PrerequisiteType.OperatingSystem => "Set a minimum Windows version, such as 10.0.19041.",
        PrerequisiteType.DotNetRuntime => "Set the minimum .NET runtime version to check for.",
        PrerequisiteType.Iis => "This check verifies IIS management tooling is available.",
        _ => "Select a prerequisite type to see guidance."
    };

    public string ValidationMessage => SelectedPrerequisite is null
        ? HasErrors
            ? "One or more prerequisites need attention. Select an item to review its validation details."
            : "Select a prerequisite to review validation details."
        : BuildValidationMessage(SelectedPrerequisite);

    public string? DetectionTarget
    {
        get => SelectedPrerequisite?.DetectionTarget;
        set
        {
            if (SelectedPrerequisite is not null)
            {
                SelectedPrerequisite.DetectionTarget = value;
                NotifyPrerequisiteUpdated();
            }
        }
    }

    public string? MinimumVersion
    {
        get => SelectedPrerequisite?.MinimumVersion;
        set
        {
            if (SelectedPrerequisite is not null)
            {
                SelectedPrerequisite.MinimumVersion = value;
                NotifyPrerequisiteUpdated();
            }
        }
    }

    public string? ExpectedValue
    {
        get => SelectedPrerequisite?.ExpectedValue;
        set
        {
            if (SelectedPrerequisite is not null)
            {
                SelectedPrerequisite.ExpectedValue = value;
                NotifyPrerequisiteUpdated();
            }
        }
    }

    public bool HasSelection => SelectedPrerequisite is not null;

    public bool HasErrors => Prerequisites.Any(HasPrerequisiteError);

    public void Bind(Func<InstallerProject> projectAccessor)
    {
        _projectAccessor = projectAccessor;
        Refresh();
    }

    public void Refresh()
    {
        Prerequisites.Clear();
        var project = Project;
        if (project is not null)
        {
            foreach (var prerequisite in project.Prerequisites)
            {
                Prerequisites.Add(prerequisite);
            }
        }

        if (SelectedPrerequisite is not null && !Prerequisites.Contains(SelectedPrerequisite))
        {
            SelectedPrerequisite = Prerequisites.FirstOrDefault();
        }

        OnPropertyChanged(nameof(Project));
        OnPropertyChanged(nameof(HasSelection));
        OnPropertyChanged(nameof(Name));
        OnPropertyChanged(nameof(Version));
        OnPropertyChanged(nameof(Required));
        OnPropertyChanged(nameof(Description));
        OnPropertyChanged(nameof(TypeText));
        OnPropertyChanged(nameof(DetectionTarget));
        OnPropertyChanged(nameof(MinimumVersion));
        OnPropertyChanged(nameof(ExpectedValue));
        OnPropertyChanged(nameof(TypeSummary));
        OnPropertyChanged(nameof(RemediationHint));
        OnPropertyChanged(nameof(ValidationMessage));
        OnPropertyChanged(nameof(HasErrors));
        AddPrerequisiteCommand.RaiseCanExecuteChanged();
        RemovePrerequisiteCommand.RaiseCanExecuteChanged();
    }

    private void AddPrerequisite()
    {
        var project = Project;
        if (project is null)
        {
            return;
        }

        var toAdd = new List<PrerequisiteEntry>();

        var selection = _selectPrerequisiteDialogService?.ShowDialog();
        if (_selectPrerequisiteDialogService is not null)
        {
            // A dialog service is available: only proceed if the user made a choice.
            if (selection is null)
            {
                return;
            }

            if (selection.AddCustomRequested || selection.SelectedPrerequisites.Count == 0)
            {
                toAdd.Add(new PrerequisiteEntry
                {
                    Name = "New prerequisite",
                    Type = PrerequisiteType.DotNetRuntime,
                    Required = true,
                    Version = "1.0.0"
                });
            }
            else
            {
                toAdd.AddRange(selection.SelectedPrerequisites);
            }
        }
        else
        {
            // No dialog service wired up (e.g. design-time or tests): keep the old blank-add behavior.
            toAdd.Add(new PrerequisiteEntry
            {
                Name = "New prerequisite",
                Type = PrerequisiteType.DotNetRuntime,
                Required = true,
                Version = "1.0.0"
            });
        }

        foreach (var prerequisite in toAdd)
        {
            project.Prerequisites.Add(prerequisite);
            Prerequisites.Add(prerequisite);
            SelectedPrerequisite = prerequisite;
        }

        Changed?.Invoke(this, EventArgs.Empty);
    }

    private void RemovePrerequisite()
    {
        if (SelectedPrerequisite is null)
        {
            return;
        }

        var selected = SelectedPrerequisite;
        Project?.Prerequisites.Remove(selected);
        Prerequisites.Remove(selected);
        SelectedPrerequisite = Prerequisites.LastOrDefault();
        Changed?.Invoke(this, EventArgs.Empty);
    }

    private void NotifySelectionChanged()
    {
        OnPropertyChanged(nameof(HasSelection));
        OnPropertyChanged(nameof(Name));
        OnPropertyChanged(nameof(Version));
        OnPropertyChanged(nameof(Required));
        OnPropertyChanged(nameof(Description));
        OnPropertyChanged(nameof(TypeText));
        OnPropertyChanged(nameof(DetectionTarget));
        OnPropertyChanged(nameof(MinimumVersion));
        OnPropertyChanged(nameof(ExpectedValue));
        OnPropertyChanged(nameof(TypeSummary));
        OnPropertyChanged(nameof(RemediationHint));
        OnPropertyChanged(nameof(ValidationMessage));
        OnPropertyChanged(nameof(HasErrors));
        AddPrerequisiteCommand.RaiseCanExecuteChanged();
        RemovePrerequisiteCommand.RaiseCanExecuteChanged();
    }

    private void NotifyPrerequisiteUpdated()
    {
        OnPropertyChanged(nameof(Name));
        OnPropertyChanged(nameof(Version));
        OnPropertyChanged(nameof(Required));
        OnPropertyChanged(nameof(Description));
        OnPropertyChanged(nameof(TypeText));
        OnPropertyChanged(nameof(DetectionTarget));
        OnPropertyChanged(nameof(MinimumVersion));
        OnPropertyChanged(nameof(ExpectedValue));
        OnPropertyChanged(nameof(TypeSummary));
        OnPropertyChanged(nameof(RemediationHint));
        OnPropertyChanged(nameof(ValidationMessage));
        OnPropertyChanged(nameof(HasErrors));
        Changed?.Invoke(this, EventArgs.Empty);
    }

    private static bool HasPrerequisiteError(PrerequisiteEntry prerequisite)
    {
        if (string.IsNullOrWhiteSpace(prerequisite.Name))
        {
            return true;
        }

        return prerequisite.Type switch
        {
            PrerequisiteType.FileExists => string.IsNullOrWhiteSpace(prerequisite.DetectionTarget),
            PrerequisiteType.RegistryKey => string.IsNullOrWhiteSpace(prerequisite.DetectionTarget),
            PrerequisiteType.OperatingSystem => string.IsNullOrWhiteSpace(prerequisite.MinimumVersion) && string.IsNullOrWhiteSpace(prerequisite.Version),
            PrerequisiteType.DotNetRuntime => string.IsNullOrWhiteSpace(prerequisite.MinimumVersion) && string.IsNullOrWhiteSpace(prerequisite.Version),
            _ => false
        };
    }

    private static string BuildValidationMessage(PrerequisiteEntry prerequisite)
    {
        var issues = new List<string>();

        if (string.IsNullOrWhiteSpace(prerequisite.Name))
        {
            issues.Add("Name is required.");
        }

        switch (prerequisite.Type)
        {
            case PrerequisiteType.FileExists:
                if (string.IsNullOrWhiteSpace(prerequisite.DetectionTarget))
                {
                    issues.Add("Detection target is required for file checks.");
                }
                else
                {
                    issues.Add($"The file '{prerequisite.DetectionTarget}' must exist before install.");
                }
                break;
            case PrerequisiteType.RegistryKey:
                if (string.IsNullOrWhiteSpace(prerequisite.DetectionTarget))
                {
                    issues.Add("Detection target is required for registry checks.");
                }
                else
                {
                    issues.Add($"The registry path '{prerequisite.DetectionTarget}' must be present before install.");
                }
                break;
            case PrerequisiteType.OperatingSystem:
                if (string.IsNullOrWhiteSpace(prerequisite.MinimumVersion) && string.IsNullOrWhiteSpace(prerequisite.Version))
                {
                    issues.Add("Minimum version is required for operating system checks.");
                }
                else
                {
                    var version = !string.IsNullOrWhiteSpace(prerequisite.MinimumVersion) ? prerequisite.MinimumVersion : prerequisite.Version;
                    issues.Add($"Windows {version} or later is required.");
                }
                break;
            case PrerequisiteType.DotNetRuntime:
                if (string.IsNullOrWhiteSpace(prerequisite.MinimumVersion) && string.IsNullOrWhiteSpace(prerequisite.Version))
                {
                    issues.Add("Minimum version is required for .NET runtime checks.");
                }
                else
                {
                    var version = !string.IsNullOrWhiteSpace(prerequisite.MinimumVersion) ? prerequisite.MinimumVersion : prerequisite.Version;
                    issues.Add($".NET runtime {version} or later is required.");
                }
                break;
            case PrerequisiteType.Iis:
                issues.Add("IIS availability will be checked during setup.");
                break;
            default:
                issues.Add("Select a prerequisite type to generate validation guidance.");
                break;
        }

        if (issues.Count == 0)
        {
            return "This prerequisite is fully configured.";
        }

        return string.Join(" ", issues);
    }
}

public sealed class BuildPropertiesEditorViewModel : ObservableObject
{
    private readonly IFileDialogService _fileDialogs;
    private Func<InstallerProject>? _projectAccessor;
    private bool _setupProjectError;
    private bool _uninstallerProjectError;
    private bool _upgradeVersionMinError;
    private bool _upgradeVersionMaxError;
    private bool _upgradeActionPropertyError;
    private CustomScreenDefinition? _selectedCustomScreen;
    private CustomScreenControl? _selectedCustomControl;

    public event EventHandler? Changed;

    public BuildPropertiesEditorViewModel(IFileDialogService fileDialogs)
    {
        _fileDialogs = fileDialogs;
        BrowseOutputFolderCommand = new RelayCommand(_ => BrowseOutputFolder(), _ => Project is not null);
        BrowseIconPathCommand = new RelayCommand(_ => BrowseIconPath(), _ => Project is not null);
        BrowseLicensePathCommand = new RelayCommand(_ => BrowseLicensePath(), _ => Project is not null);
        BrowseCustomLogoPathCommand = new RelayCommand(_ => BrowseCustomLogoPath(), _ => Project is not null);
        BrowseBrandingBannerImagePathCommand = new RelayCommand(_ => BrowseBrandingBannerImagePath(), _ => Project is not null);
        BrowseBrandingWelcomeImagePathCommand = new RelayCommand(_ => BrowseBrandingWelcomeImagePath(), _ => Project is not null);
        PickBrandingAccentColorCommand = new RelayCommand(_ => PickBrandingAccentColor(), _ => Project is not null);
        PickBrandingWelcomeBackgroundColorCommand = new RelayCommand(_ => PickBrandingWelcomeBackgroundColor(), _ => Project is not null);
        PickCustomBrandColorCommand = new RelayCommand(_ => PickCustomBrandColor(), _ => Project is not null);
        AddCustomScreenCommand = new RelayCommand(_ => AddCustomScreen(), _ => Project is not null);
        RemoveCustomScreenCommand = new RelayCommand(_ => RemoveCustomScreen(), _ => SelectedCustomScreen is not null);
        AddCustomControlCommand = new RelayCommand(_ => AddCustomControl(), _ => CurrentCustomScreen is not null);
        RemoveCustomControlCommand = new RelayCommand(_ => RemoveCustomControl(), _ => CurrentCustomScreen is not null && SelectedCustomControl is not null);
    }

    public RelayCommand BrowseOutputFolderCommand { get; }

    public RelayCommand BrowseIconPathCommand { get; }

    public RelayCommand BrowseLicensePathCommand { get; }

    public RelayCommand BrowseCustomLogoPathCommand { get; }

    public RelayCommand BrowseBrandingBannerImagePathCommand { get; }

    public RelayCommand BrowseBrandingWelcomeImagePathCommand { get; }

    public RelayCommand PickBrandingAccentColorCommand { get; }

    public RelayCommand PickBrandingWelcomeBackgroundColorCommand { get; }

    public RelayCommand PickCustomBrandColorCommand { get; }

    public RelayCommand AddCustomScreenCommand { get; }
    public RelayCommand RemoveCustomScreenCommand { get; }
    public RelayCommand AddCustomControlCommand { get; }
    public RelayCommand RemoveCustomControlCommand { get; }

    public IReadOnlyList<CustomScreenControlType> CustomControlTypes { get; } = Enum.GetValues<CustomScreenControlType>();

    public ObservableCollection<CustomScreenDefinition> CustomScreens => Project?.CustomScreens ?? new();

    public CustomScreenDefinition? SelectedCustomScreen
    {
        get => _selectedCustomScreen;
        set
        {
            if (SetProperty(ref _selectedCustomScreen, value))
            {
                SelectedCustomControl = value?.Controls.FirstOrDefault();
                RemoveCustomScreenCommand.RaiseCanExecuteChanged();
                AddCustomControlCommand.RaiseCanExecuteChanged();
            }
        }
    }

    public CustomScreenControl? SelectedCustomControl
    {
        get => _selectedCustomControl;
        set
        {
            if (SetProperty(ref _selectedCustomControl, value))
            {
                RemoveCustomControlCommand.RaiseCanExecuteChanged();
            }
        }
    }

    private CustomScreenDefinition? CurrentCustomScreen
        => SelectedCustomScreen ?? Project?.CustomScreens.LastOrDefault();

    private void AddCustomScreen()
    {
        if (Project is null) return;
        var screen = new CustomScreenDefinition { Name = $"Screen {Project.CustomScreens.Count + 1}", Title = "Custom screen" };
        Project.CustomScreens.Add(screen);
        SelectedCustomScreen = screen;
        OnPropertyChanged(nameof(CustomScreens));
        Changed?.Invoke(this, EventArgs.Empty);
    }

    private void RemoveCustomScreen()
    {
        if (Project is null || SelectedCustomScreen is null) return;
        Project.CustomScreens.Remove(SelectedCustomScreen);
        SelectedCustomScreen = Project.CustomScreens.LastOrDefault();
        OnPropertyChanged(nameof(CustomScreens));
        Changed?.Invoke(this, EventArgs.Empty);
    }

    private void AddCustomControl()
    {
        var screen = CurrentCustomScreen;
        if (screen is null) return;
        var control = new CustomScreenControl { Label = "New control", Text = "New control" };
        screen.Controls.Add(control);
        SelectedCustomScreen = screen;
        SelectedCustomControl = control;
        Changed?.Invoke(this, EventArgs.Empty);
    }

    private void RemoveCustomControl()
    {
        var screen = CurrentCustomScreen;
        if (screen is null || SelectedCustomControl is null) return;
        screen.Controls.Remove(SelectedCustomControl);
        SelectedCustomControl = screen.Controls.LastOrDefault();
        Changed?.Invoke(this, EventArgs.Empty);
    }

    private void BrowseOutputFolder()
    {
        if (Project is null)
        {
            return;
        }

        var path = _fileDialogs.SelectFolder("Select the folder where Setup.exe and the package will be created", Project.OutputFolder);
        if (!string.IsNullOrWhiteSpace(path))
        {
            Project.OutputFolder = path;
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    private void BrowseIconPath()
    {
        var path = _fileDialogs.SelectSingleFile(
            "Select Package Icon",
            "Icon files (*.ico)|*.ico|All files (*.*)|*.*");

        if (!string.IsNullOrWhiteSpace(path))
        {
            IconPath = path;
        }
    }

    private void BrowseLicensePath()
    {
        var path = _fileDialogs.SelectSingleFile(
            "Select License File",
            "Rich Text Format (*.rtf)|*.rtf|Text files (*.txt)|*.txt|All files (*.*)|*.*");

        if (!string.IsNullOrWhiteSpace(path))
        {
            LicensePath = path;
        }
    }

    private void BrowseCustomLogoPath()
    {
        var path = _fileDialogs.SelectSingleFile(
            "Select Customer Logo (bmp/png, ~493x312 recommended)",
            "Image files (*.bmp;*.png)|*.bmp;*.png|All files (*.*)|*.*");

        if (!string.IsNullOrWhiteSpace(path))
        {
            CustomLogoPath = path;
        }
    }

    private void BrowseBrandingBannerImagePath()
    {
        var path = _fileDialogs.SelectSingleFile(
            "Select Banner Image (~494x58 recommended)",
            "Image files (*.png;*.jpg;*.jpeg;*.bmp)|*.png;*.jpg;*.jpeg;*.bmp|All files (*.*)|*.*");

        if (!string.IsNullOrWhiteSpace(path))
        {
            BrandingBannerImagePath = path;
        }
    }

    private void BrowseBrandingWelcomeImagePath()
    {
        var path = _fileDialogs.SelectSingleFile(
            "Select Welcome/Finish Image (~164x312 recommended)",
            "Image files (*.png;*.jpg;*.jpeg;*.bmp)|*.png;*.jpg;*.jpeg;*.bmp|All files (*.*)|*.*");

        if (!string.IsNullOrWhiteSpace(path))
        {
            BrandingWelcomeImagePath = path;
        }
    }

    private void PickBrandingAccentColor()
    {
        var color = _fileDialogs.SelectColor(BrandingAccentColorHex);
        if (!string.IsNullOrWhiteSpace(color))
        {
            BrandingAccentColorHex = color;
        }
    }

    private void PickBrandingWelcomeBackgroundColor()
    {
        var color = _fileDialogs.SelectColor(BrandingWelcomeBackgroundColorHex);
        if (!string.IsNullOrWhiteSpace(color))
        {
            BrandingWelcomeBackgroundColorHex = color;
        }
    }

    private void PickCustomBrandColor()
    {
        var color = _fileDialogs.SelectColor(CustomBrandColorHex);
        if (!string.IsNullOrWhiteSpace(color))
        {
            CustomBrandColorHex = color;
        }
    }

    public void Bind(Func<InstallerProject> projectAccessor)
    {
        _projectAccessor = projectAccessor;
        BrowseIconPathCommand.RaiseCanExecuteChanged();
        BrowseLicensePathCommand.RaiseCanExecuteChanged();
        BrowseCustomLogoPathCommand.RaiseCanExecuteChanged();
        BrowseBrandingBannerImagePathCommand.RaiseCanExecuteChanged();
        BrowseBrandingWelcomeImagePathCommand.RaiseCanExecuteChanged();
        PickBrandingAccentColorCommand.RaiseCanExecuteChanged();
        PickBrandingWelcomeBackgroundColorCommand.RaiseCanExecuteChanged();
        PickCustomBrandColorCommand.RaiseCanExecuteChanged();
        AddCustomScreenCommand.RaiseCanExecuteChanged();
        AddCustomControlCommand.RaiseCanExecuteChanged();
        RemoveCustomScreenCommand.RaiseCanExecuteChanged();
        RemoveCustomControlCommand.RaiseCanExecuteChanged();
        OnPropertyChanged(nameof(CustomScreens));
    }

    public InstallerProject? Project => _projectAccessor?.Invoke();

    public string? SetupProjectPath => StudioPaths.LocateRuntimeProjectPath();

    public string? UninstallerProjectPath => StudioPaths.LocateUninstallerProjectPath();

    public string MsiAuthoringModeText
    {
        get => Project?.Build.MsiAuthoringMode.ToString() ?? MsiAuthoringMode.Wix.ToString();
        set
        {
            if (Project is null)
            {
                return;
            }

            if (Enum.TryParse<MsiAuthoringMode>(value, true, out var parsed))
            {
                Project.Build.MsiAuthoringMode = parsed;
                OnPropertyChanged();
                Changed?.Invoke(this, EventArgs.Empty);
            }
        }
    }

    public bool IsWixModeSelected
    {
        get => Project?.Build.MsiAuthoringMode == MsiAuthoringMode.Wix;
        set
        {
            if (Project is null || !value)
            {
                return;
            }

            Project.Build.MsiAuthoringMode = MsiAuthoringMode.Wix;
            OnPropertyChanged(nameof(IsWixModeSelected));
            OnPropertyChanged(nameof(IsNativePreviewModeSelected));
            OnPropertyChanged(nameof(MsiAuthoringModeText));
            OnPropertyChanged(nameof(BuildSummary));
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    public bool IsNativePreviewModeSelected
    {
        get => Project?.Build.MsiAuthoringMode == MsiAuthoringMode.NativePreview;
        set
        {
            if (Project is null || !value)
            {
                return;
            }

            Project.Build.MsiAuthoringMode = MsiAuthoringMode.NativePreview;
            OnPropertyChanged(nameof(IsWixModeSelected));
            OnPropertyChanged(nameof(IsNativePreviewModeSelected));
            OnPropertyChanged(nameof(MsiAuthoringModeText));
            OnPropertyChanged(nameof(BuildSummary));
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    public bool CreateUninstallerEnabled
    {
        get => Project?.Build.CreateUninstaller == true;
        set
        {
            if (Project is null)
            {
                return;
            }

            Project.Build.CreateUninstaller = value;
            OnPropertyChanged(nameof(CreateUninstallerEnabled));
            OnPropertyChanged(nameof(UninstallerModeText));
            OnPropertyChanged(nameof(BuildSummary));
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    public string SetupExecutableName
    {
        get => Project?.Build.SetupExecutableName ?? "Setup.exe";
        set
        {
            if (Project is null)
            {
                return;
            }

            Project.Build.SetupExecutableName = ProjectBuildSettings.NormalizeSetupExecutableName(value);
            OnPropertyChanged(nameof(SetupExecutableName));
            OnPropertyChanged(nameof(BuildSummary));
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    public bool IncludeIconEnabled
    {
        get => Project?.Build.IncludeIcon == true;
        set
        {
            if (Project is null)
            {
                return;
            }

            Project.Build.IncludeIcon = value;
            OnPropertyChanged(nameof(IncludeIconEnabled));
            OnPropertyChanged(nameof(BuildSummary));
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    public bool IncludeLicenseEnabled
    {
        get => Project?.Build.IncludeLicense == true;
        set
        {
            if (Project is null)
            {
                return;
            }

            Project.Build.IncludeLicense = value;
            OnPropertyChanged(nameof(IncludeLicenseEnabled));
            OnPropertyChanged(nameof(BuildSummary));
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    public bool AllowCustomerCustomizationEnabled
    {
        get => Project?.Build.AllowCustomerCustomization == true;
        set
        {
            if (Project is null)
            {
                return;
            }

            Project.Build.AllowCustomerCustomization = value;
            OnPropertyChanged(nameof(AllowCustomerCustomizationEnabled));
            OnPropertyChanged(nameof(BuildSummary));
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    public string? IconPath
    {
        get => Project?.Build.IconPath;
        set
        {
            if (Project is null || value is null)
            {
                return;
            }

            Project.Build.IconPath = value;
            OnPropertyChanged(nameof(IconPath));
            OnPropertyChanged(nameof(BuildSummary));
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    public string? LicensePath
    {
        get => Project?.Build.LicensePath;
        set
        {
            if (Project is null || value is null)
            {
                return;
            }

            Project.Build.LicensePath = value;
            OnPropertyChanged(nameof(LicensePath));
            OnPropertyChanged(nameof(BuildSummary));
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    public string? CustomLogoPath
    {
        get => Project?.Build.CustomLogoPath;
        set
        {
            if (Project is null || value is null)
            {
                return;
            }

            Project.Build.CustomLogoPath = value;
            OnPropertyChanged(nameof(CustomLogoPath));
            OnPropertyChanged(nameof(BuildSummary));
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    public string? CustomCompanyName
    {
        get => Project?.Build.CustomCompanyName;
        set
        {
            if (Project is null || value is null)
            {
                return;
            }

            Project.Build.CustomCompanyName = value;
            OnPropertyChanged(nameof(CustomCompanyName));
            OnPropertyChanged(nameof(BuildSummary));
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    public string? CustomBrandColorHex
    {
        get => Project?.Build.CustomBrandColorHex;
        set
        {
            if (Project is null || value is null)
            {
                return;
            }

            Project.Build.CustomBrandColorHex = value;
            OnPropertyChanged(nameof(CustomBrandColorHex));
            OnPropertyChanged(nameof(BuildSummary));
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    public string? BrandingBannerImagePath
    {
        get => Project?.Build.BrandingBannerImagePath;
        set
        {
            if (Project is null || value is null)
            {
                return;
            }

            Project.Build.BrandingBannerImagePath = value;
            OnPropertyChanged(nameof(BrandingBannerImagePath));
            OnPropertyChanged(nameof(BuildSummary));
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    public string? BrandingWelcomeImagePath
    {
        get => Project?.Build.BrandingWelcomeImagePath;
        set
        {
            if (Project is null || value is null)
            {
                return;
            }

            Project.Build.BrandingWelcomeImagePath = value;
            OnPropertyChanged(nameof(BrandingWelcomeImagePath));
            OnPropertyChanged(nameof(BuildSummary));
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    public string? BrandingAccentColorHex
    {
        get => Project?.Build.BrandingAccentColorHex;
        set
        {
            if (Project is null || value is null)
            {
                return;
            }

            Project.Build.BrandingAccentColorHex = value;
            OnPropertyChanged(nameof(BrandingAccentColorHex));
            OnPropertyChanged(nameof(BuildSummary));
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    public string? BrandingWelcomeBackgroundColorHex
    {
        get => Project?.Build.BrandingWelcomeBackgroundColorHex;
        set
        {
            if (Project is null || value is null)
            {
                return;
            }

            Project.Build.BrandingWelcomeBackgroundColorHex = value;
            OnPropertyChanged(nameof(BrandingWelcomeBackgroundColorHex));
            OnPropertyChanged(nameof(BuildSummary));
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    public string? UpgradeVersionMin
    {
        get => Project?.Build.UpgradeVersionMin;
        set
        {
            if (Project is null || value is null)
            {
                return;
            }

            Project.Build.UpgradeVersionMin = value;
            OnPropertyChanged(nameof(UpgradeVersionMin));
            OnPropertyChanged(nameof(BuildSummary));
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    public string? UpgradeVersionMax
    {
        get => Project?.Build.UpgradeVersionMax;
        set
        {
            if (Project is null || value is null)
            {
                return;
            }

            Project.Build.UpgradeVersionMax = value;
            OnPropertyChanged(nameof(UpgradeVersionMax));
            OnPropertyChanged(nameof(BuildSummary));
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    public string? UpgradeActionProperty
    {
        get => Project?.Build.UpgradeActionProperty;
        set
        {
            if (Project is null || value is null)
            {
                return;
            }

            Project.Build.UpgradeActionProperty = value;
            OnPropertyChanged(nameof(UpgradeActionProperty));
            OnPropertyChanged(nameof(BuildSummary));
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }

    public bool UpgradeVersionMinError { get => _upgradeVersionMinError; set => SetProperty(ref _upgradeVersionMinError, value); }

    public bool UpgradeVersionMaxError { get => _upgradeVersionMaxError; set => SetProperty(ref _upgradeVersionMaxError, value); }

    public bool UpgradeActionPropertyError { get => _upgradeActionPropertyError; set => SetProperty(ref _upgradeActionPropertyError, value); }

    public string UninstallerModeText
        => Project?.Build.CreateUninstaller == true
            ? "Standalone uninstaller enabled"
            : "Self-uninstall mode";

    public string BuildSummary
        => Project is null
            ? "No project loaded"
            : $"{Project.ProductName} {Project.Version} | {Project.Build.MsiAuthoringMode} | {UninstallerModeText} | {Project.Files.Count} files | {Project.Shortcuts.Count} shortcuts | {Project.RegistryEntries.Count} registry entries | {Project.Services.Count} services | Upgrade {Project.Build.UpgradeVersionMin} -> {Project.Build.UpgradeVersionMax}{(Project.Build.AllowCustomerCustomization ? " | Customer branding enabled" : string.Empty)}";

    public bool SetupProjectError { get => _setupProjectError; set => SetProperty(ref _setupProjectError, value); }

    public bool UninstallerProjectError { get => _uninstallerProjectError; set => SetProperty(ref _uninstallerProjectError, value); }

    public bool HasErrors => SetupProjectError || (Project?.Build.CreateUninstaller == true && UninstallerProjectError) || UpgradeVersionMinError || UpgradeVersionMaxError || UpgradeActionPropertyError;

    public void Refresh()
    {
        OnPropertyChanged(nameof(Project));
        OnPropertyChanged(nameof(SetupProjectPath));
        OnPropertyChanged(nameof(UninstallerProjectPath));
        OnPropertyChanged(nameof(MsiAuthoringModeText));
        OnPropertyChanged(nameof(IsWixModeSelected));
        OnPropertyChanged(nameof(IsNativePreviewModeSelected));
        OnPropertyChanged(nameof(CreateUninstallerEnabled));
        OnPropertyChanged(nameof(IncludeIconEnabled));
        OnPropertyChanged(nameof(IncludeLicenseEnabled));
        OnPropertyChanged(nameof(AllowCustomerCustomizationEnabled));
        OnPropertyChanged(nameof(IconPath));
        OnPropertyChanged(nameof(LicensePath));
        OnPropertyChanged(nameof(CustomLogoPath));
        OnPropertyChanged(nameof(CustomCompanyName));
        OnPropertyChanged(nameof(CustomBrandColorHex));
        OnPropertyChanged(nameof(BrandingBannerImagePath));
        OnPropertyChanged(nameof(BrandingWelcomeImagePath));
        OnPropertyChanged(nameof(BrandingAccentColorHex));
        OnPropertyChanged(nameof(BrandingWelcomeBackgroundColorHex));
        OnPropertyChanged(nameof(UpgradeVersionMin));
        OnPropertyChanged(nameof(UpgradeVersionMax));
        OnPropertyChanged(nameof(UpgradeActionProperty));
        OnPropertyChanged(nameof(UpgradeVersionMinError));
        OnPropertyChanged(nameof(UpgradeVersionMaxError));
        OnPropertyChanged(nameof(UpgradeActionPropertyError));
        OnPropertyChanged(nameof(UninstallerModeText));
        OnPropertyChanged(nameof(BuildSummary));
        OnPropertyChanged(nameof(HasErrors));
    }

    public void ValidateUpgradeSettings()
    {
        var minText = Project?.Build.UpgradeVersionMin ?? string.Empty;
        var maxText = Project?.Build.UpgradeVersionMax ?? string.Empty;
        var actionProperty = Project?.Build.UpgradeActionProperty ?? string.Empty;

        UpgradeVersionMinError = !TryParseVersion(minText, out _);
        UpgradeVersionMaxError = !string.IsNullOrWhiteSpace(maxText) && !TryParseVersion(maxText, out _);
        UpgradeActionPropertyError = string.IsNullOrWhiteSpace(actionProperty);

        if (!UpgradeVersionMinError && !UpgradeVersionMaxError &&
            TryParseVersion(minText, out var minVersion) &&
            TryParseVersion(string.IsNullOrWhiteSpace(maxText) ? minText : maxText, out var maxVersion))
        {
            if (maxVersion < minVersion)
            {
                UpgradeVersionMaxError = true;
            }
        }

        OnPropertyChanged(nameof(UpgradeVersionMinError));
        OnPropertyChanged(nameof(UpgradeVersionMaxError));
        OnPropertyChanged(nameof(UpgradeActionPropertyError));
        OnPropertyChanged(nameof(HasErrors));
    }

    private static bool TryParseVersion(string value, [NotNullWhen(true)] out Version? version)
        => Version.TryParse(value, out version);
}

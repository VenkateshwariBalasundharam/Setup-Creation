using System.Collections.ObjectModel;
using ASPLShield.Common;
using ASPLShield.Core;

namespace ASPLShield.Studio;

public sealed class ProjectExplorerViewModel : ObservableObject
{
    private Func<InstallerProject>? _projectAccessor;
    private ProjectExplorerNode? _selectedNode;

    public ObservableCollection<ProjectExplorerNode> Nodes { get; } = new();

    public ProjectExplorerNode? SelectedNode
    {
        get => _selectedNode;
        set
        {
            if (SetProperty(ref _selectedNode, value))
            {
                OnPropertyChanged(nameof(HasSelection));
                OnPropertyChanged(nameof(SelectionHeader));
                OnPropertyChanged(nameof(SelectionKind));
                OnPropertyChanged(nameof(SelectionKindDescription));
                OnPropertyChanged(nameof(SelectionDetails));
                OnPropertyChanged(nameof(SelectionPath));
                OnPropertyChanged(nameof(SelectionBadge));
                OnPropertyChanged(nameof(ActionHint));
                OnPropertyChanged(nameof(CanCreateFiles));
                OnPropertyChanged(nameof(CanCreateShortcuts));
                OnPropertyChanged(nameof(CanEditFileNode));
                OnPropertyChanged(nameof(CanEditShortcutNode));
            }
        }
    }

    public bool HasSelection => SelectedNode is not null;

    public string SelectionHeader => SelectedNode?.Header ?? "No node selected";

    public string SelectionKind => SelectedNode is null ? "None" : SelectedNode.Kind.ToString();

    public string SelectionKindDescription => SelectedNode is null ? "No selection" : DescribeKind(SelectedNode.Kind);

    public string SelectionPath
        => string.IsNullOrWhiteSpace(SelectedNode?.Tag) ? "No path assigned" : SelectedNode.Tag!;

    public string SelectionBadge => SelectedNode?.Badge ?? string.Empty;

    public string SelectionDetails
    {
        get
        {
            if (SelectedNode is null)
            {
                return "Select a project node to see its type and metadata.";
            }

            var suffix = string.IsNullOrWhiteSpace(SelectedNode.Tag) ? "No linked target." : $"Linked target: {SelectedNode.Tag}.";
            var childCount = SelectedNode.Children.Count > 0 ? $" Contains {SelectedNode.Children.Count} child node(s)." : string.Empty;
            return $"{SelectionHeader} is a {SelectionKind.ToLowerInvariant()} node.{childCount} {suffix}".Trim();
        }
    }

    public string ActionHint
        => SelectedNode?.Kind switch
        {
            ProjectExplorerNodeKind.Project => "Use project actions to add files and shortcuts.",
            ProjectExplorerNodeKind.Files or ProjectExplorerNodeKind.Folder => "You can add, remove, or reorder files from here.",
            ProjectExplorerNodeKind.Shortcut => "You can add, remove, or reorder shortcuts from here.",
            ProjectExplorerNodeKind.Registry => "Edit registry entries that will be written during install and removed during uninstall.",
            ProjectExplorerNodeKind.Iis => "IIS site and app pool authoring is available in the runtime pipeline.",
            ProjectExplorerNodeKind.Services => "Author Windows services that will be installed and cleaned up by the runtime.",
            ProjectExplorerNodeKind.Prerequisites => "Prerequisite checks are authored here and enforced by the package and runtime.",
            ProjectExplorerNodeKind.Build => "Build settings live in the authoring workspace.",
            _ => "Select a node to see available actions."
        };

    public bool CanCreateFiles => SelectedNode?.Kind is ProjectExplorerNodeKind.Project or ProjectExplorerNodeKind.Files;

    public bool CanCreateShortcuts => SelectedNode?.Kind is ProjectExplorerNodeKind.Project or ProjectExplorerNodeKind.Shortcuts;

    public bool CanEditFileNode => SelectedNode?.Kind is ProjectExplorerNodeKind.File or ProjectExplorerNodeKind.Folder;

    public bool CanEditShortcutNode => SelectedNode?.Kind is ProjectExplorerNodeKind.Shortcut;

    public void Bind(Func<InstallerProject> projectAccessor)
    {
        _projectAccessor = projectAccessor;
        Refresh();
    }

    public void Refresh()
    {
        Nodes.Clear();
        var project = _projectAccessor?.Invoke() ?? ProjectFactory.CreateDefault();
        var root = new ProjectExplorerNode
        {
            Header = project.ProductName,
            Kind = ProjectExplorerNodeKind.Project,
            IconText = "P",
            Badge = $"{project.Files.Count + project.Shortcuts.Count + project.IisSites.Count + project.RegistryEntries.Count + project.Services.Count + project.Prerequisites.Count} items",
            Description = $"{project.ProductName} {project.Version}"
        };
        root.Children.Add(CreateContainer("Files", ProjectExplorerNodeKind.Files, project.Files.Select(f => new ProjectExplorerNode
        {
            Header = f.DisplayName,
            Kind = f.IsFolder ? ProjectExplorerNodeKind.Folder : ProjectExplorerNodeKind.File,
            IconText = f.IsFolder ? "FD" : "FI",
            Tag = f.DestinationPath 
            ,
            Badge = f.IsFolder ? "Folder" : "File"
        })));
        root.Children.Add(CreateContainer("Shortcuts", ProjectExplorerNodeKind.Shortcuts, project.Shortcuts.Select(s => new ProjectExplorerNode
        {
            Header = s.Name,
            Kind = ProjectExplorerNodeKind.Shortcut,
            IconText = "SC",
            Tag = s.TargetPath,
            Badge = s.Location.ToString()
        })));
        root.Children.Add(new ProjectExplorerNode { Header = "Registry", Kind = ProjectExplorerNodeKind.Registry, IconText = "RG", Badge = $"{project.RegistryEntries.Count} entries" });
        root.Children.Add(new ProjectExplorerNode { Header = "IIS", Kind = ProjectExplorerNodeKind.Iis, IconText = "IW", Badge = "Supported" });
        root.Children.Add(new ProjectExplorerNode { Header = "Services", Kind = ProjectExplorerNodeKind.Services, IconText = "SV", Badge = $"{project.Services.Count} services" });
        root.Children.Add(new ProjectExplorerNode { Header = "Prerequisites", Kind = ProjectExplorerNodeKind.Prerequisites, IconText = "PR", Badge = $"{project.Prerequisites.Count} checks" });
        root.Children.Add(new ProjectExplorerNode { Header = "Build", Kind = ProjectExplorerNodeKind.Build, IconText = "BL", Badge = "Ready" });
        Nodes.Add(root);
        OnPropertyChanged(nameof(HasSelection));
        OnPropertyChanged(nameof(SelectionHeader));
        OnPropertyChanged(nameof(SelectionKind));
        OnPropertyChanged(nameof(SelectionKindDescription));
        OnPropertyChanged(nameof(SelectionDetails));
        OnPropertyChanged(nameof(SelectionPath));
        OnPropertyChanged(nameof(SelectionBadge));
        OnPropertyChanged(nameof(ActionHint));
        OnPropertyChanged(nameof(CanCreateFiles));
        OnPropertyChanged(nameof(CanCreateShortcuts));
        OnPropertyChanged(nameof(CanEditFileNode));
        OnPropertyChanged(nameof(CanEditShortcutNode));
    }

    private static ProjectExplorerNode CreateContainer(string header, ProjectExplorerNodeKind kind, IEnumerable<ProjectExplorerNode> items)
    {
        var materialized = items.ToList();
        var node = new ProjectExplorerNode { Header = header, Kind = kind, IconText = kind == ProjectExplorerNodeKind.Files ? "FL" : "SC", Badge = $"{materialized.Count} items" };
        foreach (var item in materialized)
        {
            node.Children.Add(item);
        }

        return node;
    }

    private static string DescribeKind(ProjectExplorerNodeKind kind)
        => kind switch
        {
            ProjectExplorerNodeKind.Project => "Project root",
            ProjectExplorerNodeKind.Files => "File collection",
            ProjectExplorerNodeKind.Shortcuts => "Shortcut collection",
            ProjectExplorerNodeKind.Registry => "Registry section",
            ProjectExplorerNodeKind.Iis => "IIS section",
            ProjectExplorerNodeKind.Services => "Service section",
            ProjectExplorerNodeKind.Prerequisites => "Prerequisite section",
            ProjectExplorerNodeKind.Build => "Build section",
            ProjectExplorerNodeKind.File => "File asset",
            ProjectExplorerNodeKind.Folder => "Folder asset",
            ProjectExplorerNodeKind.Shortcut => "Shortcut asset",
            _ => kind.ToString()
        };
}

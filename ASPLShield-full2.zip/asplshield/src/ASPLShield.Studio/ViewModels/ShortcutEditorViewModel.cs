using System.Collections.ObjectModel;
using ASPLShield.Common;
using ASPLShield.Core;

namespace ASPLShield.Studio;

public sealed class ShortcutEditorViewModel : ObservableObject
{
    private Func<InstallerProject>? _projectAccessor;
    private InstallerShortcut? _selectedShortcut;
    private readonly HashSet<InstallerShortcut> _wiredShortcuts = new();

    public event EventHandler? Changed;

    public ShortcutEditorViewModel()
    {
        AddDesktopShortcutCommand = new RelayCommand(_ => AddShortcut(ShortcutLocation.Desktop));
        AddStartMenuShortcutCommand = new RelayCommand(_ => AddShortcut(ShortcutLocation.StartMenu));
        RemoveShortcutCommand = new RelayCommand(_ => RemoveSelectedShortcut(), _ => SelectedShortcut is not null);
        MoveShortcutUpCommand = new RelayCommand(_ => MoveSelected(-1), _ => CanMoveSelected(-1));
        MoveShortcutDownCommand = new RelayCommand(_ => MoveSelected(1), _ => CanMoveSelected(1));
    }

    public ObservableCollection<InstallerShortcut> Shortcuts => _projectAccessor?.Invoke().Shortcuts ?? new ObservableCollection<InstallerShortcut>();

    public InstallerShortcut? SelectedShortcut
    {
        get => _selectedShortcut;
        set
        {
            if (SetProperty(ref _selectedShortcut, value))
            {
                RemoveShortcutCommand.RaiseCanExecuteChanged();
                MoveShortcutUpCommand.RaiseCanExecuteChanged();
                MoveShortcutDownCommand.RaiseCanExecuteChanged();
                Changed?.Invoke(this, EventArgs.Empty);
            }
        }
    }

    public RelayCommand AddDesktopShortcutCommand { get; }

    public RelayCommand AddStartMenuShortcutCommand { get; }

    public RelayCommand RemoveShortcutCommand { get; }

    public RelayCommand MoveShortcutUpCommand { get; }

    public RelayCommand MoveShortcutDownCommand { get; }

    public void Bind(Func<InstallerProject> projectAccessor) => _projectAccessor = projectAccessor;

    public void Refresh()
    {
        WireCurrentShortcuts();
        OnPropertyChanged(nameof(Shortcuts));
    }

    private void AddShortcut(ShortcutLocation location)
    {
        var project = _projectAccessor?.Invoke();
        if (project is null)
        {
            return;
        }

        var shortcut = new InstallerShortcut
        {
            Name = $"{project.ProductName} {(location == ShortcutLocation.Desktop ? "Desktop" : "Start Menu")} Shortcut",
            TargetPath = project.Files.FirstOrDefault()?.DestinationPath ?? project.ProductName,
            // WiX's Shortcut/@WorkingDirectory attribute requires either a plain
            // Directory Id or a bracketed property token like "[INSTALLFOLDER]" —
            // it does NOT accept the raw resolved install path (e.g.
            // "[ProgramFiles]\MyApp"), which WixMsiGenerator's bracket-stripping
            // logic can't normalize into a legal identifier. Default to the
            // property token instead, matching the convention used everywhere
            // else in the project (see samples/FullConfiguredSample.asplproj).
            WorkingDirectory = "[INSTALLFOLDER]",
            Location = location
        };
        Wire(shortcut);
        Shortcuts.Add(shortcut);

        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Shortcuts));
    }

    private void RemoveSelectedShortcut()
    {
        if (SelectedShortcut is null)
        {
            return;
        }

        Shortcuts.Remove(SelectedShortcut);
        SelectedShortcut = null;
        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Shortcuts));
    }

    public void NotifyChanged()
    {
        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Shortcuts));
    }

    public void MoveShortcutToIndex(InstallerShortcut shortcut, int newIndex)
    {
        if (_projectAccessor is null)
        {
            return;
        }

        var index = Shortcuts.IndexOf(shortcut);
        if (index < 0 || newIndex < 0 || newIndex >= Shortcuts.Count || index == newIndex)
        {
            return;
        }

        Shortcuts.Move(index, newIndex);
        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Shortcuts));
    }

    private bool CanMoveSelected(int delta)
    {
        if (_projectAccessor is null || SelectedShortcut is null)
        {
            return false;
        }

        var index = Shortcuts.IndexOf(SelectedShortcut);
        return delta < 0 ? index > 0 : index >= 0 && index < Shortcuts.Count - 1;
    }

    private void MoveSelected(int delta)
    {
        if (_projectAccessor is null || SelectedShortcut is null)
        {
            return;
        }

        var index = Shortcuts.IndexOf(SelectedShortcut);
        var newIndex = index + delta;
        if (index < 0 || newIndex < 0 || newIndex >= Shortcuts.Count)
        {
            return;
        }

        Shortcuts.Move(index, newIndex);
        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Shortcuts));
        MoveShortcutUpCommand.RaiseCanExecuteChanged();
        MoveShortcutDownCommand.RaiseCanExecuteChanged();
    }

    private void WireCurrentShortcuts()
    {
        if (_projectAccessor is null)
        {
            return;
        }

        foreach (var shortcut in Shortcuts)
        {
            Wire(shortcut);
        }
    }

    private void Wire(InstallerShortcut shortcut)
    {
        if (_wiredShortcuts.Add(shortcut))
        {
            shortcut.PropertyChanged += (_, _) =>
            {
                Changed?.Invoke(this, EventArgs.Empty);
                OnPropertyChanged(nameof(Shortcuts));
            };
        }
    }
}
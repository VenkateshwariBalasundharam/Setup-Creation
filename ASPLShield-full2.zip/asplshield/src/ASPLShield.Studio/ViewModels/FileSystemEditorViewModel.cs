using System.Collections.ObjectModel;
using System.Linq;
using ASPLShield.Common;
using ASPLShield.Core;

namespace ASPLShield.Studio;

public sealed class FileSystemEditorViewModel : ObservableObject
{
    private Func<InstallerProject>? _projectAccessor;
    private readonly IFileDialogService _fileDialogs;
    private InstallerFile? _selectedFile;
    private readonly HashSet<InstallerFile> _wiredFiles = new();
    private string? _pendingFolderRoot;
    private string? _pendingFolderName;
    private SelectFolderFilesViewModel? _folderPicker;
    private bool _isFolderPickerOpen;

    public event EventHandler? Changed;

    public FileSystemEditorViewModel(IFileDialogService fileDialogs)
    {
        _fileDialogs = fileDialogs;
        AddFileCommand = new RelayCommand(_ => AddFiles(), _ => true);
        AddFolderCommand = new RelayCommand(_ => AddFolder(), _ => true);
        RemoveFileCommand = new RelayCommand(_ => RemoveSelectedFile(), _ => SelectedFile is not null);
        MoveFileUpCommand = new RelayCommand(_ => MoveSelected(-1), _ => CanMoveSelected(-1));
        MoveFileDownCommand = new RelayCommand(_ => MoveSelected(1), _ => CanMoveSelected(1));
        ConfirmFolderPickerCommand = new RelayCommand(_ => ConfirmFolderPicker(), _ => true);
        CancelFolderPickerCommand = new RelayCommand(_ => CancelFolderPicker(), _ => true);
    }

    /// <summary>
    /// Backing view model for the inline "Select Files to Add" picker shown inside the Files tab
    /// (as an in-place overlay, not a separate window) after choosing a folder via Add Folder.
    /// Null when the picker is closed.
    /// </summary>
    public SelectFolderFilesViewModel? FolderPicker
    {
        get => _folderPicker;
        private set => SetProperty(ref _folderPicker, value);
    }

    /// <summary>
    /// True while the inline folder-file picker overlay should be visible in the Files tab.
    /// </summary>
    public bool IsFolderPickerOpen
    {
        get => _isFolderPickerOpen;
        private set => SetProperty(ref _isFolderPickerOpen, value);
    }

    public RelayCommand ConfirmFolderPickerCommand { get; }

    public RelayCommand CancelFolderPickerCommand { get; }

    public ObservableCollection<InstallerFile> Files => _projectAccessor?.Invoke().Files ?? new ObservableCollection<InstallerFile>();

    /// <summary>
    /// Nested view of <see cref="Files"/>, grouped by destination path so that a
    /// destination like "wwwroot/assets/img" renders as real, expandable tree nodes
    /// (wwwroot &gt; assets &gt; img) instead of a single flat string.
    /// </summary>
    public ObservableCollection<DestinationTreeNode> DestinationTree { get; } = new();

    private DestinationTreeNode? _selectedTreeNode;

    public DestinationTreeNode? SelectedTreeNode
    {
        get => _selectedTreeNode;
        set
        {
            if (SetProperty(ref _selectedTreeNode, value) && value?.File is not null)
            {
                SelectedFile = value.File;
            }
        }
    }

    public InstallerFile? SelectedFile
    {
        get => _selectedFile;
        set
        {
            if (SetProperty(ref _selectedFile, value))
            {
                RemoveFileCommand.RaiseCanExecuteChanged();
                MoveFileUpCommand.RaiseCanExecuteChanged();
                MoveFileDownCommand.RaiseCanExecuteChanged();
                Changed?.Invoke(this, EventArgs.Empty);
            }
        }
    }

    public RelayCommand AddFileCommand { get; }

    public RelayCommand AddFolderCommand { get; }

    public RelayCommand RemoveFileCommand { get; }

    public RelayCommand MoveFileUpCommand { get; }

    public RelayCommand MoveFileDownCommand { get; }

    public void Bind(Func<InstallerProject> projectAccessor) => _projectAccessor = projectAccessor;

    public void Refresh()
    {
        WireCurrentFiles();
        OnPropertyChanged(nameof(Files));
        RebuildDestinationTree();
    }

    private void AddFiles()
    {
        var selected = _fileDialogs.SelectFiles();
        if (string.IsNullOrWhiteSpace(selected) || _projectAccessor is null)
        {
            return;
        }

        AddDroppedPaths(selected.Split('|', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries));
    }

    private void AddFolder()
    {
        var folder = _fileDialogs.SelectFolder();
        if (string.IsNullOrWhiteSpace(folder) || _projectAccessor is null)
        {
            return;
        }

        var folderName = Path.GetFileName(folder.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
        if (string.IsNullOrEmpty(folderName))
        {
            folderName = folder;
        }

        _pendingFolderRoot = folder;
        _pendingFolderName = folderName;

        // Open the "Select Files to Add" picker inline, inside the Files tab, instead of a
        // separate top-level window.
        FolderPicker = new SelectFolderFilesViewModel(folder);
        IsFolderPickerOpen = true;
    }

    private void ConfirmFolderPicker()
    {
        var picker = FolderPicker;
        var folderName = _pendingFolderName;

        if (picker is null || folderName is null || _projectAccessor is null)
        {
            CloseFolderPicker();
            return;
        }

        var selection = picker.GetSelectedFiles();

        foreach (var (fullPath, relativePath) in selection)
        {
            var info = new FileInfo(fullPath);
            var fileItem = new InstallerFile
            {
                SourcePath = fullPath,
                DestinationPath = $"{folderName}/{relativePath}",
                DisplayName = info.Name,
                SizeBytes = info.Length,
                IsFolder = false
            };
            Wire(fileItem);
            Files.Add(fileItem);
        }

        if (selection.Count > 0)
        {
            Changed?.Invoke(this, EventArgs.Empty);
            OnPropertyChanged(nameof(Files));
            RebuildDestinationTree();
        }

        CloseFolderPicker();
    }

    private void CancelFolderPicker() => CloseFolderPicker();

    private void CloseFolderPicker()
    {
        IsFolderPickerOpen = false;
        FolderPicker = null;
        _pendingFolderRoot = null;
        _pendingFolderName = null;
    }

    private void RemoveSelectedFile()
    {
        if (SelectedFile is null)
        {
            return;
        }

        Files.Remove(SelectedFile);
        SelectedFile = null;
        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Files));
        RebuildDestinationTree();
    }

    private bool CanMoveSelected(int delta)
    {
        if (_projectAccessor is null || SelectedFile is null)
        {
            return false;
        }

        var index = Files.IndexOf(SelectedFile);
        return delta < 0 ? index > 0 : index >= 0 && index < Files.Count - 1;
    }

    private void MoveSelected(int delta)
    {
        if (_projectAccessor is null || SelectedFile is null)
        {
            return;
        }

        var index = Files.IndexOf(SelectedFile);
        var newIndex = index + delta;
        if (index < 0 || newIndex < 0 || newIndex >= Files.Count)
        {
            return;
        }

        Files.Move(index, newIndex);
        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Files));
        RebuildDestinationTree();
        MoveFileUpCommand.RaiseCanExecuteChanged();
        MoveFileDownCommand.RaiseCanExecuteChanged();
    }

    public void AddDroppedPaths(IEnumerable<string> paths)
    {
        if (_projectAccessor is null)
        {
            return;
        }

        foreach (var path in paths)
        {
            if (string.IsNullOrWhiteSpace(path))
            {
                continue;
            }

            if (Directory.Exists(path))
            {
                var item = new InstallerFile
                {
                    SourcePath = path,
                    DestinationPath = Path.GetFileName(path),
                    DisplayName = Path.GetFileName(path),
                    SizeBytes = ComputeFolderSize(path),
                    IsFolder = true
                };
                Wire(item);
                Files.Add(item);
                continue;
            }

            if (!File.Exists(path))
            {
                continue;
            }

            var info = new FileInfo(path);
            var fileItem = new InstallerFile
            {
                SourcePath = path,
                DestinationPath = Path.GetFileName(path),
                DisplayName = info.Name,
                SizeBytes = info.Length,
                IsFolder = false
            };
            Wire(fileItem);
            Files.Add(fileItem);
        }

        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Files));
        RebuildDestinationTree();
    }

    public void MoveFileToIndex(InstallerFile file, int newIndex)
    {
        if (_projectAccessor is null)
        {
            return;
        }

        var index = Files.IndexOf(file);
        if (index < 0 || newIndex < 0 || newIndex >= Files.Count || index == newIndex)
        {
            return;
        }

        Files.Move(index, newIndex);
        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Files));
        RebuildDestinationTree();
    }

    /// <summary>
    /// Rebuilds <see cref="DestinationTree"/> by splitting every file's <see cref="InstallerFile.DestinationPath"/>
    /// on '/' or '\' and turning each intermediate segment into its own folder node, so
    /// "wwwroot/assets/img/logo.png" becomes wwwroot &gt; assets &gt; img &gt; logo.png rather than one flat row.
    /// Folder entries added via Add Folder share a node with any files nested beneath the same path.
    /// </summary>
    private void RebuildDestinationTree()
    {
        var root = new ObservableCollection<DestinationTreeNode>();
        var folderLookup = new Dictionary<string, DestinationTreeNode>(StringComparer.OrdinalIgnoreCase);

        foreach (var file in Files)
        {
            var normalized = (file.DestinationPath ?? string.Empty).Replace('\\', '/').Trim('/');
            var segments = normalized.Split('/', StringSplitOptions.RemoveEmptyEntries);
            if (segments.Length == 0)
            {
                segments = new[] { string.IsNullOrWhiteSpace(file.DisplayName) ? "(unnamed)" : file.DisplayName };
                normalized = segments[0];
            }

            var folderSegmentCount = file.IsFolder ? segments.Length : segments.Length - 1;
            var currentChildren = root;
            var currentPath = string.Empty;

            for (var i = 0; i < folderSegmentCount; i++)
            {
                currentPath = currentPath.Length == 0 ? segments[i] : $"{currentPath}/{segments[i]}";
                if (!folderLookup.TryGetValue(currentPath, out var folderNode))
                {
                    folderNode = new DestinationTreeNode { Name = segments[i], FullPath = currentPath, IsFolder = true };
                    folderLookup[currentPath] = folderNode;
                    currentChildren.Add(folderNode);
                }

                currentChildren = folderNode.Children;
            }

            if (file.IsFolder)
            {
                if (folderLookup.TryGetValue(normalized, out var selfNode))
                {
                    selfNode.File = file;
                }
            }
            else
            {
                var leafNode = new DestinationTreeNode
                {
                    Name = segments[^1],
                    FullPath = normalized,
                    IsFolder = false,
                    File = file
                };
                currentChildren.Add(leafNode);
            }
        }

        SortTree(root);

        DestinationTree.Clear();
        foreach (var node in root)
        {
            DestinationTree.Add(node);
        }
    }

    private static void SortTree(ObservableCollection<DestinationTreeNode> nodes)
    {
        var ordered = nodes
            .OrderBy(n => n.IsFolder ? 0 : 1)
            .ThenBy(n => n.Name, StringComparer.OrdinalIgnoreCase)
            .ToList();

        nodes.Clear();
        foreach (var node in ordered)
        {
            SortTree(node.Children);
            nodes.Add(node);
        }
    }

    private static long ComputeFolderSize(string path)
        => Directory.Exists(path)
            ? Directory.EnumerateFiles(path, "*", SearchOption.AllDirectories).Sum(file => new FileInfo(file).Length)
            : 0;

    private void WireCurrentFiles()
    {
        if (_projectAccessor is null)
        {
            return;
        }

        foreach (var file in Files)
        {
            Wire(file);
        }
    }

    private void Wire(InstallerFile file)
    {
        if (_wiredFiles.Add(file))
        {
            file.PropertyChanged += (_, _) =>
            {
                Changed?.Invoke(this, EventArgs.Empty);
                OnPropertyChanged(nameof(Files));
                RebuildDestinationTree();
            };
        }
    }
}

using System.Collections.ObjectModel;
using ASPLShield.Common;
using ASPLShield.Core;

namespace ASPLShield.Studio;

public sealed class RegistryEditorViewModel : ObservableObject
{
    private Func<InstallerProject>? _projectAccessor;
    private RegistryEntry? _selectedEntry;
    private readonly HashSet<RegistryEntry> _wiredEntries = new();

    public event EventHandler? Changed;

    public RegistryEditorViewModel()
    {
        AddEntryCommand = new RelayCommand(_ => AddEntry(), _ => true);
        RemoveEntryCommand = new RelayCommand(_ => RemoveSelectedEntry(), _ => SelectedEntry is not null);
        MoveEntryUpCommand = new RelayCommand(_ => MoveSelected(-1), _ => CanMoveSelected(-1));
        MoveEntryDownCommand = new RelayCommand(_ => MoveSelected(1), _ => CanMoveSelected(1));
    }

    public ObservableCollection<RegistryEntry> Entries => _projectAccessor?.Invoke().RegistryEntries ?? new ObservableCollection<RegistryEntry>();

    public RegistryEntry? SelectedEntry
    {
        get => _selectedEntry;
        set
        {
            if (SetProperty(ref _selectedEntry, value))
            {
                RemoveEntryCommand.RaiseCanExecuteChanged();
                MoveEntryUpCommand.RaiseCanExecuteChanged();
                MoveEntryDownCommand.RaiseCanExecuteChanged();
                OnPropertyChanged(nameof(RegistryRoot));
                OnPropertyChanged(nameof(RegistryRootText));
            }
        }
    }

    public RegistryRootKind RegistryRoot
    {
        get => SelectedEntry?.RegistryRoot ?? RegistryRootKind.CurrentUser;
        set
        {
            if (SelectedEntry is null)
            {
                return;
            }

            SelectedEntry.RegistryRoot = value;
            OnPropertyChanged();
        }
    }

    public string RegistryRootText
    {
        get => RegistryRoot.ToString();
        set
        {
            if (Enum.TryParse(value, true, out RegistryRootKind parsed))
            {
                RegistryRoot = parsed;
            }
        }
    }

    public RelayCommand AddEntryCommand { get; }

    public RelayCommand RemoveEntryCommand { get; }

    public RelayCommand MoveEntryUpCommand { get; }

    public RelayCommand MoveEntryDownCommand { get; }

    public bool HasErrors => Entries.Any(entry => string.IsNullOrWhiteSpace(entry.KeyPath));

    public void Bind(Func<InstallerProject> projectAccessor) => _projectAccessor = projectAccessor;

    public void Refresh()
    {
        WireCurrentEntries();
        OnPropertyChanged(nameof(Entries));
        OnPropertyChanged(nameof(HasErrors));
    }

    private void AddEntry()
    {
        var project = _projectAccessor?.Invoke();
        if (project is null)
        {
            return;
        }

        var entry = new RegistryEntry
        {
            RegistryRoot = RegistryRootKind.CurrentUser,
            KeyPath = $@"Software\ASPLShield\{project.ProductName}",
            Name = "Installed",
            Value = "1",
            ValueKind = "String"
        };

        Wire(entry);
        project.RegistryEntries.Add(entry);
        SelectedEntry = entry;
        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Entries));
        OnPropertyChanged(nameof(HasErrors));
    }

    private void RemoveSelectedEntry()
    {
        if (SelectedEntry is null)
        {
            return;
        }

        Entries.Remove(SelectedEntry);
        SelectedEntry = Entries.FirstOrDefault();
        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Entries));
        OnPropertyChanged(nameof(HasErrors));
    }

    private bool CanMoveSelected(int delta)
    {
        if (_projectAccessor is null || SelectedEntry is null)
        {
            return false;
        }

        var index = Entries.IndexOf(SelectedEntry);
        return delta < 0 ? index > 0 : index >= 0 && index < Entries.Count - 1;
    }

    private void MoveSelected(int delta)
    {
        if (_projectAccessor is null || SelectedEntry is null)
        {
            return;
        }

        var index = Entries.IndexOf(SelectedEntry);
        var newIndex = index + delta;
        if (index < 0 || newIndex < 0 || newIndex >= Entries.Count)
        {
            return;
        }

        Entries.Move(index, newIndex);
        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Entries));
        MoveEntryUpCommand.RaiseCanExecuteChanged();
        MoveEntryDownCommand.RaiseCanExecuteChanged();
    }

    private void WireCurrentEntries()
    {
        if (_projectAccessor is null)
        {
            return;
        }

        foreach (var entry in Entries)
        {
            Wire(entry);
        }
    }

    private void Wire(RegistryEntry entry)
    {
        if (_wiredEntries.Add(entry))
        {
            entry.PropertyChanged += (_, _) =>
            {
                Changed?.Invoke(this, EventArgs.Empty);
                OnPropertyChanged(nameof(Entries));
                OnPropertyChanged(nameof(HasErrors));
                OnPropertyChanged(nameof(RegistryRoot));
                OnPropertyChanged(nameof(RegistryRootText));
            };
        }
    }
}

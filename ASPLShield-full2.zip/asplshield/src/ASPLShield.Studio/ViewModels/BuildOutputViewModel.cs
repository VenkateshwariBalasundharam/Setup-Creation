using System.Collections.ObjectModel;
using ASPLShield.Common;

namespace ASPLShield.Studio;

public sealed class BuildOutputViewModel : ObservableObject
{
    public BuildOutputViewModel()
    {
        ClearCommand = new RelayCommand(_ => Clear(), _ => Lines.Count > 0);
        Lines.CollectionChanged += (_, _) => ClearCommand.RaiseCanExecuteChanged();
    }

    public ObservableCollection<string> Lines { get; } = new();

    public RelayCommand ClearCommand { get; }

    public void Append(string message)
    {
        Lines.Add($"[{DateTime.Now:HH:mm:ss}] {message}");
        OnPropertyChanged(nameof(Lines));
    }

    public void Clear()
    {
        Lines.Clear();
        OnPropertyChanged(nameof(Lines));
    }
}

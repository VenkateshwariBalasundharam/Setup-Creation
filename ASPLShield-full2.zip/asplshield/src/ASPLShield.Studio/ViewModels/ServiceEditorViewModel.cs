using System.Collections.ObjectModel;
using ASPLShield.Common;
using ASPLShield.Core;

namespace ASPLShield.Studio;

public sealed class ServiceEditorViewModel : ObservableObject
{
    private Func<InstallerProject>? _projectAccessor;
    private ServiceEntry? _selectedService;
    private readonly HashSet<ServiceEntry> _wiredServices = new();

    public event EventHandler? Changed;

    public ServiceEditorViewModel()
    {
        AddServiceCommand = new RelayCommand(_ => AddService(), _ => true);
        RemoveServiceCommand = new RelayCommand(_ => RemoveSelectedService(), _ => SelectedService is not null);
        MoveServiceUpCommand = new RelayCommand(_ => MoveSelected(-1), _ => CanMoveSelected(-1));
        MoveServiceDownCommand = new RelayCommand(_ => MoveSelected(1), _ => CanMoveSelected(1));
    }

    public ObservableCollection<ServiceEntry> Services => _projectAccessor?.Invoke().Services ?? new ObservableCollection<ServiceEntry>();

    public ServiceEntry? SelectedService
    {
        get => _selectedService;
        set
        {
            if (SetProperty(ref _selectedService, value))
            {
                RemoveServiceCommand.RaiseCanExecuteChanged();
                MoveServiceUpCommand.RaiseCanExecuteChanged();
                MoveServiceDownCommand.RaiseCanExecuteChanged();
                OnPropertyChanged(nameof(DependencyText));
                OnPropertyChanged(nameof(AccountName));
                OnPropertyChanged(nameof(AccountPassword));
            }
        }
    }

    public string? AccountName
    {
        get => SelectedService?.AccountName;
        set
        {
            if (SelectedService is not null && value is not null)
            {
                SelectedService.AccountName = value;
                OnPropertyChanged();
            }
        }
    }

    public string? AccountPassword
    {
        get => SelectedService?.AccountPassword;
        set
        {
            if (SelectedService is not null)
            {
                SelectedService.AccountPassword = value;
                OnPropertyChanged();
            }
        }
    }

    public string DependencyText
    {
        get => SelectedService is null ? string.Empty : string.Join(", ", SelectedService.Dependencies);
        set
        {
            if (SelectedService is null)
            {
                return;
            }

            SelectedService.Dependencies = value
                .Split(new[] { ',', ';', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .ToList();
            OnPropertyChanged();
        }
    }

    public RelayCommand AddServiceCommand { get; }

    public RelayCommand RemoveServiceCommand { get; }

    public RelayCommand MoveServiceUpCommand { get; }

    public RelayCommand MoveServiceDownCommand { get; }

    public bool HasErrors => Services.Any(service => string.IsNullOrWhiteSpace(service.ServiceName) || string.IsNullOrWhiteSpace(service.ExecutablePath));

    public void Bind(Func<InstallerProject> projectAccessor) => _projectAccessor = projectAccessor;

    public void Refresh()
    {
        WireCurrentServices();
        OnPropertyChanged(nameof(Services));
        OnPropertyChanged(nameof(HasErrors));
        OnPropertyChanged(nameof(AccountName));
        OnPropertyChanged(nameof(AccountPassword));
        OnPropertyChanged(nameof(DependencyText));
    }

    private void AddService()
    {
        var project = _projectAccessor?.Invoke();
        if (project is null)
        {
            return;
        }

        var defaultTarget = project.Files.FirstOrDefault()?.DestinationPath ?? $"{project.ProductName}.exe";
        var service = new ServiceEntry
        {
            ServiceName = $"{project.ProductName}Service",
            DisplayName = $"{project.ProductName} Service",
            ExecutablePath = defaultTarget,
            AutoStart = true,
            DelayedAutoStart = false
        };

        Wire(service);
        project.Services.Add(service);
        SelectedService = service;
        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Services));
        OnPropertyChanged(nameof(HasErrors));
    }

    private void RemoveSelectedService()
    {
        if (SelectedService is null)
        {
            return;
        }

        Services.Remove(SelectedService);
        SelectedService = Services.FirstOrDefault();
        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Services));
        OnPropertyChanged(nameof(HasErrors));
    }

    private bool CanMoveSelected(int delta)
    {
        if (_projectAccessor is null || SelectedService is null)
        {
            return false;
        }

        var index = Services.IndexOf(SelectedService);
        return delta < 0 ? index > 0 : index >= 0 && index < Services.Count - 1;
    }

    private void MoveSelected(int delta)
    {
        if (_projectAccessor is null || SelectedService is null)
        {
            return;
        }

        var index = Services.IndexOf(SelectedService);
        var newIndex = index + delta;
        if (index < 0 || newIndex < 0 || newIndex >= Services.Count)
        {
            return;
        }

        Services.Move(index, newIndex);
        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Services));
        MoveServiceUpCommand.RaiseCanExecuteChanged();
        MoveServiceDownCommand.RaiseCanExecuteChanged();
    }

    private void WireCurrentServices()
    {
        if (_projectAccessor is null)
        {
            return;
        }

        foreach (var service in Services)
        {
            Wire(service);
        }
    }

    private void Wire(ServiceEntry service)
    {
        if (_wiredServices.Add(service))
        {
            service.PropertyChanged += (_, _) =>
            {
                Changed?.Invoke(this, EventArgs.Empty);
                OnPropertyChanged(nameof(Services));
                OnPropertyChanged(nameof(HasErrors));
            };
        }
    }
}

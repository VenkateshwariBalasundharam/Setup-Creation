using System.Collections.ObjectModel;
using System.Collections.Specialized;
using ASPLShield.Common;
using ASPLShield.Core;

namespace ASPLShield.Studio;

public sealed class IisEditorViewModel : ObservableObject
{
    private Func<InstallerProject>? _projectAccessor;
    private IisSiteEntry? _selectedSite;
    private IisSiteBindingEntry? _selectedBinding;
    private bool _isSynchronizingBindings;
    private readonly ObservableCollection<IisSiteBindingEntry> _bindings = new();
    private readonly HashSet<IisSiteEntry> _wiredSites = new();
    private readonly HashSet<IisSiteBindingEntry> _wiredBindings = new();

    public event EventHandler? Changed;

    public IisEditorViewModel()
    {
        AddSiteCommand = new RelayCommand(_ => AddSite(), _ => true);
        RemoveSiteCommand = new RelayCommand(_ => RemoveSelectedSite(), _ => SelectedSite is not null);
        MoveSiteUpCommand = new RelayCommand(_ => MoveSelectedSite(-1), _ => CanMoveSelectedSite(-1));
        MoveSiteDownCommand = new RelayCommand(_ => MoveSelectedSite(1), _ => CanMoveSelectedSite(1));
        AddBindingCommand = new RelayCommand(_ => AddBinding(), _ => SelectedSite is not null);
        RemoveBindingCommand = new RelayCommand(_ => RemoveSelectedBinding(), _ => SelectedBinding is not null);
        MoveBindingUpCommand = new RelayCommand(_ => MoveSelectedBinding(-1), _ => CanMoveSelectedBinding(-1));
        MoveBindingDownCommand = new RelayCommand(_ => MoveSelectedBinding(1), _ => CanMoveSelectedBinding(1));
        _bindings.CollectionChanged += Bindings_CollectionChanged;
    }

    public ObservableCollection<IisSiteEntry> Sites => _projectAccessor?.Invoke().IisSites ?? new ObservableCollection<IisSiteEntry>();

    public ObservableCollection<IisSiteBindingEntry> Bindings => _bindings;

    public IisSiteEntry? SelectedSite
    {
        get => _selectedSite;
        set
        {
            if (SetProperty(ref _selectedSite, value))
            {
                RemoveSiteCommand.RaiseCanExecuteChanged();
                MoveSiteUpCommand.RaiseCanExecuteChanged();
                MoveSiteDownCommand.RaiseCanExecuteChanged();
                AddBindingCommand.RaiseCanExecuteChanged();
                SyncBindingsFromSelectedSite();
                Changed?.Invoke(this, EventArgs.Empty);
            }
        }
    }

    public IisSiteBindingEntry? SelectedBinding
    {
        get => _selectedBinding;
        set
        {
            if (SetProperty(ref _selectedBinding, value))
            {
                RemoveBindingCommand.RaiseCanExecuteChanged();
                MoveBindingUpCommand.RaiseCanExecuteChanged();
                MoveBindingDownCommand.RaiseCanExecuteChanged();
            }
        }
    }

    public RelayCommand AddSiteCommand { get; }

    public RelayCommand RemoveSiteCommand { get; }

    public RelayCommand MoveSiteUpCommand { get; }

    public RelayCommand MoveSiteDownCommand { get; }

    public RelayCommand AddBindingCommand { get; }

    public RelayCommand RemoveBindingCommand { get; }

    public RelayCommand MoveBindingUpCommand { get; }

    public RelayCommand MoveBindingDownCommand { get; }

    public void Bind(Func<InstallerProject> projectAccessor) => _projectAccessor = projectAccessor;

    public void Refresh()
    {
        WireCurrentSites();
        OnPropertyChanged(nameof(Sites));
        OnPropertyChanged(nameof(Bindings));
        if (SelectedSite is not null && !Sites.Contains(SelectedSite))
        {
            SelectedSite = Sites.FirstOrDefault();
        }
        else
        {
            SyncBindingsFromSelectedSite();
        }
    }

    private void AddSite()
    {
        var project = _projectAccessor?.Invoke();
        if (project is null)
        {
            return;
        }

        var site = new IisSiteEntry
        {
            SiteName = $"{project.ProductName} Site",
            PhysicalPath = project.InstallationFolder,
            ApplicationPoolName = $"{project.ProductName}Pool",
            CreateApplicationPool = true,
            StartOnInstall = true,
            Bindings = new List<IisSiteBindingEntry>
            {
                new() { Protocol = "http", BindingInformation = "*:80:" }
            }
        };

        WireSite(site);
        foreach (var binding in site.Bindings)
        {
            WireBinding(binding);
        }
        project.IisSites.Add(site);
        SelectedSite = site;
        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Sites));
    }

    private void RemoveSelectedSite()
    {
        if (SelectedSite is null || _projectAccessor is null)
        {
            return;
        }

        Sites.Remove(SelectedSite);
        SelectedSite = Sites.FirstOrDefault();
        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Sites));
    }

    private bool CanMoveSelectedSite(int delta)
    {
        if (_projectAccessor is null || SelectedSite is null)
        {
            return false;
        }

        var index = Sites.IndexOf(SelectedSite);
        return delta < 0 ? index > 0 : index >= 0 && index < Sites.Count - 1;
    }

    private void MoveSelectedSite(int delta)
    {
        if (_projectAccessor is null || SelectedSite is null)
        {
            return;
        }

        var index = Sites.IndexOf(SelectedSite);
        var newIndex = index + delta;
        if (index < 0 || newIndex < 0 || newIndex >= Sites.Count)
        {
            return;
        }

        Sites.Move(index, newIndex);
        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Sites));
        MoveSiteUpCommand.RaiseCanExecuteChanged();
        MoveSiteDownCommand.RaiseCanExecuteChanged();
    }

    private void AddBinding()
    {
        if (SelectedSite is null)
        {
            return;
        }

        Bindings.Add(new IisSiteBindingEntry { Protocol = "http", BindingInformation = "*:80:" });
        PushBindingsToSelectedSite();
        Changed?.Invoke(this, EventArgs.Empty);
    }

    private void RemoveSelectedBinding()
    {
        if (SelectedBinding is null)
        {
            return;
        }

        Bindings.Remove(SelectedBinding);
        SelectedBinding = Bindings.FirstOrDefault();
        PushBindingsToSelectedSite();
        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Bindings));
    }

    private bool CanMoveSelectedBinding(int delta)
    {
        if (SelectedBinding is null)
        {
            return false;
        }

        var index = Bindings.IndexOf(SelectedBinding);
        return delta < 0 ? index > 0 : index >= 0 && index < Bindings.Count - 1;
    }

    private void MoveSelectedBinding(int delta)
    {
        if (SelectedBinding is null)
        {
            return;
        }

        var index = Bindings.IndexOf(SelectedBinding);
        var newIndex = index + delta;
        if (index < 0 || newIndex < 0 || newIndex >= Bindings.Count)
        {
            return;
        }

        Bindings.Move(index, newIndex);
        PushBindingsToSelectedSite();
        Changed?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(Bindings));
        MoveBindingUpCommand.RaiseCanExecuteChanged();
        MoveBindingDownCommand.RaiseCanExecuteChanged();
    }

    private void SyncBindingsFromSelectedSite()
    {
        if (_isSynchronizingBindings)
        {
            return;
        }

        try
        {
            _isSynchronizingBindings = true;
            _bindings.Clear();
            if (SelectedSite is not null)
            {
                foreach (var binding in SelectedSite.Bindings)
                {
                    WireBinding(binding);
                    _bindings.Add(binding);
                }
            }

            SelectedBinding = _bindings.FirstOrDefault();
        }
        finally
        {
            _isSynchronizingBindings = false;
        }
    }

    private void PushBindingsToSelectedSite()
    {
        if (_isSynchronizingBindings || SelectedSite is null)
        {
            return;
        }

        SelectedSite.Bindings = _bindings.ToList();
    }

    private void Bindings_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
    {
        if (_isSynchronizingBindings)
        {
            return;
        }

        PushBindingsToSelectedSite();
        OnPropertyChanged(nameof(Bindings));
    }

    private void WireCurrentSites()
    {
        if (_projectAccessor is null)
        {
            return;
        }

        foreach (var site in Sites)
        {
            WireSite(site);
            foreach (var binding in site.Bindings)
            {
                WireBinding(binding);
            }
        }
    }

    private void WireSite(IisSiteEntry site)
    {
        if (_wiredSites.Add(site))
        {
            site.PropertyChanged += (_, _) =>
            {
                Changed?.Invoke(this, EventArgs.Empty);
                OnPropertyChanged(nameof(Sites));
            };
        }
    }

    private void WireBinding(IisSiteBindingEntry binding)
    {
        if (_wiredBindings.Add(binding))
        {
            binding.PropertyChanged += (_, _) =>
            {
                Changed?.Invoke(this, EventArgs.Empty);
                OnPropertyChanged(nameof(Bindings));
            };
        }
    }
}

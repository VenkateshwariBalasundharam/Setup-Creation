using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Text.Json;
using ASPLShield.Build;
using ASPLShield.Common;
using ASPLShield.Core;
using ASPLShield.PackageEngine;
using ASPLShield.ServiceInstaller;
using ASPLShield.UpdateEngine;
using Microsoft.Extensions.Logging;
using Microsoft.Win32;

namespace ASPLShield.Studio;

public sealed class MainViewModel : ObservableObject, IDisposable
{
    private readonly IStudioLogMonitorService _logMonitor;
    private readonly IStudioShellService _shellService;
    private readonly IStudioBuildWorkflowService _buildWorkflow;
    private readonly IStudioNativePreviewService _nativePreviewService;
    private readonly IStudioProjectSessionService _projectSession;
    private readonly IStudioRefreshService _refreshService;
    private readonly IProjectRepository _projectRepository;
    private readonly IProjectSerializer _projectSerializer;
    private readonly UpdateEngineClient _updateEngineClient;
    private readonly ILogger<MainViewModel> _logger;
    private string _statusText = "Ready";
    private string? _currentProjectPath;
    private InstallerProject _project = ProjectFactory.CreateDefault();
    private string? _detectedSetupProjectPath;
    private string? _detectedUninstallerProjectPath;
    private string _buildTooltip = "Build project";
    private string _recentLogsSummary = "No log entries loaded.";
    private string _updateCheckStatus = "Update feed not checked.";
    private string _templateStatus = "No templates loaded.";
    private ProjectTemplateEntry? _selectedTemplate;

    public MainViewModel(
        IStudioLogMonitorService logMonitor,
        IStudioShellService shellService,
        IStudioBuildWorkflowService buildWorkflow,
        IStudioNativePreviewService nativePreviewService,
        IStudioProjectSessionService projectSession,
        IStudioRefreshService refreshService,
        IProjectRepository projectRepository,
        IProjectSerializer projectSerializer,
        UpdateEngineClient updateEngineClient,
        ProjectExplorerViewModel explorer,
        FileSystemEditorViewModel files,
        ShortcutEditorViewModel shortcuts,
        IisEditorViewModel iis,
        RegistryEditorViewModel registry,
        ServiceEditorViewModel services,
        PropertiesViewModel properties,
        StudioThemeViewModel theme,
        BuildOutputViewModel buildOutput,
        ILogger<MainViewModel> logger)
    {
        _logMonitor = logMonitor;
        _shellService = shellService;
        _buildWorkflow = buildWorkflow;
        _nativePreviewService = nativePreviewService;
        _projectSession = projectSession;
        _refreshService = refreshService;
        _projectRepository = projectRepository;
        _projectSerializer = projectSerializer;
        _updateEngineClient = updateEngineClient;
        _logger = logger;

        Explorer = explorer;
        Files = files;
        Shortcuts = shortcuts;
        Iis = iis;
        Registry = registry;
        Services = services;
        Properties = properties;
        Theme = theme;
        BuildOutput = buildOutput;

        Explorer.Bind(() => Project);
        Files.Bind(() => Project);
        Shortcuts.Bind(() => Project);
        Iis.Bind(() => Project);
        Registry.Bind(() => Project);
        Services.Bind(() => Project);
        Properties.Bind(() => Project, () => Files.SelectedFile, () => Shortcuts.SelectedShortcut);
        Properties.Integration.PropertyChanged += (_, _) => RefreshAll();
        Properties.BuildEditor.Changed += (_, _) => RefreshAll();
        Properties.PrerequisiteEditor.Changed += (_, _) => RefreshAll();
        Files.Changed += (_, _) => RefreshAll();
        Shortcuts.Changed += (_, _) => RefreshAll();
        Iis.Changed += (_, _) => RefreshAll();
        Registry.Changed += (_, _) => RefreshAll();
        Services.Changed += (_, _) => RefreshAll();
        Project.PropertyChanged += (_, _) => RefreshAll();
        Properties.NativePreview.MergePersistedOperations(_project.NativePreviewOperations);

        NewProjectCommand = new AsyncRelayCommand(_ => NewProjectAsync());
        OpenProjectCommand = new AsyncRelayCommand(_ => OpenProjectAsync());
        OpenFolderCommand = new AsyncRelayCommand(_ => OpenFolderAsync());
        OpenRecentProjectCommand = new AsyncRelayCommand((parameter, _) => OpenRecentProjectAsync(parameter as RecentProjectEntry));
        ClearRecentProjectsCommand = new AsyncRelayCommand(_ => ClearRecentProjectsAsync());
        SaveProjectCommand = new AsyncRelayCommand(_ => SaveProjectAsync());
        SaveProjectAsCommand = new AsyncRelayCommand(_ => SaveProjectAsAsync());
        BuildCommand = new AsyncRelayCommand(_ => BuildAsync(), _ => CanBuild());
        BuildAndRunCommand = new AsyncRelayCommand(_ => BuildAndRunAsync(), _ => CanBuild());
        RebuildCommand = new AsyncRelayCommand(_ => RebuildAsync(), _ => CanBuild());
        CleanCommand = new RelayCommand(_ => Clean());
        ExportNativeDatabaseCommand = new AsyncRelayCommand(_ => ExportNativeDatabaseAsync(), _ => !string.IsNullOrWhiteSpace(NativePreview.DatabasePath));
        CheckUpdatesCommand = new AsyncRelayCommand(_ => CheckUpdatesAsync());
        RefreshTemplatesCommand = new AsyncRelayCommand(_ => RefreshTemplatesAsync());
        SaveTemplateCommand = new AsyncRelayCommand(_ => SaveTemplateAsync());
        ApplyTemplateCommand = new AsyncRelayCommand(_ => ApplyTemplateAsync(), _ => SelectedTemplate is not null);
        DeleteTemplateCommand = new AsyncRelayCommand(_ => DeleteTemplateAsync(), _ => SelectedTemplate is not null);
        ExitCommand = new RelayCommand(_ => System.Windows.Application.Current.Shutdown());
        OpenLogsFolderCommand = new RelayCommand(_ => _shellService.OpenFolderInExplorer(_logMonitor.LogsDirectoryPath));
        OpenOutputFolderCommand = new RelayCommand(_ =>
        {
            // OpenFolderInExplorer creates the folder if it doesn't exist yet (e.g. before the first build).
            if (_shellService.CanOpenPhysicalFolder(Project.OutputFolder))
            {
                _shellService.OpenFolderInExplorer(Project.OutputFolder);
            }
        }, _ => CanOpenOutputFolder());
        OpenInstallFolderCommand = new RelayCommand(_ =>
        {
            if (_shellService.CanOpenPhysicalFolder(DiagnosticsInstallFolderPath))
            {
                _shellService.OpenFolderInExplorer(DiagnosticsInstallFolderPath);
            }
        }, _ => _shellService.CanOpenPhysicalFolder(DiagnosticsInstallFolderPath));
        RefreshLogsCommand = new RelayCommand(_ => RefreshAll());
        _logMonitor.Changed += (_, _) => QueueRefreshRecentLogs();
        _logMonitor.Start();

        RefreshAll();
        _ = RefreshTemplatesAsync();
        _ = RefreshRecentProjectsAsync();
    }

    public InstallerProject Project
    {
        get => _project;
        private set
        {
            if (SetProperty(ref _project, value))
            {
                _project.PropertyChanged += (_, _) => RefreshAll();
                Properties.NativePreview.LoadFromProject(value);
                RefreshAll();
            }
        }
    }

    public ProjectExplorerViewModel Explorer { get; }

    public FileSystemEditorViewModel Files { get; }

    public ShortcutEditorViewModel Shortcuts { get; }

    public IisEditorViewModel Iis { get; }

    public RegistryEditorViewModel Registry { get; }

    public ServiceEditorViewModel Services { get; }

    public PropertiesViewModel Properties { get; }

    public StudioThemeViewModel Theme { get; }

    public BuildOutputViewModel BuildOutput { get; }

    public NativePreviewViewModel NativePreview => Properties.NativePreview;

    public ObservableCollection<RecentProjectEntry> RecentProjects { get; } = new();

    public ObservableCollection<string> ValidationMessages { get; } = new();

    public ObservableCollection<string> IisWarnings { get; } = new();

    public string? DetectedSetupProjectPath
    {
        get => _detectedSetupProjectPath;
        private set => SetProperty(ref _detectedSetupProjectPath, value);
    }

    public string? DetectedUninstallerProjectPath
    {
        get => _detectedUninstallerProjectPath;
        private set => SetProperty(ref _detectedUninstallerProjectPath, value);
    }

    public string StatusText
    {
        get => _statusText;
        private set => SetProperty(ref _statusText, value);
    }

    public string? CurrentProjectPath
    {
        get => _currentProjectPath;
        private set => SetProperty(ref _currentProjectPath, value);
    }

    public AsyncRelayCommand NewProjectCommand { get; }

    public AsyncRelayCommand OpenProjectCommand { get; }

    public AsyncRelayCommand OpenFolderCommand { get; }

    public AsyncRelayCommand OpenRecentProjectCommand { get; }

    public AsyncRelayCommand ClearRecentProjectsCommand { get; }

    public AsyncRelayCommand SaveProjectCommand { get; }

    public AsyncRelayCommand SaveProjectAsCommand { get; }

    public AsyncRelayCommand BuildCommand { get; }

    public AsyncRelayCommand BuildAndRunCommand { get; }

    public AsyncRelayCommand RebuildCommand { get; }

    public RelayCommand CleanCommand { get; }

    public AsyncRelayCommand ExportNativeDatabaseCommand { get; }

    public AsyncRelayCommand CheckUpdatesCommand { get; }

    public AsyncRelayCommand RefreshTemplatesCommand { get; }

    public AsyncRelayCommand SaveTemplateCommand { get; }

    public AsyncRelayCommand ApplyTemplateCommand { get; }

    public AsyncRelayCommand DeleteTemplateCommand { get; }

    public RelayCommand ExitCommand { get; }

    public RelayCommand OpenLogsFolderCommand { get; }

    public RelayCommand OpenOutputFolderCommand { get; }

    public RelayCommand OpenInstallFolderCommand { get; }

    public RelayCommand RefreshLogsCommand { get; }

    public string BuildTooltip
    {
        get => _buildTooltip;
        private set => SetProperty(ref _buildTooltip, value);
    }

    public string DiagnosticsUpdateFeed => string.IsNullOrWhiteSpace(Properties.Integration.UpdateFeedUri)
        ? "Update feed not configured"
        : Properties.Integration.UpdateFeedUri;

    public string DiagnosticsInstallLogPath => Path.Combine(Path.GetTempPath(), "ASPLShield", "Logs", "install.log");

    public string DiagnosticsUninstallLogPath => Path.Combine(Path.GetTempPath(), "ASPLShield", "Logs", "uninstall.log");

    public string DiagnosticsInstallStateHint => "Installation state is written to asplshield.installstate.json inside the installed folder.";

    public string DiagnosticsInstallFolderPath => Properties.ProjectEditor.InstallationFolder ?? string.Empty;

    public ObservableCollection<string> RecentLogEntries { get; } = new();

    public string RecentLogsSummary
    {
        get => _recentLogsSummary;
        private set => SetProperty(ref _recentLogsSummary, value);
    }

    public string UpdateCheckStatus
    {
        get => _updateCheckStatus;
        private set => SetProperty(ref _updateCheckStatus, value);
    }

    public string TemplateStatus
    {
        get => _templateStatus;
        private set => SetProperty(ref _templateStatus, value);
    }

    public ObservableCollection<ProjectTemplateEntry> ProjectTemplates { get; } = new();

    public ProjectTemplateEntry? SelectedTemplate
    {
        get => _selectedTemplate;
        set
        {
            if (SetProperty(ref _selectedTemplate, value))
            {
                ApplyTemplateCommand.RaiseCanExecuteChanged();
                DeleteTemplateCommand.RaiseCanExecuteChanged();
            }
        }
    }

    public void Dispose()
    {
        _logMonitor.Dispose();
    }

    private async Task NewProjectAsync()
    {
        var result = _projectSession.CreateNew();
        if (!result.Succeeded || result.Project is null)
        {
            return;
        }

        Project = result.Project;
        CurrentProjectPath = null;
        StatusText = result.StatusText;
        if (!string.IsNullOrWhiteSpace(result.OutputMessage))
        {
            BuildOutput.Append(result.OutputMessage);
        }
        await Task.CompletedTask;
    }

    private async Task OpenProjectAsync()
    {
        var result = await _projectSession.OpenAsync().ConfigureAwait(true);
        if (!result.Succeeded || result.Project is null)
        {
            StatusText = result.StatusText;
            return;
        }

        Project = result.Project;
        CurrentProjectPath = result.ProjectPath;
        StatusText = result.StatusText;
        if (!string.IsNullOrWhiteSpace(result.OutputMessage))
        {
            BuildOutput.Append(result.OutputMessage);
        }

        await RefreshRecentProjectsAsync().ConfigureAwait(true);
    }

    private async Task SaveProjectAsync()
    {
        var result = await _projectSession.SaveAsync(Project, CurrentProjectPath, Properties.NativePreview).ConfigureAwait(true);
        if (!result.Succeeded || result.Project is null || string.IsNullOrWhiteSpace(result.ProjectPath))
        {
            return;
        }

        CurrentProjectPath = result.ProjectPath;
        StatusText = result.StatusText;
        if (!string.IsNullOrWhiteSpace(result.OutputMessage))
        {
            BuildOutput.Append(result.OutputMessage);
        }

        await RefreshRecentProjectsAsync().ConfigureAwait(true);
    }

    private async Task SaveProjectAsAsync()
    {
        var result = await _projectSession.SaveAsAsync(Project, Properties.NativePreview).ConfigureAwait(true);
        if (!result.Succeeded || result.Project is null || string.IsNullOrWhiteSpace(result.ProjectPath))
        {
            return;
        }

        CurrentProjectPath = result.ProjectPath;
        StatusText = result.StatusText;
        if (!string.IsNullOrWhiteSpace(result.OutputMessage))
        {
            BuildOutput.Append(result.OutputMessage);
        }

        await RefreshRecentProjectsAsync().ConfigureAwait(true);
    }

    private async Task OpenFolderAsync()
    {
        var folder = _projectSession.SelectProjectFolder();
        if (string.IsNullOrWhiteSpace(folder))
        {
            return;
        }

        var projectFile = Directory.EnumerateFiles(folder, "*.asplproj").FirstOrDefault();
        if (string.IsNullOrWhiteSpace(projectFile))
        {
            StatusText = $"No .asplproj file was found in '{folder}'.";
            return;
        }

        await OpenRecentProjectAsync(projectFile).ConfigureAwait(true);
    }

    private async Task OpenRecentProjectAsync(RecentProjectEntry? entry)
    {
        if (entry is null)
        {
            return;
        }

        await OpenRecentProjectAsync(entry.ProjectPath).ConfigureAwait(true);
    }

    private async Task OpenRecentProjectAsync(string projectPath)
    {
        var result = await _projectSession.OpenAsync(projectPath).ConfigureAwait(true);
        if (!result.Succeeded || result.Project is null)
        {
            StatusText = result.StatusText;
            return;
        }

        Project = result.Project;
        CurrentProjectPath = result.ProjectPath;
        StatusText = result.StatusText;
        if (!string.IsNullOrWhiteSpace(result.OutputMessage))
        {
            BuildOutput.Append(result.OutputMessage);
        }

        await RefreshRecentProjectsAsync().ConfigureAwait(true);
    }

    private async Task RefreshRecentProjectsAsync()
    {
        var recent = await _projectRepository.GetRecentProjectsAsync().ConfigureAwait(true);
        RecentProjects.Clear();
        foreach (var entry in recent)
        {
            RecentProjects.Add(entry);
        }
    }

    private async Task ClearRecentProjectsAsync()
    {
        await _projectRepository.ClearRecentProjectsAsync().ConfigureAwait(true);
        RecentProjects.Clear();
        StatusText = "Recent projects list cleared.";
    }

    private async Task BuildAsync()
    {
        if (string.IsNullOrWhiteSpace(CurrentProjectPath))
        {
            await SaveProjectAsync().ConfigureAwait(true);
        }
        if (string.IsNullOrWhiteSpace(CurrentProjectPath))
        {
            return;
        }

        var outcome = await _buildWorkflow.BuildAsync(
            Project,
            CurrentProjectPath,
            Project.OutputFolder,
            StudioPaths.LocateRuntimeProjectPath(),
            StudioPaths.LocateUninstallerProjectPath(),
            IisWarnings).ConfigureAwait(true);

        foreach (var message in outcome.Messages)
        {
            BuildOutput.Append(message);
        }

        StatusText = outcome.StatusText ?? StatusText;

        if (!outcome.Succeeded || outcome.BuildResult is null)
        {
            return;
        }

        var result = outcome.BuildResult;
        if (!string.IsNullOrWhiteSpace(result.MsiAuthoringPath))
        {
            if (Project.Build.MsiAuthoringMode == MsiAuthoringMode.NativePreview)
            {
                await _nativePreviewService.LoadAsync(Properties.NativePreview, Project, result.MsiAuthoringPath, result.MsiDatabasePath).ConfigureAwait(true);
                Properties.NativePreview.MergePersistedOperations(Project.NativePreviewOperations);
                ExportNativeDatabaseCommand.RaiseCanExecuteChanged();
            }
            else
            {
                Properties.NativePreview.Clear();
            }
        }

        if (Project.Build.CreateUninstaller)
        {
            StatusText = "Build completed successfully.";
        }
    }

    private async Task BuildAndRunAsync()
    {
        await BuildAsync().ConfigureAwait(true);

        var setupExePath = Path.Combine(Project.OutputFolder, Project.Build.SetupExecutableName);
        if (!File.Exists(setupExePath))
        {
            BuildOutput.Append($"Build & Run: could not find '{setupExePath}' to launch.");
            return;
        }

        try
        {
            Process.Start(new ProcessStartInfo(setupExePath) { UseShellExecute = true });
            BuildOutput.Append($"Launched: {setupExePath}");
        }
        catch (Exception ex)
        {
            BuildOutput.Append($"Build & Run failed to launch the installer: {ex.Message}");
        }
    }

    private async Task RebuildAsync()
    {
        Clean();
        await BuildAsync().ConfigureAwait(true);
    }

    private void Clean()
    {
        foreach (var message in _buildWorkflow.Clean(Project.OutputFolder))
        {
            BuildOutput.Append(message);
        }

        StatusText = "Clean completed.";
    }

    private async Task ExportNativeDatabaseAsync()
    {
        var exportedPath = await _nativePreviewService.ExportAsync(NativePreview.DatabasePath, $"{Project.ProductName}.native-msi-database.msi").ConfigureAwait(true);
        if (string.IsNullOrWhiteSpace(exportedPath))
        {
            BuildOutput.Append("No native MSI database is available to export.");
            return;
        }

        BuildOutput.Append($"Native MSI database exported: {exportedPath}");
        StatusText = "Native database exported.";
    }

    private async Task CheckUpdatesAsync()
    {
        var updateFeed = Properties.Integration.UpdateFeedUri;
        if (string.IsNullOrWhiteSpace(updateFeed))
        {
            UpdateCheckStatus = "Set an update feed URI first.";
            StatusText = UpdateCheckStatus;
            BuildOutput.Append(UpdateCheckStatus);
            return;
        }

        if (!TryCreateFeedUri(updateFeed, out var feedUri) || feedUri is null)
        {
            UpdateCheckStatus = "The configured update feed URI is invalid.";
            StatusText = UpdateCheckStatus;
            BuildOutput.Append(UpdateCheckStatus);
            return;
        }

        try
        {
            var result = await _updateEngineClient.CheckForUpdatesAsync(feedUri).ConfigureAwait(true);
            UpdateCheckStatus = result.Message ?? "Update check completed.";
            StatusText = UpdateCheckStatus;
            BuildOutput.Append(UpdateCheckStatus);
            if (result.HasUpdate && result.Package is not null)
            {
                BuildOutput.Append($"Update package {result.Package.CurrentVersion} -> {result.Package.LatestVersion}: {result.Package.DownloadUrl}");
                if (!string.IsNullOrWhiteSpace(result.Package.ReleaseNotes))
                {
                    BuildOutput.Append(result.Package.ReleaseNotes);
                }
            }
        }
        catch (Exception ex)
        {
            UpdateCheckStatus = $"Update check failed: {ex.Message}";
            StatusText = UpdateCheckStatus;
            BuildOutput.Append(UpdateCheckStatus);
        }
    }

    private async Task RefreshTemplatesAsync()
    {
        var templates = await _projectRepository.GetTemplatesAsync().ConfigureAwait(true);
        ProjectTemplates.Clear();
        foreach (var template in templates)
        {
            ProjectTemplates.Add(template);
        }

        TemplateStatus = templates.Count == 0
            ? "No templates saved yet."
            : $"{templates.Count} template{(templates.Count == 1 ? string.Empty : "s")} available.";
    }

    private async Task SaveTemplateAsync()
    {
        var templatesRoot = PathUtilities.EnsureDirectory(StudioPaths.TemplatesPath);
        var baseName = SanitizeFileName(Project.ProductName);
        var templatePath = Path.Combine(templatesRoot, $"{baseName}.asplproj");
        await _projectSerializer.SaveAsync(Project, templatePath).ConfigureAwait(true);

        var existing = ProjectTemplates.FirstOrDefault(template => string.Equals(template.TemplatePath, templatePath, StringComparison.OrdinalIgnoreCase));
        var templateEntry = existing ?? new ProjectTemplateEntry
        {
            Name = Project.ProductName,
            Description = $"{Project.ProductName} template",
            TemplatePath = templatePath
        };

        templateEntry.Name = Project.ProductName;
        templateEntry.Description = $"{Project.ProductName} template";
        templateEntry.TemplatePath = templatePath;

        await _projectRepository.SaveTemplateAsync(templateEntry).ConfigureAwait(true);
        await RefreshTemplatesAsync().ConfigureAwait(true);
        TemplateStatus = $"Saved template: {templateEntry.Name}";
        StatusText = TemplateStatus;
        BuildOutput.Append(TemplateStatus);
    }

    private async Task ApplyTemplateAsync()
    {
        if (SelectedTemplate is null)
        {
            return;
        }

        if (!File.Exists(SelectedTemplate.TemplatePath))
        {
            TemplateStatus = $"Template file missing: {SelectedTemplate.TemplatePath}";
            StatusText = TemplateStatus;
            BuildOutput.Append(TemplateStatus);
            return;
        }

        var loaded = await _projectSerializer.LoadAsync(SelectedTemplate.TemplatePath).ConfigureAwait(true);
        Project = loaded;
        CurrentProjectPath = null;
        TemplateStatus = $"Applied template: {SelectedTemplate.Name}";
        StatusText = TemplateStatus;
        BuildOutput.Append(TemplateStatus);
        RefreshAll();
    }

    private async Task DeleteTemplateAsync()
    {
        if (SelectedTemplate is null)
        {
            return;
        }

        var template = SelectedTemplate;
        await _projectRepository.DeleteTemplateAsync(template.Id).ConfigureAwait(true);
        if (File.Exists(template.TemplatePath))
        {
            File.Delete(template.TemplatePath);
        }

        SelectedTemplate = null;
        await RefreshTemplatesAsync().ConfigureAwait(true);
        TemplateStatus = $"Deleted template: {template.Name}";
        StatusText = TemplateStatus;
        BuildOutput.Append(TemplateStatus);
    }

    private void RefreshAll()
    {
        var snapshot = _refreshService.Refresh(Project, Properties, Registry.HasErrors, Services.HasErrors);
        DetectedSetupProjectPath = snapshot.SetupProjectPath;
        DetectedUninstallerProjectPath = snapshot.UninstallerProjectPath;
        ValidationMessages.Clear();
        foreach (var message in snapshot.ValidationMessages)
        {
            ValidationMessages.Add(message);
        }

        IisWarnings.Clear();
        foreach (var warning in snapshot.IisWarnings)
        {
            IisWarnings.Add(warning);
        }

        Explorer.Refresh();
        Files.Refresh();
        Shortcuts.Refresh();
        Iis.Refresh();
        Registry.Refresh();
        Services.Refresh();
        Properties.Refresh();
        BuildTooltip = snapshot.BuildTooltip;
        RecentLogEntries.Clear();
        foreach (var line in snapshot.RecentLogEntries)
        {
            RecentLogEntries.Add(line);
        }
        RecentLogsSummary = snapshot.RecentLogsSummary;
        OnPropertyChanged(nameof(DiagnosticsUpdateFeed));
        OnPropertyChanged(nameof(DiagnosticsInstallLogPath));
        OnPropertyChanged(nameof(DiagnosticsUninstallLogPath));
        OnPropertyChanged(nameof(DiagnosticsInstallStateHint));
        OnPropertyChanged(nameof(DiagnosticsInstallFolderPath));
        OnPropertyChanged(nameof(RecentLogsSummary));
        OnPropertyChanged(nameof(UpdateCheckStatus));
        OnPropertyChanged(nameof(TemplateStatus));
        BuildCommand.RaiseCanExecuteChanged();
        BuildAndRunCommand.RaiseCanExecuteChanged();
        RebuildCommand.RaiseCanExecuteChanged();
        ExportNativeDatabaseCommand.RaiseCanExecuteChanged();
        CheckUpdatesCommand.RaiseCanExecuteChanged();
        RefreshTemplatesCommand.RaiseCanExecuteChanged();
        SaveTemplateCommand.RaiseCanExecuteChanged();
        ApplyTemplateCommand.RaiseCanExecuteChanged();
        DeleteTemplateCommand.RaiseCanExecuteChanged();
        OpenInstallFolderCommand.RaiseCanExecuteChanged();
        OpenOutputFolderCommand.RaiseCanExecuteChanged();
    }

    // IisWarnings are advisory information about the *current* machine (e.g. "not running
    // elevated", "IIS management tools not installed"). They describe the environment the
    // installer will eventually run in, not the machine doing the packaging, so they must
    // not block Build. Only real project validation errors (ValidationMessages) gate it.
    private bool CanBuild() => ValidationMessages.Count == 0;

    private bool CanOpenOutputFolder()
        => _shellService.CanOpenPhysicalFolder(Project.OutputFolder);

    private void QueueRefreshRecentLogs()
    {
        var dispatcher = System.Windows.Application.Current?.Dispatcher;
        if (dispatcher is null || dispatcher.CheckAccess())
        {
            RefreshAll();
            return;
        }

        _ = dispatcher.InvokeAsync(RefreshAll);
    }

    private static bool TryCreateFeedUri(string configured, out Uri? uri)
    {
        if (Uri.TryCreate(configured, UriKind.Absolute, out uri))
        {
            return true;
        }

        if (File.Exists(configured))
        {
            uri = new Uri(Path.GetFullPath(configured));
            return true;
        }

        uri = null;
        return false;
    }

    private static string SanitizeFileName(string value)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var chars = value.Select(ch => invalid.Contains(ch) ? '_' : ch).ToArray();
        var sanitized = new string(chars).Trim();
        return string.IsNullOrWhiteSpace(sanitized) ? "ASPLShield" : sanitized;
    }

}

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using ASPLShield.Common;
using ASPLShield.Core;

namespace ASPLShield.Studio;

/// <summary>
/// A single selectable entry in the "Add Prerequisite" catalog picker.
/// </summary>
public sealed class PrerequisiteCatalogItem : ObservableObject
{
    private bool _isSelected;

    public string Name { get; init; } = string.Empty;

    public string Description { get; init; } = string.Empty;

    public PrerequisiteType Type { get; init; } = PrerequisiteType.Unknown;

    public string Version { get; init; } = string.Empty;

    public string? MinimumVersion { get; init; }

    public string? DetectionTarget { get; init; }

    public string? ExpectedValue { get; init; }

    public bool IsSelected
    {
        get => _isSelected;
        set => SetProperty(ref _isSelected, value);
    }
}

/// <summary>
/// Backs the SelectPrerequisiteWindow: a catalog of common software prerequisites plus an
/// "Add Custom" escape hatch for anything not in the list.
/// </summary>
public sealed class SelectPrerequisiteViewModel : ObservableObject
{
    public ObservableCollection<PrerequisiteCatalogItem> CatalogItems { get; } = new();

    public RelayCommand OkCommand { get; }

    public RelayCommand CancelCommand { get; }

    public RelayCommand AddCustomCommand { get; }

    /// <summary>Raised when the dialog should close. Payload is the DialogResult to apply.</summary>
    public event EventHandler<bool>? RequestClose;

    public bool IsCustomRequested { get; private set; }

    public bool HasSelection => CatalogItems.Any(i => i.IsSelected);

    public SelectPrerequisiteViewModel()
    {
        SeedCatalog();

        foreach (var item in CatalogItems)
        {
            item.PropertyChanged += (_, _) => OnPropertyChanged(nameof(HasSelection));
        }

        OkCommand = new RelayCommand(_ => RequestClose?.Invoke(this, true), _ => HasSelection);
        CancelCommand = new RelayCommand(_ => RequestClose?.Invoke(this, false));
        AddCustomCommand = new RelayCommand(_ =>
        {
            IsCustomRequested = true;
            RequestClose?.Invoke(this, true);
        });
    }

    public IReadOnlyList<PrerequisiteEntry> BuildSelectedEntries()
    {
        return CatalogItems
            .Where(i => i.IsSelected)
            .Select(i => new PrerequisiteEntry
            {
                Name = i.Name,
                Description = i.Description,
                Type = i.Type,
                Version = i.Version,
                MinimumVersion = i.MinimumVersion,
                DetectionTarget = i.DetectionTarget,
                ExpectedValue = i.ExpectedValue,
                Required = true
            })
            .ToList();
    }

    private void SeedCatalog()
    {
        // .NET Framework (legacy)
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Microsoft .NET Framework 4.6.2",
            Description = "Required by apps still targeting the older .NET Framework 4.6.2 runtime.",
            Type = PrerequisiteType.DotNetRuntime,
            Version = "4.6.2",
            MinimumVersion = "4.6.2",
            DetectionTarget = "HKLM\\SOFTWARE\\Microsoft\\NET Framework Setup\\NDP\\v4\\Full"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Microsoft .NET Framework 4.7.1 (x86 and x64)",
            Description = "Required by apps still targeting the older .NET Framework 4.7.1 runtime.",
            Type = PrerequisiteType.DotNetRuntime,
            Version = "4.7.1",
            MinimumVersion = "4.7.1",
            DetectionTarget = "HKLM\\SOFTWARE\\Microsoft\\NET Framework Setup\\NDP\\v4\\Full"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Microsoft .NET Framework 4.7.2 (x86 and x64)",
            Description = "Required by apps still targeting the older .NET Framework 4.7.2 runtime.",
            Type = PrerequisiteType.DotNetRuntime,
            Version = "4.7.2",
            MinimumVersion = "4.7.2",
            DetectionTarget = "HKLM\\SOFTWARE\\Microsoft\\NET Framework Setup\\NDP\\v4\\Full"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Microsoft .NET Framework 4.8 (x86 and x64)",
            Description = "Required by apps still targeting the older .NET Framework 4.8 runtime.",
            Type = PrerequisiteType.DotNetRuntime,
            Version = "4.8",
            MinimumVersion = "4.8",
            DetectionTarget = "HKLM\\SOFTWARE\\Microsoft\\NET Framework Setup\\NDP\\v4\\Full"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Microsoft .NET Framework 4.8.1 (x86 and x64)",
            Description = "Required by apps still targeting the older .NET Framework 4.8.1 runtime.",
            Type = PrerequisiteType.DotNetRuntime,
            Version = "4.8.1",
            MinimumVersion = "4.8.1",
            DetectionTarget = "HKLM\\SOFTWARE\\Microsoft\\NET Framework Setup\\NDP\\v4\\Full"
        });

        // Modern .NET (5+)
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Microsoft .NET 6.0 Desktop Runtime (x64)",
            Description = "Required to run WPF/WinForms apps built on .NET 6.",
            Type = PrerequisiteType.DotNetRuntime,
            Version = "6.0.0",
            MinimumVersion = "6.0.0"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Microsoft .NET 7.0 Desktop Runtime (x64)",
            Description = "Required to run WPF/WinForms apps built on .NET 7.",
            Type = PrerequisiteType.DotNetRuntime,
            Version = "7.0.0",
            MinimumVersion = "7.0.0"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Microsoft .NET 8.0 Desktop Runtime (x64)",
            Description = "Required to run WPF/WinForms apps built on .NET 8.",
            Type = PrerequisiteType.DotNetRuntime,
            Version = "8.0.0",
            MinimumVersion = "8.0.0"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Microsoft .NET 9.0 Desktop Runtime (x64)",
            Description = "Required to run WPF/WinForms apps built on .NET 9.",
            Type = PrerequisiteType.DotNetRuntime,
            Version = "9.0.0",
            MinimumVersion = "9.0.0"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Microsoft .NET 8.0 ASP.NET Core Runtime",
            Description = "Required to host ASP.NET Core apps built on .NET 8 under IIS.",
            Type = PrerequisiteType.DotNetRuntime,
            Version = "8.0.0",
            MinimumVersion = "8.0.0"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Microsoft .NET 8.0 Runtime (Console/Service)",
            Description = "Required to run console apps and background services built on .NET 8.",
            Type = PrerequisiteType.DotNetRuntime,
            Version = "8.0.0",
            MinimumVersion = "8.0.0"
        });

        // Visual C++ redistributables
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Visual C++ Redistributable 2015-2022 (x64)",
            Description = "Required by native components linked against the VC++ runtime.",
            Type = PrerequisiteType.RegistryKey,
            Version = "14.38",
            DetectionTarget = "HKLM\\SOFTWARE\\Microsoft\\VisualStudio\\14.0\\VC\\Runtimes\\X64"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Visual C++ Redistributable 2015-2022 (x86)",
            Description = "Required by 32-bit native components linked against the VC++ runtime.",
            Type = PrerequisiteType.RegistryKey,
            Version = "14.38",
            DetectionTarget = "HKLM\\SOFTWARE\\Microsoft\\VisualStudio\\14.0\\VC\\Runtimes\\X86"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Visual C++ Redistributable 2013 (x64)",
            Description = "Required by older native components built against VC++ 2013.",
            Type = PrerequisiteType.RegistryKey,
            Version = "12.0",
            DetectionTarget = "HKLM\\SOFTWARE\\Microsoft\\VisualStudio\\12.0\\VC\\Runtimes\\X64"
        });

        // Windows platform / installer
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Windows Installer 5.0",
            Description = "Baseline MSI engine version required to run this installer.",
            Type = PrerequisiteType.OperatingSystem,
            Version = "5.0",
            MinimumVersion = "10.0.10240"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Windows 10 (64-bit) or later",
            Description = "Minimum supported Windows version for this application.",
            Type = PrerequisiteType.OperatingSystem,
            Version = "10.0",
            MinimumVersion = "10.0.17763"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Microsoft Edge WebView2 Runtime",
            Description = "Required for apps that embed web content using WebView2.",
            Type = PrerequisiteType.RegistryKey,
            Version = "120.0",
            DetectionTarget = "HKLM\\SOFTWARE\\WOW6432Node\\Microsoft\\EdgeUpdate\\Clients\\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"
        });

        // IIS / web hosting
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "IIS Management Console",
            Description = "Required when the package configures IIS sites or app pools.",
            Type = PrerequisiteType.Iis,
            Version = "10.0"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "IIS URL Rewrite Module 2.1",
            Description = "Required for apps that rely on URL rewrite rules under IIS.",
            Type = PrerequisiteType.Iis,
            Version = "2.1"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "IIS ASP.NET Core Module V2",
            Description = "Required to host ASP.NET Core apps in-process under IIS.",
            Type = PrerequisiteType.Iis,
            Version = "18.0"
        });

        // Databases
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "SQL Server Express LocalDB 2022",
            Description = "Required for apps that use a local SQL Server database file.",
            Type = PrerequisiteType.RegistryKey,
            Version = "16.0",
            DetectionTarget = "HKLM\\SOFTWARE\\Microsoft\\Microsoft SQL Server Local DB\\Installed Versions\\16.0"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Microsoft System CLR Types for SQL Server 2014 (x64)",
            Description = "Required by apps that use SQL Server spatial/geography CLR types.",
            Type = PrerequisiteType.RegistryKey,
            Version = "12.0",
            DetectionTarget = "HKLM\\SOFTWARE\\Microsoft\\Microsoft SQL Server\\120\\SharedFeatures\\SqlSysClrTypes\\CurrentVersion"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Microsoft System CLR Types for SQL Server 2014 (x86)",
            Description = "32-bit variant of the SQL Server CLR types package.",
            Type = PrerequisiteType.RegistryKey,
            Version = "12.0",
            DetectionTarget = "HKLM\\SOFTWARE\\WOW6432Node\\Microsoft\\Microsoft SQL Server\\120\\SharedFeatures\\SqlSysClrTypes\\CurrentVersion"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "SQL Server Native Client 11.0",
            Description = "Required for legacy ODBC/OLE DB connections to SQL Server.",
            Type = PrerequisiteType.RegistryKey,
            Version = "11.0",
            DetectionTarget = "HKLM\\SOFTWARE\\Microsoft\\Microsoft SQL Server Native Client 11.0"
        });

        // Runtimes / third-party
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Java Runtime Environment 8",
            Description = "Required by components that depend on a JRE 8 installation.",
            Type = PrerequisiteType.RegistryKey,
            Version = "1.8",
            DetectionTarget = "HKLM\\SOFTWARE\\JavaSoft\\Java Runtime Environment"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Microsoft Access Database Engine 2016 Redistributable",
            Description = "Required for apps that read/write Access (.accdb/.mdb) or Excel files via OLE DB.",
            Type = PrerequisiteType.RegistryKey,
            Version = "16.0",
            DetectionTarget = "HKLM\\SOFTWARE\\Microsoft\\Office\\16.0\\Access Connectivity Engine"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "DirectX End-User Runtime",
            Description = "Required by apps that use DirectX 9 components not included in Windows by default.",
            Type = PrerequisiteType.FileExists,
            Version = "9.29",
            DetectionTarget = "%WINDIR%\\System32\\d3dx9_43.dll"
        });
        CatalogItems.Add(new PrerequisiteCatalogItem
        {
            Name = "Windows Identity Foundation 3.5",
            Description = "Required by legacy apps that use claims-based identity (WIF).",
            Type = PrerequisiteType.RegistryKey,
            Version = "3.5",
            DetectionTarget = "HKLM\\SOFTWARE\\Microsoft\\NET Framework Setup\\NDP\\v3.5"
        });
    }
}

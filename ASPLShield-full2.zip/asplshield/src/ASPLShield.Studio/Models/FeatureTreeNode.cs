using System.Collections.ObjectModel;
using ASPLShield.Common;
using ASPLShield.Core;

namespace ASPLShield.Studio;

/// <summary>
/// Wraps an <see cref="InstallerFeature"/> as a checkable tree node for the "Filter Files by
/// Feature" and "Assign to Feature" dropdowns on the Files tab. Supports tri-state checking so a
/// parent shows indeterminate when only some of its children are checked.
/// </summary>
public sealed class FeatureTreeNode : ObservableObject
{
    private bool? _isChecked = false;
    private bool _isExpanded = true;

    public FeatureTreeNode(InstallerFeature feature)
    {
        Feature = feature;
    }

    public InstallerFeature Feature { get; }

    /// <summary>Label shown in the tree — falls back to the internal Name if no DisplayName was set.</summary>
    public string Label => string.IsNullOrWhiteSpace(Feature.DisplayName) ? Feature.Name : Feature.DisplayName;

    public FeatureTreeNode? Parent { get; private set; }

    public ObservableCollection<FeatureTreeNode> Children { get; } = new();

    public bool? IsChecked
    {
        get => _isChecked;
        set => SetIsChecked(value, updateChildren: true, updateParent: true);
    }

    public bool IsExpanded
    {
        get => _isExpanded;
        set => SetProperty(ref _isExpanded, value);
    }

    public void SetIsChecked(bool? value, bool updateChildren, bool updateParent)
    {
        if (value == _isChecked)
        {
            return;
        }

        _isChecked = value;

        if (updateChildren && _isChecked.HasValue)
        {
            foreach (var child in Children)
            {
                child.SetIsChecked(_isChecked, updateChildren: true, updateParent: false);
            }
        }

        if (updateParent)
        {
            Parent?.RecomputeFromChildren();
        }

        OnPropertyChanged(nameof(IsChecked));
    }

    private void RecomputeFromChildren()
    {
        bool? state = null;
        for (var i = 0; i < Children.Count; i++)
        {
            var current = Children[i].IsChecked;
            if (i == 0)
            {
                state = current;
            }
            else if (state != current)
            {
                state = null;
                break;
            }
        }

        SetIsChecked(state, updateChildren: false, updateParent: true);
    }

    /// <summary>Depth-first walk of this node and every descendant.</summary>
    public IEnumerable<FeatureTreeNode> Flatten()
    {
        yield return this;
        foreach (var child in Children)
        {
            foreach (var n in child.Flatten())
            {
                yield return n;
            }
        }
    }

    /// <summary>Builds a parent/child tree from the project's flat feature list using ParentFeatureName.</summary>
    public static ObservableCollection<FeatureTreeNode> BuildTree(IEnumerable<InstallerFeature> features)
    {
        var list = features.ToList();
        var nodesByName = list.ToDictionary(f => f.Name, f => new FeatureTreeNode(f));
        var roots = new ObservableCollection<FeatureTreeNode>();

        foreach (var feature in list)
        {
            var node = nodesByName[feature.Name];
            if (!string.IsNullOrWhiteSpace(feature.ParentFeatureName)
                && nodesByName.TryGetValue(feature.ParentFeatureName, out var parent))
            {
                node.Parent = parent;
                parent.Children.Add(node);
            }
            else
            {
                roots.Add(node);
            }
        }

        return roots;
    }
}

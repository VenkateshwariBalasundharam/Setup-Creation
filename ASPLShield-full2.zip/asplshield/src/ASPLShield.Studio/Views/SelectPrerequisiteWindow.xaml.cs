using System.Windows;
using System.Windows.Media;

namespace ASPLShield.Studio;

public partial class SelectPrerequisiteWindow : Window
{
    public SelectPrerequisiteWindow()
    {
        InitializeComponent();
        DataContextChanged += OnDataContextChanged;
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
        // Cover the owner window exactly so the scrim dims the whole app behind the card,
        // regardless of whether the owner is maximized, restored, or on a secondary monitor.
        if (Owner is not null)
        {
            var topLeft = Owner.PointToScreen(new System.Windows.Point(0, 0));
            var source = PresentationSource.FromVisual(Owner);
            var scale = source?.CompositionTarget?.TransformToDevice.M11 ?? 1.0;

            Left = topLeft.X / scale;
            Top = topLeft.Y / scale;
            Width = Owner.ActualWidth;
            Height = Owner.ActualHeight;
        }
    }

    private void OnDataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
        if (e.OldValue is SelectPrerequisiteViewModel oldViewModel)
        {
            oldViewModel.RequestClose -= OnRequestClose;
        }

        if (e.NewValue is SelectPrerequisiteViewModel newViewModel)
        {
            newViewModel.RequestClose += OnRequestClose;
        }
    }

    private void OnRequestClose(object? sender, bool dialogResult)
    {
        DialogResult = dialogResult;
    }

    private void OkButton_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is SelectPrerequisiteViewModel viewModel && viewModel.OkCommand.CanExecute(null))
        {
            viewModel.OkCommand.Execute(null);
        }
    }

    private void AddCustomButton_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is SelectPrerequisiteViewModel viewModel)
        {
            viewModel.AddCustomCommand.Execute(null);
        }
    }

    private void CancelButton_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is SelectPrerequisiteViewModel viewModel)
        {
            viewModel.CancelCommand.Execute(null);
        }
    }
}

using System.Windows;

namespace ASPLShield.Studio;

public partial class SelectFolderFilesWindow : Window
{
    public SelectFolderFilesWindow()
    {
        InitializeComponent();
    }

    private void AcceptButton_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is SelectFolderFilesViewModel viewModel)
        {
            viewModel.IsConfirmed = true;
        }

        DialogResult = true;
    }

    private void CancelButton_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is SelectFolderFilesViewModel viewModel)
        {
            viewModel.IsConfirmed = false;
        }

        DialogResult = false;
    }
}

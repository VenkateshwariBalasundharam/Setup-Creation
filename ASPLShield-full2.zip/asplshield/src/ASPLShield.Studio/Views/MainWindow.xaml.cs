using System.Collections;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using ASPLShield.Core;
using WpfButton = System.Windows.Controls.Button;
using WpfMouseEventArgs = System.Windows.Input.MouseEventArgs;
using WpfMouseButtonEventArgs = System.Windows.Input.MouseButtonEventArgs;
using WpfMouseButtonState = System.Windows.Input.MouseButtonState;
using WpfPoint = System.Windows.Point;
using WpfDataFormats = System.Windows.DataFormats;
using WpfDragDropEffects = System.Windows.DragDropEffects;
using WpfDragEventArgs = System.Windows.DragEventArgs;


namespace ASPLShield.Studio;

public partial class MainWindow : Window
{
    private WpfPoint _dragStartPoint;

    public MainWindow(MainViewModel viewModel)
    {
        InitializeComponent();
        DataContext = viewModel;
        Closed += (_, _) => (DataContext as IDisposable)?.Dispose();
    }

    private void ExplorerTreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
    {
        if (DataContext is not MainViewModel vm)
        {
            return;
        }

        vm.Explorer.SelectedNode = e.NewValue as ProjectExplorerNode;
    }

    private void FilesTreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
    {
        if (DataContext is not MainViewModel vm)
        {
            return;
        }

        vm.Files.SelectedTreeNode = e.NewValue as DestinationTreeNode;
    }

    private void FilesDataGrid_PreviewDragOver(object sender, WpfDragEventArgs e)
    {
        e.Effects = e.Data.GetDataPresent(WpfDataFormats.FileDrop) ? WpfDragDropEffects.Copy : WpfDragDropEffects.None;
        e.Handled = true;
    }

    private void FilesDataGrid_Drop(object sender, WpfDragEventArgs e)
    {
        if (sender is not DataGrid grid || DataContext is not MainViewModel vm)
        {
            return;
        }

        if (e.Data.GetDataPresent(WpfDataFormats.FileDrop))
        {
            var paths = e.Data.GetData(WpfDataFormats.FileDrop) as string[];
            if (paths is null)
            {
                return;
            }

            vm.Files.AddDroppedPaths(paths);
            grid.Items.Refresh();
            return;
        }

        if (e.Data.GetDataPresent(typeof(InstallerFile)) && e.Data.GetData(typeof(InstallerFile)) is InstallerFile file)
        {
            var targetItem = GetItemUnderMouse<InstallerFile>(grid, e.GetPosition(grid));
            if (targetItem is null)
            {
                return;
            }

            var targetIndex = vm.Files.Files.IndexOf(targetItem);
            vm.Files.MoveFileToIndex(file, targetIndex);
        }
    }

    private void FilesDataGrid_DragOver(object sender, WpfDragEventArgs e)
    {
        e.Effects = e.Data.GetDataPresent(WpfDataFormats.FileDrop)
            ? WpfDragDropEffects.Copy
            : e.Data.GetDataPresent(typeof(InstallerFile))
                ? WpfDragDropEffects.Move
                : WpfDragDropEffects.None;
        e.Handled = true;
    }

    private void FilesDataGrid_PreviewMouseLeftButtonDown(object sender, WpfMouseButtonEventArgs e)
    {
        _dragStartPoint = e.GetPosition(null);
    }

    private void FilesDataGrid_PreviewMouseMove(object sender, WpfMouseEventArgs e)
    {
        if (e.LeftButton != WpfMouseButtonState.Pressed || sender is not DataGrid grid)
        {
            return;
        }

        var position = e.GetPosition(null);
        if (Math.Abs(position.X - _dragStartPoint.X) < SystemParameters.MinimumHorizontalDragDistance &&
            Math.Abs(position.Y - _dragStartPoint.Y) < SystemParameters.MinimumVerticalDragDistance)
        {
            return;
        }

        if (grid.SelectedItem is null)
        {
            return;
        }

        DragDrop.DoDragDrop(grid, grid.SelectedItem, WpfDragDropEffects.Move);
    }

    private void ShortcutsDataGrid_PreviewMouseLeftButtonDown(object sender, WpfMouseButtonEventArgs e)
    {
        _dragStartPoint = e.GetPosition(null);
    }

    private void ShortcutsDataGrid_PreviewMouseMove(object sender, WpfMouseEventArgs e)
    {
        if (e.LeftButton != WpfMouseButtonState.Pressed || sender is not DataGrid grid)
        {
            return;
        }

        var position = e.GetPosition(null);
        if (Math.Abs(position.X - _dragStartPoint.X) < SystemParameters.MinimumHorizontalDragDistance &&
            Math.Abs(position.Y - _dragStartPoint.Y) < SystemParameters.MinimumVerticalDragDistance)
        {
            return;
        }

        if (grid.SelectedItem is null)
        {
            return;
        }

        DragDrop.DoDragDrop(grid, grid.SelectedItem, WpfDragDropEffects.Move);
    }

    private void ShortcutsDataGrid_DragOver(object sender, WpfDragEventArgs e)
    {
        e.Effects = e.Data.GetDataPresent(typeof(InstallerShortcut)) ? WpfDragDropEffects.Move : WpfDragDropEffects.None;
        e.Handled = true;
    }

    private void ShortcutsDataGrid_Drop(object sender, WpfDragEventArgs e)
    {
        if (sender is not DataGrid grid || DataContext is not MainViewModel vm || grid.ItemsSource is null)
        {
            return;
        }

        if (e.Data.GetDataPresent(typeof(InstallerShortcut)) && e.Data.GetData(typeof(InstallerShortcut)) is InstallerShortcut shortcut)
        {
            var targetItem = GetItemUnderMouse<InstallerShortcut>(grid, e.GetPosition(grid));
            if (targetItem is null)
            {
                return;
            }

            var targetIndex = vm.Shortcuts.Shortcuts.IndexOf(targetItem);
            vm.Shortcuts.MoveShortcutToIndex(shortcut, targetIndex);
        }
    }

    private void RecentProjectsMenuItem_SubmenuOpened(object sender, RoutedEventArgs e)
    {
        if (sender is not MenuItem menuItem || DataContext is not MainViewModel vm)
        {
            return;
        }

        // Keep "Clear Recent Projects" (index 0) and the Separator (index 1);
        // remove everything after that and rebuild it fresh each time the submenu opens.
        while (menuItem.Items.Count > 2)
        {
            menuItem.Items.RemoveAt(2);
        }

        var recentProjects = vm.RecentProjects as IEnumerable;
        var hasAny = false;

        if (recentProjects is not null)
        {
            foreach (var project in recentProjects)
            {
                if (project is null)
                {
                    continue;
                }

                hasAny = true;
                var path = GetRecentProjectPath(project);

                var entry = new MenuItem
                {
                    Header = string.IsNullOrEmpty(path) ? path : System.IO.Path.GetFileNameWithoutExtension(path),
                    ToolTip = path,
                    Command = vm.OpenRecentProjectCommand,
                    CommandParameter = project
                };
                menuItem.Items.Add(entry);
            }
        }

        if (!hasAny)
        {
            menuItem.Items.Add(new MenuItem { Header = "(No recent projects)", IsEnabled = false });
        }
    }

    private static string GetRecentProjectPath(object project)
    {
        // RecentProjectEntry doesn't override ToString(), so pull the path via reflection.
        // Adjust/trim this candidate list once you confirm the real property name on RecentProjectEntry.
        var type = project.GetType();
        foreach (var candidate in new[] { "ProjectPath", "Path", "FilePath", "FullPath" })
        {
            var prop = type.GetProperty(candidate);
            if (prop?.GetValue(project) is string value && !string.IsNullOrEmpty(value))
            {
                return value;
            }
        }

        return project.ToString() ?? string.Empty;
    }

    private void ThemeOption_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not MenuItem menuItem || DataContext is not MainViewModel vm)
        {
            return;
        }

        var option = menuItem.DataContext;
        var themeVm = vm.Theme;
        if (option is null || themeVm is null)
        {
            return;
        }

        var kindProperty = option.GetType().GetProperty("Kind");
        var selectedThemeProperty = themeVm.GetType().GetProperty("SelectedTheme");
        if (kindProperty is not null && selectedThemeProperty is not null)
        {
            selectedThemeProperty.SetValue(themeVm, kindProperty.GetValue(option));
        }

        e.Handled = true;
    }

    private void ExplorerToggle_Click(object sender, RoutedEventArgs e)
    {
        var show = ExplorerToggleButton.IsChecked == true;
        ExplorerColumn.MinWidth = show ? 180 : 0;
        ExplorerColumn.Width = show ? new GridLength(320) : new GridLength(0);
        ExplorerSplitterColumn.Width = show ? new GridLength(3) : new GridLength(0);
        ExplorerPanel.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
    }

    private void PropertiesToggle_Click(object sender, RoutedEventArgs e)
    {
        var show = PropertiesToggleButton.IsChecked == true;
        PropertiesColumn.Width = show ? new GridLength(320) : new GridLength(0);
        PropertiesPanel.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
    }

    private void CustomScreensGuide_Click(object sender, RoutedEventArgs e)
    {
        var guide = string.Join(Environment.NewLine, new[]
        {
            "Custom Screens Guide",
            "",
            "1. Click Add Screen and select the screen in the list.",
            "2. Set the screen name, title, and description.",
            "3. Click Add Control for each field the installer should show.",
            "4. Select a control and choose its type:",
            "   Label       - display read-only text.",
            "   TextBox     - collect text such as a server name.",
            "   BrowseButton- collect a file path using Browse.",
            "   CheckBox    - collect true/false options.",
            "   RadioButton - present a choice in a group.",
            "   NumberBox   - collect a numeric value.",
            "5. Set Label, Text, Default value, and Required as needed.",
            "6. Set appsettings key to save the value after installation.",
            "",
            "Example:",
            "Label: Database server",
            "Type: TextBox",
            "Default value: localhost",
            "appsettings key: ConnectionStrings:Server",
            "",
            "After installation, the value is written to appsettings.json in the install folder."
        });

        System.Windows.MessageBox.Show(guide, "Custom Screens Guide", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void GlobalGuide_Click(object sender, RoutedEventArgs e)
    {
        var guide = string.Join(Environment.NewLine, new[]
        {
            "ASPLShield Studio Guide",
            "",
            "1. New Project - create a project and set product name, version, install folder, and output folder.",
            "2. Overview - review the project identity and build locations.",
            "3. Files - add files or folders to be installed; drag and drop is supported.",
            "4. Features - group files into optional installable features.",
            "5. Shortcuts - create Desktop or Start Menu shortcuts and choose their targets.",
            "6. Registry - add registry keys and values to write during installation.",
            "7. IIS - configure sites, bindings, application pools, and startup behavior.",
            "8. Services - configure Windows services, accounts, startup, and dependencies.",
            "9. Prerequisites - define file, registry, operating-system, or .NET checks.",
            "10. Build → Custom Screens - add project-specific installer pages and controls.",
            "11. Build - set the Setup EXE name, uninstaller, branding, and MSI mode.",
            "12. Save Project, then click Build. Use Open Output Folder to view the artifacts.",
            "",
            "Custom screen example:",
            "Add a TextBox labelled 'Database server' with default 'localhost'.",
            "Set appsettings key to ConnectionStrings:Server.",
            "The installer writes the entered value to appsettings.json in the install folder.",
            "",
            "Build & Run launches the generated installer. Rebuild cleans the output first.",
            "Use the Build Output panel and Logs Folder when troubleshooting."
        });

        System.Windows.MessageBox.Show(guide, "ASPLShield Studio Guide", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void SigningPasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
    {
        if (sender is not PasswordBox passwordBox || DataContext is not MainViewModel vm)
        {
            return;
        }

        vm.Properties.Integration.SigningCertificatePassword = passwordBox.Password;
    }

    private void ScrollToTop_Click(object sender, RoutedEventArgs e)
    {
        if (sender is WpfButton button && button.Tag is ScrollViewer viewer)
        {
            viewer.ScrollToTop();
        }
    }

    private void ScrollToBottom_Click(object sender, RoutedEventArgs e)
    {
        if (sender is WpfButton button && button.Tag is ScrollViewer viewer)
        {
            viewer.ScrollToEnd();
        }
    }

    private static T? GetItemUnderMouse<T>(ItemsControl itemsControl, WpfPoint position) where T : class
    {
        var element = itemsControl.InputHitTest(position) as DependencyObject;
        while (element is not null && element is not DataGridRow)
        {
            element = VisualTreeHelper.GetParent(element);
        }

        if (element is DataGridRow row)
        {
            return row.Item as T;
        }

        return null;
    }
}

using System.Windows;

namespace ASPLShield.Studio;

public partial class NewProjectWizardWindow : Window
{
    public NewProjectWizardWindow()
    {
        InitializeComponent();
    }

    private void AcceptButton_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is NewProjectWizardViewModel viewModel)
        {
            viewModel.CreateCommand.Execute(null);
            DialogResult = viewModel.IsConfirmed;
        }
    }

    private void CancelButton_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is NewProjectWizardViewModel viewModel)
        {
            viewModel.CancelCommand.Execute(null);
            DialogResult = false;
        }
    }
}

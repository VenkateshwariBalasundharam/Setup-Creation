using Microsoft.Data.Sqlite;

namespace ASPLShield.Studio;

public interface IStudioSqliteConnectionFactory
{
    SqliteConnection CreateConnection();
}

public sealed class StudioSqliteConnectionFactory : IStudioSqliteConnectionFactory
{
    public SqliteConnection CreateConnection()
        => new($"Data Source={StudioPaths.DatabasePath}");
}

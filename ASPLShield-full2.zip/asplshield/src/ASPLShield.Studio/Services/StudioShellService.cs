using System.Diagnostics;
using System.Security.Principal;

namespace ASPLShield.Studio;

public interface IStudioShellService
{
    string LogsDirectoryPath { get; }

    bool CanOpenPhysicalFolder(string? folderPath);

    void OpenFolderInExplorer(string folderPath);

    int? ParsePort(string bindingInformation);

    bool IsAdministrator();
}

public sealed class StudioShellService : IStudioShellService
{
    public string LogsDirectoryPath => Path.Combine(Path.GetTempPath(), "ASPLShield", "Logs");

    public bool CanOpenPhysicalFolder(string? folderPath)
    {
        if (string.IsNullOrWhiteSpace(folderPath))
        {
            return false;
        }

        if (folderPath.Contains('[', StringComparison.Ordinal) || folderPath.Contains('%', StringComparison.Ordinal))
        {
            return false;
        }

        return Path.IsPathRooted(folderPath);
    }

    public void OpenFolderInExplorer(string folderPath)
    {
        Directory.CreateDirectory(folderPath);
        var psi = new ProcessStartInfo
        {
            FileName = "explorer.exe",
            Arguments = $"\"{folderPath}\"",
            UseShellExecute = true
        };

        Process.Start(psi);
    }

    public int? ParsePort(string bindingInformation)
    {
        if (string.IsNullOrWhiteSpace(bindingInformation))
        {
            return null;
        }

        var parts = bindingInformation.Split(':');
        if (parts.Length < 2 || !int.TryParse(parts[1], out var port))
        {
            return null;
        }

        return port;
    }

    public bool IsAdministrator()
    {
        using var identity = WindowsIdentity.GetCurrent();
        var principal = new WindowsPrincipal(identity);
        return principal.IsInRole(WindowsBuiltInRole.Administrator);
    }
}

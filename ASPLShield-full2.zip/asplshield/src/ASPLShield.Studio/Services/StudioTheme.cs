using System.Collections.ObjectModel;
using System.Windows.Media;
using WpfApplication = System.Windows.Application;
using WpfColor = System.Windows.Media.Color;
using WpfColorConverter = System.Windows.Media.ColorConverter;
using WpfPoint = System.Windows.Point;
using WpfBrush = System.Windows.Media.Brush;

namespace ASPLShield.Studio;

public enum StudioThemeKind
{
    LightBlue,
    Midnight,
    Sandstone,
    Blush
}

public sealed record StudioThemePalette(
    string Name,
    WpfBrush WindowBackground,
    WpfBrush ShellBackground,
    WpfBrush CardBackground,
    WpfBrush CardBorder,
    WpfBrush TextPrimary,
    WpfBrush TextSecondary,
    WpfBrush TextMuted,
    WpfBrush Accent,
    WpfBrush AccentSoft,
    WpfBrush AccentBorder,
    WpfBrush ButtonBackground,
    WpfBrush ButtonBorder,
    WpfBrush ButtonForeground,
    WpfBrush ButtonHover,
    WpfBrush ButtonPressed,
    WpfBrush InputBackground,
    WpfBrush InputBorder,
    WpfBrush ValidationBrush);

public interface IStudioThemeService
{
    StudioThemeKind CurrentTheme { get; }

    IReadOnlyList<StudioThemeKind> AvailableThemes { get; }

    WpfBrush GetPreviewBrush(StudioThemeKind themeKind);

    void ApplyTheme(StudioThemeKind themeKind);
}

public sealed class StudioThemeService : IStudioThemeService
{
    private readonly Dictionary<StudioThemeKind, StudioThemePalette> _palettes = new()
    {
        [StudioThemeKind.LightBlue] = new StudioThemePalette(
            "Light Blue",
            CreateVerticalGradient("#FFF7FAFF", "#FFF2F7FF", "#FFE7F0FF", "#FFF9FBFF"),
            CreateSolid("#F7FFFFFF"),
            CreateSolid("#F3FFFFFF"),
            CreateSolid("#C8D7E8"),
            CreateSolid("#FF1F2A37"),
            CreateSolid("#FF5C6C80"),
            CreateSolid("#FF7F8EA3"),
            CreateSolid("#FF4A82D1"),
            CreateSolid("#FFEAF3FF"),
            CreateSolid("#FFB7CBEA"),
            CreateSolid("#FFFFFFFF"),
            CreateSolid("#FFB8D0F1"),
            CreateSolid("#FF4A82D1"),
            CreateSolid("#FFEAF3FF"),
            CreateSolid("#FFD8E8FF"),
            CreateSolid("#FFFDFEFF"),
            CreateSolid("#FFC8D7E8"),
            CreateSolid("#FF9A6A00")),
        [StudioThemeKind.Midnight] = new StudioThemePalette(
            "Midnight",
            CreateVerticalGradient("#FF0E1624", "#FF111C2E", "#FF12233A", "#FF0A101A"),
            CreateSolid("#FF101A2C"),
            CreateSolid("#FF16243A"),
            CreateSolid("#FF2A3D59"),
            CreateSolid("#FFF4F7FB"),
            CreateSolid("#FFC8D5E6"),
            CreateSolid("#FF99ABC0"),
            CreateSolid("#FF8CB7FF"),
            CreateSolid("#FF223A59"),
            CreateSolid("#FF375A87"),
            CreateSolid("#FF3D597E"),
            CreateSolid("#FF8CB7FF"),
            CreateSolid("#FFF4F7FB"),
            CreateSolid("#FF203757"),
            CreateSolid("#FF2D4A73"),
            CreateSolid("#FF0E1726"),
            CreateSolid("#FF3A4E69"),
            CreateSolid("#FFFFC966")),
        [StudioThemeKind.Sandstone] = new StudioThemePalette(
            "Sandstone",
            CreateVerticalGradient("#FFFDFBF6", "#FFFBF5EA", "#FFF6EBD8", "#FFFEFCF8"),
            CreateSolid("#F8FFFCF5"),
            CreateSolid("#F4FFFBF3"),
            CreateSolid("#FFE4D6BE"),
            CreateSolid("#FF2E2419"),
            CreateSolid("#FF6B5D4B"),
            CreateSolid("#FF9C8C75"),
            CreateSolid("#FFD97D3E"),
            CreateSolid("#FFF7E4D2"),
            CreateSolid("#FFE8B98C"),
            CreateSolid("#FFFFFDF9"),
            CreateSolid("#FFE8B98C"),
            CreateSolid("#FFC85A22"),
            CreateSolid("#FFF7E4D2"),
            CreateSolid("#FFF0D5B8"),
            CreateSolid("#FFFFFEFB"),
            CreateSolid("#FFE4D6BE"),
            CreateSolid("#FFB23A3A")),
        [StudioThemeKind.Blush] = new StudioThemePalette(
            "Blush",
            CreateVerticalGradient("#FFFFF8FA", "#FFFDF1F5", "#FFFAE4EC", "#FFFFFAFB"),
            CreateSolid("#F8FFFAFB"),
            CreateSolid("#F5FFF9FB"),
            CreateSolid("#FFEBD3DE"),
            CreateSolid("#FF3A2530"),
            CreateSolid("#FF7A5A68"),
            CreateSolid("#FFB08999"),
            CreateSolid("#FFE0598B"),
            CreateSolid("#FFFBE4EE"),
            CreateSolid("#FFEDB8D0"),
            CreateSolid("#FFFFFDFE"),
            CreateSolid("#FFEDB8D0"),
            CreateSolid("#FFC94577"),
            CreateSolid("#FFFBE4EE"),
            CreateSolid("#FFF5D0E0"),
            CreateSolid("#FFFFFEFF"),
            CreateSolid("#FFEBD3DE"),
            CreateSolid("#FF9A3A3A"))
    };

    private StudioThemeKind _currentTheme = StudioThemeKind.LightBlue;

    public StudioThemeService()
    {
        ApplyTheme(_currentTheme);
    }

    public StudioThemeKind CurrentTheme => _currentTheme;

    public IReadOnlyList<StudioThemeKind> AvailableThemes { get; } = Enum.GetValues<StudioThemeKind>();

    public WpfBrush GetPreviewBrush(StudioThemeKind themeKind)
        => _palettes.TryGetValue(themeKind, out var palette)
            ? palette.Accent
            : CreateSolid("#FFFFFFFF");

    public void ApplyTheme(StudioThemeKind themeKind)
    {
        if (!_palettes.TryGetValue(themeKind, out var palette))
        {
            return;
        }

        _currentTheme = themeKind;
        var resources = WpfApplication.Current.Resources;
        resources["AppBackgroundBrush"] = palette.WindowBackground;
        resources["ShellBackgroundBrush"] = palette.ShellBackground;
        resources["CardBrush"] = palette.CardBackground;
        resources["CardBorderBrush"] = palette.CardBorder;
        resources["TextPrimaryBrush"] = palette.TextPrimary;
        resources["TextSecondaryBrush"] = palette.TextSecondary;
        resources["TextMutedBrush"] = palette.TextMuted;
        resources["AccentBrush"] = palette.Accent;
        resources["AccentSoftBrush"] = palette.AccentSoft;
        resources["AccentBorderBrush"] = palette.AccentBorder;
        resources["ButtonBackgroundBrush"] = palette.ButtonBackground;
        resources["ButtonBorderBrush"] = palette.ButtonBorder;
        resources["ButtonForegroundBrush"] = palette.ButtonForeground;
        resources["ButtonHoverBrush"] = palette.ButtonHover;
        resources["ButtonPressedBrush"] = palette.ButtonPressed;
        resources["InputBackgroundBrush"] = palette.InputBackground;
        resources["InputBorderBrush"] = palette.InputBorder;
        resources["ValidationBrush"] = palette.ValidationBrush;
        resources["MenuBackgroundBrush"] = palette.ShellBackground;
        resources["StatusBarBrush"] = palette.ShellBackground;
        resources["PanelBackgroundBrush"] = palette.CardBackground;
    }

    private static WpfBrush CreateSolid(string hex) => (WpfBrush)new BrushConverter().ConvertFromString(hex)!;

    private static WpfBrush CreateVerticalGradient(string top, string second, string third, string bottom)
        => new LinearGradientBrush(
            new GradientStopCollection
            {
                new((WpfColor)WpfColorConverter.ConvertFromString(top)!, 0),
                new((WpfColor)WpfColorConverter.ConvertFromString(second)!, 0.34),
                new((WpfColor)WpfColorConverter.ConvertFromString(third)!, 0.72),
                new((WpfColor)WpfColorConverter.ConvertFromString(bottom)!, 1)
            },
            new WpfPoint(0, 0),
            new WpfPoint(0, 1));
}
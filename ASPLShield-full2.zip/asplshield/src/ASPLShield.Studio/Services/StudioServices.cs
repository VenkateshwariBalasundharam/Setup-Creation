using ASPLShield.Core;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Win32;
using System.Windows;

namespace ASPLShield.Studio;

public interface IFileDialogService
{
    string? OpenProjectFile();

    string? SaveProjectFile(string defaultFileName);

    string? SaveNativeDatabaseFile(string defaultFileName);

    string? SelectFiles();

    string? SelectFolder();

    /// <summary>Folder picker with a custom title and starting folder (used for the output folder).</summary>
    string? SelectFolder(string description, string? initialPath) => SelectFolder();

    string? SelectSingleFile(string title, string filter);

    /// <summary>
    /// Shows a native color picker seeded with <paramref name="currentColorHex"/> (if parsable) and
    /// returns the chosen color as "#RRGGBB", or null if the user cancelled.
    /// </summary>
    string? SelectColor(string? currentColorHex);
}

public sealed class WpfFileDialogService : IFileDialogService
{
    public string? OpenProjectFile()
    {
        var dialog = new Microsoft.Win32.OpenFileDialog
        {
            Filter = "ASPLShield Project (*.asplproj)|*.asplproj|All files (*.*)|*.*",
            Title = "Open Project"
        };

        return dialog.ShowDialog() == true ? dialog.FileName : null;
    }

    public string? SaveProjectFile(string defaultFileName)
    {
        var dialog = new Microsoft.Win32.SaveFileDialog
        {
            Filter = "ASPLShield Project (*.asplproj)|*.asplproj",
            Title = "Save Project",
            FileName = defaultFileName
        };

        return dialog.ShowDialog() == true ? dialog.FileName : null;
    }

    public string? SaveNativeDatabaseFile(string defaultFileName)
    {
        var dialog = new Microsoft.Win32.SaveFileDialog
        {
            Filter = "Native MSI Database (*.native-msi-database.msi)|*.native-msi-database.msi",
            Title = "Export Native MSI Database",
            FileName = defaultFileName
        };

        return dialog.ShowDialog() == true ? dialog.FileName : null;
    }

    public string? SelectFiles()
    {
        var dialog = new Microsoft.Win32.OpenFileDialog
        {
            Multiselect = true,
            Title = "Add Files"
        };

        return dialog.ShowDialog() == true ? string.Join("|", dialog.FileNames) : null;
    }

    public string? SelectFolder()
    {
        using var dialog = new System.Windows.Forms.FolderBrowserDialog
        {
            Description = "Select a folder to include"
        };

        return dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK ? dialog.SelectedPath : null;
    }

    public string? SelectFolder(string description, string? initialPath)
    {
        using var dialog = new System.Windows.Forms.FolderBrowserDialog
        {
            Description = description,
            UseDescriptionForTitle = true,
            ShowNewFolderButton = true
        };

        if (!string.IsNullOrWhiteSpace(initialPath) && Path.IsPathRooted(initialPath) && Directory.Exists(initialPath))
        {
            dialog.InitialDirectory = initialPath;
            dialog.SelectedPath = initialPath;
        }

        return dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK ? dialog.SelectedPath : null;
    }

    public string? SelectSingleFile(string title, string filter)
    {
        var dialog = new Microsoft.Win32.OpenFileDialog
        {
            Multiselect = false,
            Title = title,
            Filter = filter
        };

        return dialog.ShowDialog() == true ? dialog.FileName : null;
    }

    public string? SelectColor(string? currentColorHex)
    {
        using var dialog = new System.Windows.Forms.ColorDialog
        {
            FullOpen = true,
            AnyColor = true
        };

        if (!string.IsNullOrWhiteSpace(currentColorHex))
        {
            try
            {
                var converted = System.Windows.Media.ColorConverter.ConvertFromString(currentColorHex);
                if (converted is System.Windows.Media.Color seedColor)
                {
                    dialog.Color = System.Drawing.Color.FromArgb(seedColor.R, seedColor.G, seedColor.B);
                }
            }
            catch (FormatException)
            {
                // Ignore an unparsable starting color and let the dialog open with its own default.
            }
        }

        if (dialog.ShowDialog() != System.Windows.Forms.DialogResult.OK)
        {
            return null;
        }

        return $"#{dialog.Color.R:X2}{dialog.Color.G:X2}{dialog.Color.B:X2}";
    }
}

public interface INewProjectDialogService
{
    InstallerProject? ShowDialog();
}

public sealed class NewProjectDialogService : INewProjectDialogService
{
    private readonly IServiceProvider _serviceProvider;

    public NewProjectDialogService(IServiceProvider serviceProvider)
    {
        _serviceProvider = serviceProvider;
    }

    public InstallerProject? ShowDialog()
    {
        var window = _serviceProvider.GetRequiredService<NewProjectWizardWindow>();
        var vm = new NewProjectWizardViewModel(_serviceProvider.GetRequiredService<IProjectRepository>(), _serviceProvider.GetRequiredService<IFileDialogService>());
        window.Loaded += async (_, _) => await vm.LoadTemplatesAsync().ConfigureAwait(true);
        window.DataContext = vm;
        var result = window.ShowDialog();
        return result == true ? vm.CreateProject() : null;
    }
}

/// <summary>
/// Result of the "Add Prerequisite" catalog picker: either one or more catalog selections,
/// or a signal that the caller should fall back to creating a blank custom prerequisite.
/// </summary>
public sealed class PrerequisiteSelectionResult
{
    public IReadOnlyList<PrerequisiteEntry> SelectedPrerequisites { get; init; } = Array.Empty<PrerequisiteEntry>();

    public bool AddCustomRequested { get; init; }
}

public interface ISelectPrerequisiteDialogService
{
    /// <summary>Shows the picker. Returns null if the user cancelled.</summary>
    PrerequisiteSelectionResult? ShowDialog();
}

public sealed class SelectPrerequisiteDialogService : ISelectPrerequisiteDialogService
{
    private readonly IServiceProvider _serviceProvider;

    public SelectPrerequisiteDialogService(IServiceProvider serviceProvider)
    {
        _serviceProvider = serviceProvider;
    }

    public PrerequisiteSelectionResult? ShowDialog()
    {
        var window = _serviceProvider.GetRequiredService<SelectPrerequisiteWindow>();
        var vm = new SelectPrerequisiteViewModel();
        window.DataContext = vm;
        window.Owner = System.Windows.Application.Current?.MainWindow;

        var result = window.ShowDialog();
        if (result != true)
        {
            return null;
        }

        return new PrerequisiteSelectionResult
        {
            SelectedPrerequisites = vm.BuildSelectedEntries(),
            AddCustomRequested = vm.IsCustomRequested
        };
    }
}
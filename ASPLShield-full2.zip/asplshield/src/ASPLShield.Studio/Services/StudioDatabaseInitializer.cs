namespace ASPLShield.Studio;

/// <summary>
/// Creates the SQLite schema used by the authoring experience.
/// </summary>
public sealed class StudioDatabaseInitializer
{
    private const string Schema = """
        CREATE TABLE IF NOT EXISTS Projects (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            ProjectPath TEXT NOT NULL UNIQUE,
            ProductName TEXT NOT NULL,
            Version TEXT NOT NULL,
            Publisher TEXT NOT NULL,
            OutputFolder TEXT NOT NULL,
            LastSavedUtc TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS BuildHistory (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            ProjectPath TEXT NOT NULL,
            BuiltAtUtc TEXT NOT NULL,
            OutputFolder TEXT NOT NULL,
            Succeeded INTEGER NOT NULL,
            Message TEXT NULL
        );

        CREATE TABLE IF NOT EXISTS Templates (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Name TEXT NOT NULL,
            Description TEXT NOT NULL,
            TemplatePath TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS RecentProjects (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            ProjectPath TEXT NOT NULL UNIQUE,
            OpenedAtUtc TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS ApplicationSettings (
            SettingKey TEXT PRIMARY KEY,
            SettingValue TEXT NOT NULL
        );
        """;

    private readonly IStudioSqliteConnectionFactory _connectionFactory;

    public StudioDatabaseInitializer(IStudioSqliteConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task InitializeAsync(CancellationToken cancellationToken = default)
    {
        Directory.CreateDirectory(StudioPaths.AppRoot);
        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = Schema;
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }
}

using System.Diagnostics;

namespace ASPLShield.Studio;

public interface IStudioLogMonitorService : IDisposable
{
    event EventHandler? Changed;

    string LogsDirectoryPath { get; }

    void Start();

    IReadOnlyList<string> ReadRecentEntries(int lineCount);
}

public sealed class StudioLogMonitorService : IStudioLogMonitorService
{
    private FileSystemWatcher? _watcher;

    public event EventHandler? Changed;

    public string LogsDirectoryPath => Path.Combine(Path.GetTempPath(), "ASPLShield", "Logs");

    public void Start()
    {
        if (_watcher is not null)
        {
            return;
        }

        Directory.CreateDirectory(LogsDirectoryPath);

        _watcher = new FileSystemWatcher(LogsDirectoryPath, "*.log")
        {
            IncludeSubdirectories = false,
            NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite | NotifyFilters.Size,
            EnableRaisingEvents = true
        };

        FileSystemEventHandler handler = (_, _) => Changed?.Invoke(this, EventArgs.Empty);
        RenamedEventHandler renamedHandler = (_, _) => Changed?.Invoke(this, EventArgs.Empty);
        _watcher.Changed += handler;
        _watcher.Created += handler;
        _watcher.Deleted += handler;
        _watcher.Renamed += renamedHandler;
    }

    public IReadOnlyList<string> ReadRecentEntries(int lineCount)
    {
        var entries = new List<string>();

        foreach (var logPath in new[]
                 {
                     Path.Combine(LogsDirectoryPath, "install.log"),
                     Path.Combine(LogsDirectoryPath, "uninstall.log")
                 })
        {
            if (!TryReadTail(logPath, lineCount, out var tail))
            {
                continue;
            }

            foreach (var line in tail)
            {
                entries.Add($"{Path.GetFileName(logPath)}: {line}");
            }
        }

        return entries;
    }

    public void Dispose()
    {
        if (_watcher is null)
        {
            return;
        }

        _watcher.Dispose();
        _watcher = null;
    }

    private static bool TryReadTail(string logPath, int lineCount, out IEnumerable<string> tail)
    {
        tail = Array.Empty<string>();
        if (!File.Exists(logPath))
        {
            return false;
        }

        try
        {
            using var stream = new FileStream(logPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            using var reader = new StreamReader(stream);
            var lines = new List<string>();
            while (!reader.EndOfStream)
            {
                lines.Add(reader.ReadLine() ?? string.Empty);
            }

            tail = lines.TakeLast(lineCount).ToArray();
            return true;
        }
        catch
        {
            return false;
        }
    }
}

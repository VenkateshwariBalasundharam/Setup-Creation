namespace ASPLShield.Studio;

internal static class StudioPaths
{
    public static string AppRoot => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "ASPLShield");

    public static string DatabasePath => Path.Combine(AppRoot, "asplshield.db");

    public static string TemplatesPath => Path.Combine(AppRoot, "Templates");

    public static string? LocateRuntimeProjectPath()
        => LocateProjectPath("ASPLShield.Runtime");

    public static string? LocateUninstallerProjectPath()
        => LocateProjectPath("ASPLShield.Uninstaller");

    private static string? LocateProjectPath(string projectFolderName)
    {
        var directory = new DirectoryInfo(AppContext.BaseDirectory);
        while (directory is not null)
        {
            var candidate = Path.Combine(directory.FullName, "src", projectFolderName, $"{projectFolderName}.csproj");
            if (File.Exists(candidate))
            {
                return candidate;
            }

            var solutionCandidate = Path.Combine(directory.FullName, "ASPLShield.slnx");
            if (File.Exists(solutionCandidate))
            {
                candidate = Path.Combine(directory.FullName, "src", projectFolderName, $"{projectFolderName}.csproj");
                return File.Exists(candidate) ? candidate : null;
            }

            directory = directory.Parent;
        }

        return null;
    }
}

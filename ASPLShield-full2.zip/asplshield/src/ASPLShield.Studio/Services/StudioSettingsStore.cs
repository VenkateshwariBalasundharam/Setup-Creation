namespace ASPLShield.Studio;

public interface IStudioSettingsStore
{
    Task<StudioThemeKind?> GetThemeAsync(CancellationToken cancellationToken = default);

    Task SetThemeAsync(StudioThemeKind themeKind, CancellationToken cancellationToken = default);
}

public sealed class SqliteStudioSettingsStore : IStudioSettingsStore
{
    private readonly IStudioSqliteConnectionFactory _connectionFactory;

    public SqliteStudioSettingsStore(IStudioSqliteConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<StudioThemeKind?> GetThemeAsync(CancellationToken cancellationToken = default)
    {
        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT SettingValue
            FROM ApplicationSettings
            WHERE SettingKey = 'Studio.Theme';
            """;
        var value = await command.ExecuteScalarAsync(cancellationToken).ConfigureAwait(false);
        if (value is not string text || !Enum.TryParse<StudioThemeKind>(text, ignoreCase: true, out var theme))
        {
            return null;
        }

        return theme;
    }

    public async Task SetThemeAsync(StudioThemeKind themeKind, CancellationToken cancellationToken = default)
    {
        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO ApplicationSettings (SettingKey, SettingValue)
            VALUES ('Studio.Theme', $theme)
            ON CONFLICT(SettingKey) DO UPDATE SET
                SettingValue = excluded.SettingValue;
            """;
        command.Parameters.AddWithValue("$theme", themeKind.ToString());
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }
}

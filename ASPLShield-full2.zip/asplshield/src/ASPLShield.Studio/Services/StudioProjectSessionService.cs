using ASPLShield.Core;

namespace ASPLShield.Studio;

public sealed record StudioProjectSessionResult(
    bool Succeeded,
    InstallerProject? Project,
    string? ProjectPath,
    string StatusText,
    string? OutputMessage);

public interface IStudioProjectSessionService
{
    StudioProjectSessionResult CreateNew();

    Task<StudioProjectSessionResult> OpenAsync(CancellationToken cancellationToken = default);

    Task<StudioProjectSessionResult> OpenAsync(string projectFile, CancellationToken cancellationToken = default);

    Task<StudioProjectSessionResult> SaveAsync(InstallerProject project, string? currentProjectPath, NativePreviewViewModel nativePreview, CancellationToken cancellationToken = default);

    Task<StudioProjectSessionResult> SaveAsAsync(InstallerProject project, NativePreviewViewModel nativePreview, CancellationToken cancellationToken = default);

    string? SelectProjectFolder();
}

public sealed class StudioProjectSessionService : IStudioProjectSessionService
{
    private readonly IFileDialogService _fileDialogs;
    private readonly INewProjectDialogService _newProjectDialogService;
    private readonly IProjectRepository _repository;

    public StudioProjectSessionService(
        IFileDialogService fileDialogs,
        INewProjectDialogService newProjectDialogService,
        IProjectRepository repository)
    {
        _fileDialogs = fileDialogs;
        _newProjectDialogService = newProjectDialogService;
        _repository = repository;
    }

    public StudioProjectSessionResult CreateNew()
    {
        var project = _newProjectDialogService.ShowDialog();
        if (project is null)
        {
            return new StudioProjectSessionResult(false, null, null, "Ready", null);
        }

        return new StudioProjectSessionResult(true, project, null, "Created a new project.", "New project created.");
    }

    public async Task<StudioProjectSessionResult> OpenAsync(CancellationToken cancellationToken = default)
    {
        var projectFile = _fileDialogs.OpenProjectFile();
        if (string.IsNullOrWhiteSpace(projectFile))
        {
            return new StudioProjectSessionResult(false, null, null, "Ready", null);
        }

        return await OpenAsync(projectFile, cancellationToken).ConfigureAwait(false);
    }

    public async Task<StudioProjectSessionResult> OpenAsync(string projectFile, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(projectFile))
        {
            return new StudioProjectSessionResult(false, null, null, "Ready", null);
        }

        var loaded = await _repository.LoadProjectAsync(projectFile, cancellationToken).ConfigureAwait(false);
        if (loaded is null)
        {
            return new StudioProjectSessionResult(false, null, null, $"Project '{projectFile}' could not be opened.", null);
        }

        await _repository.RecordRecentProjectAsync(projectFile, cancellationToken).ConfigureAwait(false);
        return new StudioProjectSessionResult(true, loaded, projectFile, $"Opened {projectFile}.", $"Opened project: {projectFile}");
    }

    public string? SelectProjectFolder() => _fileDialogs.SelectFolder();

    public async Task<StudioProjectSessionResult> SaveAsync(InstallerProject project, string? currentProjectPath, NativePreviewViewModel nativePreview, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(project);
        ArgumentNullException.ThrowIfNull(nativePreview);

        var path = currentProjectPath;
        if (string.IsNullOrWhiteSpace(path))
        {
            path = _fileDialogs.SaveProjectFile(project.ProductName + ".asplproj");
        }

        if (string.IsNullOrWhiteSpace(path))
        {
            return new StudioProjectSessionResult(false, null, null, "Ready", null);
        }

        nativePreview.SaveToProject(project);
        await _repository.SaveProjectAsync(path, project, cancellationToken).ConfigureAwait(false);
        return new StudioProjectSessionResult(true, project, path, $"Saved {path}.", $"Saved project: {path}");
    }

    public async Task<StudioProjectSessionResult> SaveAsAsync(InstallerProject project, NativePreviewViewModel nativePreview, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(project);
        ArgumentNullException.ThrowIfNull(nativePreview);

        var path = _fileDialogs.SaveProjectFile(project.ProductName + ".asplproj");
        if (string.IsNullOrWhiteSpace(path))
        {
            return new StudioProjectSessionResult(false, null, null, "Ready", null);
        }

        nativePreview.SaveToProject(project);
        await _repository.SaveProjectAsync(path, project, cancellationToken).ConfigureAwait(false);
        return new StudioProjectSessionResult(true, project, path, $"Saved {path}.", $"Saved project as: {path}");
    }
}

using ASPLShield.Core;

namespace ASPLShield.Studio;

/// <summary>
/// Persists project metadata, build history, templates, and recent file tracking in SQLite.
/// </summary>
public sealed class SqliteProjectRepository : IProjectRepository
{
    private readonly IProjectSerializer _serializer;
    private readonly StudioDatabaseInitializer _initializer;
    private readonly IStudioSqliteConnectionFactory _connectionFactory;

    public SqliteProjectRepository(
        IProjectSerializer serializer,
        StudioDatabaseInitializer initializer,
        IStudioSqliteConnectionFactory connectionFactory)
    {
        _serializer = serializer;
        _initializer = initializer;
        _connectionFactory = connectionFactory;
    }

    public Task InitializeAsync(CancellationToken cancellationToken = default)
        => _initializer.InitializeAsync(cancellationToken);

    public async Task SaveProjectAsync(string path, InstallerProject project, CancellationToken cancellationToken = default)
    {
        await _serializer.SaveAsync(project, path, cancellationToken).ConfigureAwait(false);

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO Projects (ProjectPath, ProductName, Version, Publisher, OutputFolder, LastSavedUtc)
            VALUES ($path, $product, $version, $publisher, $output, $savedUtc)
            ON CONFLICT(ProjectPath) DO UPDATE SET
                ProductName = excluded.ProductName,
                Version = excluded.Version,
                Publisher = excluded.Publisher,
                OutputFolder = excluded.OutputFolder,
                LastSavedUtc = excluded.LastSavedUtc;
            """;
        command.Parameters.AddWithValue("$path", path);
        command.Parameters.AddWithValue("$product", project.ProductName);
        command.Parameters.AddWithValue("$version", project.Version);
        command.Parameters.AddWithValue("$publisher", project.Publisher);
        command.Parameters.AddWithValue("$output", project.OutputFolder);
        command.Parameters.AddWithValue("$savedUtc", DateTimeOffset.UtcNow.ToString("O"));
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }

    public async Task<InstallerProject?> LoadProjectAsync(string path, CancellationToken cancellationToken = default)
    {
        if (!File.Exists(path))
        {
            return null;
        }

        return await _serializer.LoadAsync(path, cancellationToken).ConfigureAwait(false);
    }

    public async Task RecordBuildAsync(BuildHistoryEntry entry, CancellationToken cancellationToken = default)
    {
        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO BuildHistory (ProjectPath, BuiltAtUtc, OutputFolder, Succeeded, Message)
            VALUES ($path, $builtAt, $output, $succeeded, $message);
            """;
        command.Parameters.AddWithValue("$path", entry.ProjectPath);
        command.Parameters.AddWithValue("$builtAt", entry.BuiltAtUtc.ToString("O"));
        command.Parameters.AddWithValue("$output", entry.OutputFolder);
        command.Parameters.AddWithValue("$succeeded", entry.Succeeded ? 1 : 0);
        command.Parameters.AddWithValue("$message", (object?)entry.Message ?? DBNull.Value);
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }

    public async Task<IReadOnlyList<BuildHistoryEntry>> GetBuildHistoryAsync(CancellationToken cancellationToken = default)
    {
        var results = new List<BuildHistoryEntry>();
        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT Id, ProjectPath, BuiltAtUtc, OutputFolder, Succeeded, Message
            FROM BuildHistory
            ORDER BY Id DESC;
            """;
        await using var reader = await command.ExecuteReaderAsync(cancellationToken).ConfigureAwait(false);
        while (await reader.ReadAsync(cancellationToken).ConfigureAwait(false))
        {
            results.Add(new BuildHistoryEntry
            {
                Id = reader.GetInt64(0),
                ProjectPath = reader.GetString(1),
                BuiltAtUtc = DateTimeOffset.Parse(reader.GetString(2)),
                OutputFolder = reader.GetString(3),
                Succeeded = reader.GetInt64(4) == 1,
                Message = reader.IsDBNull(5) ? null : reader.GetString(5)
            });
        }

        return results;
    }

    public async Task RecordRecentProjectAsync(string path, CancellationToken cancellationToken = default)
    {
        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO RecentProjects (ProjectPath, OpenedAtUtc)
            VALUES ($path, $openedAt)
            ON CONFLICT(ProjectPath) DO UPDATE SET
                OpenedAtUtc = excluded.OpenedAtUtc;
            """;
        command.Parameters.AddWithValue("$path", path);
        command.Parameters.AddWithValue("$openedAt", DateTimeOffset.UtcNow.ToString("O"));
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }

    public async Task<IReadOnlyList<RecentProjectEntry>> GetRecentProjectsAsync(CancellationToken cancellationToken = default)
    {
        var results = new List<RecentProjectEntry>();
        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT Id, ProjectPath, OpenedAtUtc
            FROM RecentProjects
            ORDER BY OpenedAtUtc DESC;
            """;
        await using var reader = await command.ExecuteReaderAsync(cancellationToken).ConfigureAwait(false);
        while (await reader.ReadAsync(cancellationToken).ConfigureAwait(false))
        {
            results.Add(new RecentProjectEntry
            {
                Id = reader.GetInt64(0),
                ProjectPath = reader.GetString(1),
                OpenedAtUtc = DateTimeOffset.Parse(reader.GetString(2))
            });
        }

        return results;
    }

    public async Task ClearRecentProjectsAsync(CancellationToken cancellationToken = default)
    {
        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = "DELETE FROM RecentProjects;";
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }

    public async Task SaveTemplateAsync(ProjectTemplateEntry template, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(template);

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenAsync(cancellationToken).ConfigureAwait(false);

        await using var command = connection.CreateCommand();
        if (template.Id > 0)
        {
            command.CommandText = """
                UPDATE Templates
                SET Name = $name,
                    Description = $description,
                    TemplatePath = $path
                WHERE Id = $id;
                """;
            command.Parameters.AddWithValue("$id", template.Id);
        }
        else
        {
            command.CommandText = """
                INSERT INTO Templates (Name, Description, TemplatePath)
                VALUES ($name, $description, $path);
                """;
        }

        command.Parameters.AddWithValue("$name", template.Name);
        command.Parameters.AddWithValue("$description", template.Description);
        command.Parameters.AddWithValue("$path", template.TemplatePath);
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);

        if (template.Id <= 0)
        {
            await using var idCommand = connection.CreateCommand();
            idCommand.CommandText = "SELECT last_insert_rowid();";
            var rowId = await idCommand.ExecuteScalarAsync(cancellationToken).ConfigureAwait(false);
            template.Id = rowId is long longId ? longId : Convert.ToInt64(rowId, System.Globalization.CultureInfo.InvariantCulture);
        }
    }

    public async Task<IReadOnlyList<ProjectTemplateEntry>> GetTemplatesAsync(CancellationToken cancellationToken = default)
    {
        var results = new List<ProjectTemplateEntry>();
        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT Id, Name, Description, TemplatePath
            FROM Templates
            ORDER BY Name COLLATE NOCASE;
            """;
        await using var reader = await command.ExecuteReaderAsync(cancellationToken).ConfigureAwait(false);
        while (await reader.ReadAsync(cancellationToken).ConfigureAwait(false))
        {
            results.Add(new ProjectTemplateEntry
            {
                Id = reader.GetInt64(0),
                Name = reader.GetString(1),
                Description = reader.GetString(2),
                TemplatePath = reader.GetString(3)
            });
        }

        return results;
    }

    public async Task DeleteTemplateAsync(long templateId, CancellationToken cancellationToken = default)
    {
        if (templateId <= 0)
        {
            return;
        }

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenAsync(cancellationToken).ConfigureAwait(false);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            DELETE FROM Templates
            WHERE Id = $id;
            """;
        command.Parameters.AddWithValue("$id", templateId);
        await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
    }
}

using ASPLShield.Build;
using ASPLShield.Core;

namespace ASPLShield.Studio;

public sealed record StudioBuildWorkflowResult(
    bool Succeeded,
    string? StatusText,
    string? ErrorMessage,
    BuildResult? BuildResult,
    IReadOnlyList<string> Messages);

public interface IStudioBuildWorkflowService
{
    Task<StudioBuildWorkflowResult> BuildAsync(
        InstallerProject project,
        string? currentProjectPath,
        string outputDirectory,
        string? setupProjectPath,
        string? uninstallerProjectPath,
        IReadOnlyCollection<string> iisWarnings,
        CancellationToken cancellationToken = default);

    IReadOnlyList<string> Clean(string outputDirectory);
}

public sealed class StudioBuildWorkflowService : IStudioBuildWorkflowService
{
    private readonly IBuildEngine _buildEngine;
    private readonly IProjectRepository _repository;

    public StudioBuildWorkflowService(IBuildEngine buildEngine, IProjectRepository repository)
    {
        _buildEngine = buildEngine;
        _repository = repository;
    }

    public async Task<StudioBuildWorkflowResult> BuildAsync(
        InstallerProject project,
        string? currentProjectPath,
        string outputDirectory,
        string? setupProjectPath,
        string? uninstallerProjectPath,
        IReadOnlyCollection<string> iisWarnings,
        CancellationToken cancellationToken = default)
    {
        try
        {
            // IIS warnings (not elevated, IIS management tools missing, port already in use
            // on this machine, etc.) describe the environment the installer will run in on
            // the *target* machine at install time. They are not a reason to refuse to
            // package the build here, so we surface them as messages instead of throwing.
            var messages = new List<string>();
            foreach (var warning in iisWarnings)
            {
                messages.Add($"IIS warning: {warning}");
            }

            var result = await _buildEngine.BuildAsync(new BuildRequest
            {
                Project = project,
                OutputDirectory = outputDirectory,
                SetupProjectPath = setupProjectPath,
                UninstallerProjectPath = uninstallerProjectPath
            }, cancellationToken).ConfigureAwait(false);

            if (!string.IsNullOrWhiteSpace(currentProjectPath))
            {
                await _repository.RecordBuildAsync(new BuildHistoryEntry
                {
                    ProjectPath = currentProjectPath,
                    OutputFolder = project.OutputFolder,
                    BuiltAtUtc = DateTimeOffset.UtcNow,
                    Succeeded = true,
                    Message = "Build completed successfully."
                }, cancellationToken).ConfigureAwait(false);
            }

            messages.Add($"Build succeeded: {result.SetupExePath}");
            messages.Add($"Package created: {result.PackagePath}");

            if (project.Build.CreateUninstaller)
            {
                messages.Add($"Standalone uninstaller enabled: {result.UninstallExePath}");
            }
            else
            {
                messages.Add("Self-uninstall mode enabled. The installer will rely on Setup.exe --uninstall.");
            }

            if (!string.IsNullOrWhiteSpace(result.MsiAuthoringPath))
            {
                if (project.Build.MsiAuthoringMode == MsiAuthoringMode.NativePreview)
                {
                    messages.Add($"Native MSI preview plan generated: {result.MsiAuthoringPath}");
                    if (!string.IsNullOrWhiteSpace(result.MsiDatabasePath))
                    {
                        messages.Add($"Native MSI database written: {result.MsiDatabasePath}");
                    }
                }
                else
                {
                    messages.Add($"MSI authoring generated: {result.MsiAuthoringPath}");
                }
            }

            if (!string.IsNullOrWhiteSpace(result.MsiPath))
            {
                messages.Add($"MSI compiled: {result.MsiPath}");
            }

            if (!string.IsNullOrWhiteSpace(result.MsiDatabasePath))
            {
                messages.Add($"Native database path: {result.MsiDatabasePath}");
            }

            foreach (var warning in result.Warnings)
            {
                messages.Add($"Build warning: {warning}");
            }

            return new StudioBuildWorkflowResult(
                Succeeded: true,
                StatusText: project.Build.CreateUninstaller
                    ? "Build completed successfully."
                    : "Build completed successfully in self-uninstall mode.",
                ErrorMessage: null,
                BuildResult: result,
                Messages: messages);
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrWhiteSpace(currentProjectPath))
            {
                await _repository.RecordBuildAsync(new BuildHistoryEntry
                {
                    ProjectPath = currentProjectPath,
                    OutputFolder = project.OutputFolder,
                    BuiltAtUtc = DateTimeOffset.UtcNow,
                    Succeeded = false,
                    Message = ex.Message
                }, cancellationToken).ConfigureAwait(false);
            }

            return new StudioBuildWorkflowResult(
                Succeeded: false,
                StatusText: "Build failed.",
                ErrorMessage: ex.Message,
                BuildResult: null,
                Messages: new[] { $"Build failed: {ex.Message}" });
        }
    }

    public IReadOnlyList<string> Clean(string outputDirectory)
    {
        var messages = new List<string>();
        if (string.IsNullOrWhiteSpace(outputDirectory) || !Directory.Exists(outputDirectory))
        {
            messages.Add("Nothing to clean: output folder does not exist yet.");
            return messages;
        }

        try
        {
            foreach (var file in Directory.EnumerateFiles(outputDirectory))
            {
                File.Delete(file);
            }

            foreach (var directory in Directory.EnumerateDirectories(outputDirectory))
            {
                Directory.Delete(directory, recursive: true);
            }

            messages.Add($"Cleaned output folder: {outputDirectory}");
        }
        catch (Exception ex)
        {
            messages.Add($"Clean failed: {ex.Message}");
        }

        return messages;
    }
}
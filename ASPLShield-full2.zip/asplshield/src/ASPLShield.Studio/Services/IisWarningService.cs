using System.Net.NetworkInformation;
using ASPLShield.Core;
using ASPLShield.ServiceInstaller;

namespace ASPLShield.Studio;

public interface IIisWarningService
{
    IReadOnlyList<string> GetWarnings(InstallerProject project);
}

public sealed class IisWarningService : IIisWarningService
{
    private readonly IStudioShellService _shellService;

    public IisWarningService(IStudioShellService shellService)
    {
        _shellService = shellService;
    }

    public IReadOnlyList<string> GetWarnings(InstallerProject project)
    {
        var warnings = new List<string>();
        if (project.IisSites.Count == 0)
        {
            return warnings;
        }

        if (!_shellService.IsAdministrator())
        {
            warnings.Add("IIS deployment requires administrator rights to configure sites and application pools.");
        }

        if (!WindowsPrerequisiteChecker.IsIisManagementAvailable())
        {
            warnings.Add("IIS management support was not detected. Install the Web Server role and IIS management tools before building or deploying.");
        }

        var activePorts = IPGlobalProperties.GetIPGlobalProperties().GetActiveTcpListeners().Select(listener => listener.Port).ToHashSet();
        foreach (var site in project.IisSites)
        {
            foreach (var binding in site.Bindings)
            {
                var port = _shellService.ParsePort(binding.BindingInformation);
                if (port is > 0 && activePorts.Contains(port.Value))
                {
                    warnings.Add($"Port {port.Value} is already in use for IIS site '{site.SiteName}'.");
                }
            }

            if (!string.IsNullOrWhiteSpace(site.PhysicalPath) &&
                !site.PhysicalPath.Contains("[InstallFolder]", StringComparison.OrdinalIgnoreCase) &&
                !Path.IsPathRooted(site.PhysicalPath))
            {
                warnings.Add($"IIS site '{site.SiteName}' uses a relative physical path. Prefer [InstallFolder] or an explicit install path.");
            }
        }

        return warnings;
    }
}

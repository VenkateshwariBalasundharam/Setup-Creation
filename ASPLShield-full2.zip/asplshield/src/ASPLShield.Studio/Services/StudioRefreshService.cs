using ASPLShield.Core;

namespace ASPLShield.Studio;

public sealed record StudioRefreshSnapshot(
    string? SetupProjectPath,
    string? UninstallerProjectPath,
    IReadOnlyList<string> ValidationMessages,
    IReadOnlyList<string> IisWarnings,
    IReadOnlyList<string> RecentLogEntries,
    string RecentLogsSummary,
    string BuildTooltip);

public interface IStudioRefreshService
{
    StudioRefreshSnapshot Refresh(
        InstallerProject project,
        PropertiesViewModel properties,
        bool registryHasErrors,
        bool serviceHasErrors);
}

public sealed class StudioRefreshService : IStudioRefreshService
{
    private readonly IProjectValidationService _validationService;
    private readonly IIisWarningService _iisWarningService;
    private readonly IStudioLogMonitorService _logMonitor;

    public StudioRefreshService(
        IProjectValidationService validationService,
        IIisWarningService iisWarningService,
        IStudioLogMonitorService logMonitor)
    {
        _validationService = validationService;
        _iisWarningService = iisWarningService;
        _logMonitor = logMonitor;
    }

    public StudioRefreshSnapshot Refresh(
        InstallerProject project,
        PropertiesViewModel properties,
        bool registryHasErrors,
        bool serviceHasErrors)
    {
        ArgumentNullException.ThrowIfNull(project);
        ArgumentNullException.ThrowIfNull(properties);

        var setupProjectPath = StudioPaths.LocateRuntimeProjectPath();
        var uninstallerProjectPath = StudioPaths.LocateUninstallerProjectPath();
        var iisWarnings = _iisWarningService.GetWarnings(project);
        var validation = _validationService.BuildResult(
            new ProjectValidationSnapshot(
                properties.ProjectEditor.HasErrors,
                properties.FileEditor.HasErrors,
                properties.ShortcutEditor.HasErrors,
                properties.BuildEditor.HasErrors,
                properties.PrerequisiteEditor.HasErrors,
                setupProjectPath is null,
                project.Build.CreateUninstaller && uninstallerProjectPath is null,
                properties.BuildEditor.UpgradeVersionMinError,
                properties.BuildEditor.UpgradeVersionMaxError,
                properties.BuildEditor.UpgradeActionPropertyError,
                registryHasErrors,
                serviceHasErrors),
            iisWarnings);

        var recentLogEntries = _logMonitor.ReadRecentEntries(5);
        var recentLogsSummary = recentLogEntries.Count == 0
            ? "No recent installer logs found."
            : $"{recentLogEntries.Count} recent log entr{(recentLogEntries.Count == 1 ? "y" : "ies")} loaded.";

        var buildTooltip = _validationService.BuildTooltip(validation.Errors, iisWarnings);

        return new StudioRefreshSnapshot(
            setupProjectPath,
            uninstallerProjectPath,
            validation.Errors,
            iisWarnings,
            recentLogEntries,
            recentLogsSummary,
            buildTooltip);
    }
}

using System.Text.Json;
using ASPLShield.Common;
using ASPLShield.Core;

namespace ASPLShield.Studio;

public interface IIntegrationSettingsStore
{
    Task<IntegrationSettings> LoadAsync(CancellationToken cancellationToken = default);

    Task SaveAsync(IntegrationSettings settings, CancellationToken cancellationToken = default);
}

public sealed class FileIntegrationSettingsStore : IIntegrationSettingsStore
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web) { WriteIndented = true };

    public async Task<IntegrationSettings> LoadAsync(CancellationToken cancellationToken = default)
    {
        var path = GetPath();
        if (!File.Exists(path))
        {
            return new IntegrationSettings();
        }

        await using var stream = File.OpenRead(path);
        return await JsonSerializer.DeserializeAsync<IntegrationSettings>(stream, JsonOptions, cancellationToken).ConfigureAwait(false)
            ?? new IntegrationSettings();
    }

    public async Task SaveAsync(IntegrationSettings settings, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(settings);

        var path = GetPath();
        Directory.CreateDirectory(Path.GetDirectoryName(path) ?? StudioPaths.AppRoot);
        await using var stream = File.Create(path);
        await JsonSerializer.SerializeAsync(stream, settings, JsonOptions, cancellationToken).ConfigureAwait(false);
    }

    public static string GetPath() => Path.Combine(StudioPaths.AppRoot, "asplshield.integration.json");
}

public sealed class IntegrationSettingsViewModel : ObservableObject
{
    private readonly IIntegrationSettingsStore _store;
    private IntegrationSettings _settings = new();

    public IntegrationSettingsViewModel(IIntegrationSettingsStore store)
    {
        _store = store;
    }

    public string? SigningCertificatePath
    {
        get => _settings.SigningCertificatePath;
        set => Update(settings => settings.SigningCertificatePath = value);
    }

    public string? SigningCertificatePassword
    {
        get => _settings.SigningCertificatePassword;
        set => Update(settings => settings.SigningCertificatePassword = value);
    }

    public string? SigningTimestampUrl
    {
        get => _settings.SigningTimestampUrl;
        set => Update(settings => settings.SigningTimestampUrl = value);
    }

    public string? SigningToolPath
    {
        get => _settings.SigningToolPath;
        set => Update(settings => settings.SigningToolPath = value);
    }

    public string? UpdateFeedUri
    {
        get => _settings.UpdateFeedUri;
        set => Update(settings => settings.UpdateFeedUri = value);
    }

    public string FilePath => FileIntegrationSettingsStore.GetPath();

    public async Task LoadAsync(CancellationToken cancellationToken = default)
    {
        _settings = await _store.LoadAsync(cancellationToken).ConfigureAwait(false);
        Refresh();
    }

    public Task SaveAsync(CancellationToken cancellationToken = default)
        => _store.SaveAsync(_settings, cancellationToken);

    private void Update(Action<IntegrationSettings> mutator)
    {
        mutator(_settings);
        OnPropertyChanged(string.Empty);
        _ = SaveAsync();
    }

    public void Refresh(bool notifyPropertyChanged = true)
    {
        if (!notifyPropertyChanged)
        {
            return;
        }

        OnPropertyChanged(nameof(SigningCertificatePath));
        OnPropertyChanged(nameof(SigningCertificatePassword));
        OnPropertyChanged(nameof(SigningTimestampUrl));
        OnPropertyChanged(nameof(SigningToolPath));
        OnPropertyChanged(nameof(UpdateFeedUri));
        OnPropertyChanged(nameof(FilePath));
    }
}

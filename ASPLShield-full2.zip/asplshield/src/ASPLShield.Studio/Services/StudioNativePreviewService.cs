using System.Text.Json;
using ASPLShield.Build;
using ASPLShield.Core;

namespace ASPLShield.Studio;

public interface IStudioNativePreviewService
{
    Task LoadAsync(NativePreviewViewModel preview, InstallerProject project, string planPath, string? databasePath, CancellationToken cancellationToken = default);

    Task<string?> ExportAsync(string sourceDatabasePath, string defaultFileName, CancellationToken cancellationToken = default);
}

public sealed class StudioNativePreviewService : IStudioNativePreviewService
{
    private readonly IFileDialogService _fileDialogs;

    public StudioNativePreviewService(IFileDialogService fileDialogs)
    {
        _fileDialogs = fileDialogs;
    }

    public async Task LoadAsync(NativePreviewViewModel preview, InstallerProject project, string planPath, string? databasePath, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(preview);
        ArgumentNullException.ThrowIfNull(project);

        if (!string.IsNullOrWhiteSpace(databasePath) && File.Exists(databasePath))
        {
            var database = await TryLoadNativeDatabaseAsync(databasePath, cancellationToken).ConfigureAwait(false);
            if (database is null && string.Equals(Path.GetExtension(databasePath), ".msi", StringComparison.OrdinalIgnoreCase))
            {
                var previewPath = GetNativePreviewDatabasePath(databasePath);
                if (File.Exists(previewPath))
                {
                    database = await TryLoadNativeDatabaseAsync(previewPath, cancellationToken).ConfigureAwait(false);
                }
            }

            if (database is not null)
            {
                preview.ApplyDatabase(database, planPath, databasePath);
                preview.MergePersistedOperations(project.NativePreviewOperations);
                return;
            }
        }

        if (!File.Exists(planPath))
        {
            preview.Clear();
            return;
        }

        await using var stream = File.OpenRead(planPath);
        var plan = await JsonSerializer.DeserializeAsync<NativeMsiAuthoringPlan>(stream, cancellationToken: cancellationToken).ConfigureAwait(false);
        if (plan is null)
        {
            preview.Clear();
            return;
        }

        preview.ApplyPlan(plan, planPath, databasePath);
        preview.MergePersistedOperations(project.NativePreviewOperations);
    }

    public async Task<string?> ExportAsync(string sourceDatabasePath, string defaultFileName, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(sourceDatabasePath) || !File.Exists(sourceDatabasePath))
        {
            return null;
        }

        var targetPath = _fileDialogs.SaveNativeDatabaseFile(defaultFileName);
        if (string.IsNullOrWhiteSpace(targetPath))
        {
            return null;
        }

        await using var source = File.OpenRead(sourceDatabasePath);
        await using var target = File.Create(targetPath);
        await source.CopyToAsync(target, cancellationToken).ConfigureAwait(false);
        return targetPath;
    }

    private static async Task<NativeMsiDatabase?> TryLoadNativeDatabaseAsync(string path, CancellationToken cancellationToken)
    {
        try
        {
            await using var databaseStream = File.OpenRead(path);
            return await JsonSerializer.DeserializeAsync<NativeMsiDatabase>(databaseStream, cancellationToken: cancellationToken).ConfigureAwait(false);
        }
        catch (JsonException)
        {
            return null;
        }
    }

    private static string GetNativePreviewDatabasePath(string databasePath)
        => Path.Combine(Path.GetDirectoryName(databasePath) ?? string.Empty, $"{Path.GetFileNameWithoutExtension(databasePath)}.preview.json");
}

using ASPLShield.Core;

namespace ASPLShield.Studio;

public sealed record ProjectValidationSnapshot(
    bool ProjectDetailsError,
    bool FileError,
    bool ShortcutError,
    bool BuildError,
    bool PrerequisiteError,
    bool SetupProjectMissing,
    bool UninstallerProjectMissing,
    bool UpgradeVersionMinError,
    bool UpgradeVersionMaxError,
    bool UpgradeActionPropertyError,
    bool RegistryError,
    bool ServiceError);

public interface IProjectValidationService
{
    ProjectValidationResult BuildResult(ProjectValidationSnapshot snapshot, IEnumerable<string> iisWarnings);

    string BuildTooltip(IReadOnlyCollection<string> validationMessages, IReadOnlyCollection<string> iisWarnings);
}

public sealed class ProjectValidationService : IProjectValidationService
{
    public ProjectValidationResult BuildResult(ProjectValidationSnapshot snapshot, IEnumerable<string> iisWarnings)
    {
        var result = new ProjectValidationResult();

        AddIf(result, snapshot.ProjectDetailsError, "Project details need attention.");
        AddIf(result, snapshot.FileError, "Selected file needs attention.");
        AddIf(result, snapshot.ShortcutError, "Selected shortcut needs attention.");
        AddIf(result, snapshot.BuildError, "Build settings need attention.");
        AddIf(result, snapshot.PrerequisiteError, "Prerequisite entries need attention.");
        AddIf(result, snapshot.SetupProjectMissing, "Setup project could not be located.");
        AddIf(result, snapshot.UninstallerProjectMissing, "Uninstaller project could not be located.");
        AddIf(result, snapshot.UpgradeVersionMinError, "Upgrade minimum version is invalid.");
        AddIf(result, snapshot.UpgradeVersionMaxError, "Upgrade maximum version is invalid or earlier than the minimum version.");
        AddIf(result, snapshot.UpgradeActionPropertyError, "Upgrade action property is required.");
        AddIf(result, snapshot.RegistryError, "Registry entries need attention.");
        AddIf(result, snapshot.ServiceError, "Service entries need attention.");

        // NOTE: iisWarnings are intentionally NOT added as errors here.
        // They are advisory information about the *current* (build) machine,
        // such as "IIS management tooling isn't installed on this PC" — that
        // does not mean the generated installer is broken, since it will run
        // on the *target* machine, not this one. They are surfaced separately
        // via IisWarnings in the UI so the user is aware, but they must not
        // gate CanBuild the way real project-validation errors do.
        return result;
    }

    public string BuildTooltip(IReadOnlyCollection<string> validationMessages, IReadOnlyCollection<string> iisWarnings)
    {
        if (validationMessages.Count == 0 && iisWarnings.Count == 0)
        {
            return "Build project";
        }

        if (validationMessages.Count == 0)
        {
            return $"Build project (advisory only):{Environment.NewLine}{string.Join(Environment.NewLine, iisWarnings)}";
        }

        return $"Build blocked by validation:{Environment.NewLine}{string.Join(Environment.NewLine, validationMessages)}";
    }

    private static void AddIf(ProjectValidationResult result, bool condition, string message)
    {
        if (condition)
        {
            result.AddError(message);
        }
    }
}

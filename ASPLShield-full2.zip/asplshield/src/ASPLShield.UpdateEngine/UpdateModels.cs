namespace ASPLShield.UpdateEngine;

public sealed class UpdatePackageInfo
{
    public string CurrentVersion { get; set; } = string.Empty;

    public string LatestVersion { get; set; } = string.Empty;

    public string DownloadUrl { get; set; } = string.Empty;

    public string? ReleaseNotes { get; set; }
}

public sealed class UpdateCheckResult
{
    public bool HasUpdate { get; init; }

    public UpdatePackageInfo? Package { get; init; }

    public string? Message { get; init; }
}

using System.Net.Http.Json;
using System.Text.Json;
using ASPLShield.Common;
using ASPLShield.Core;

namespace ASPLShield.UpdateEngine;

/// <summary>
/// Auto-updater that can evaluate a local file or HTTP(S) feed for newer releases.
/// </summary>
public sealed class UpdateEngineClient : IAutoUpdater
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);
    private readonly HttpClient _httpClient;
    private readonly Uri? _feedUri;

    public UpdateEngineClient()
        : this(new HttpClient(), GetConfiguredFeedUri())
    {
    }

    public UpdateEngineClient(HttpClient httpClient, Uri? feedUri = null)
    {
        _httpClient = Guard.AgainstNull(httpClient, nameof(httpClient));
        _feedUri = feedUri;
    }

    public async Task CheckForUpdatesAsync(CancellationToken cancellationToken = default)
    {
        if (_feedUri is null)
        {
            return;
        }

        await CheckForUpdatesAsync(_feedUri, cancellationToken).ConfigureAwait(false);
    }

    public async Task<UpdateCheckResult> CheckForUpdatesAsync(Uri serviceEndpoint, CancellationToken cancellationToken = default)
    {
        Guard.AgainstNull(serviceEndpoint, nameof(serviceEndpoint));
        var manifest = await ReadManifestAsync(serviceEndpoint, cancellationToken).ConfigureAwait(false);

        if (!Version.TryParse(manifest.CurrentVersion, out var currentVersion) || !Version.TryParse(manifest.LatestVersion, out var latestVersion))
        {
            return new UpdateCheckResult
            {
                HasUpdate = false,
                Message = "Update feed version information is invalid."
            };
        }

        var hasUpdate = latestVersion > currentVersion;
        if (hasUpdate && string.IsNullOrWhiteSpace(manifest.DownloadUrl))
        {
            return new UpdateCheckResult
            {
                HasUpdate = false,
                Message = "Update feed is missing a download URL."
            };
        }

        return new UpdateCheckResult
        {
            HasUpdate = hasUpdate,
            Package = hasUpdate ? new UpdatePackageInfo
            {
                CurrentVersion = manifest.CurrentVersion,
                LatestVersion = manifest.LatestVersion,
                DownloadUrl = NormalizeDownloadUrl(manifest.DownloadUrl),
                ReleaseNotes = manifest.ReleaseNotes
            } : null,
            Message = hasUpdate
                ? $"Update available: {manifest.LatestVersion}"
                : "Already running the latest version."
        };
    }

    private async Task<UpdateFeedManifest> ReadManifestAsync(Uri serviceEndpoint, CancellationToken cancellationToken)
    {
        if (serviceEndpoint.IsFile || serviceEndpoint.Scheme.Equals(Uri.UriSchemeFile, StringComparison.OrdinalIgnoreCase))
        {
            var path = serviceEndpoint.IsAbsoluteUri ? serviceEndpoint.LocalPath : serviceEndpoint.OriginalString;
            await using var stream = File.OpenRead(path);
            return await JsonSerializer.DeserializeAsync<UpdateFeedManifest>(stream, JsonOptions, cancellationToken).ConfigureAwait(false)
                ?? throw new InvalidDataException("Update feed file could not be read.");
        }

        using var response = await _httpClient.GetAsync(serviceEndpoint, cancellationToken).ConfigureAwait(false);
        response.EnsureSuccessStatusCode();
        await using var responseStream = await response.Content.ReadAsStreamAsync(cancellationToken).ConfigureAwait(false);
        return await JsonSerializer.DeserializeAsync<UpdateFeedManifest>(responseStream, JsonOptions, cancellationToken).ConfigureAwait(false)
            ?? throw new InvalidDataException("Update feed response could not be read.");
    }

    private static Uri? GetConfiguredFeedUri()
    {
        var settings = IntegrationSettingsLoader.Current;
        var configured = settings.UpdateFeedUri ?? Environment.GetEnvironmentVariable("ASPLSHIELD_UPDATE_FEED") ?? LoadInstalledFeedUri();
        if (string.IsNullOrWhiteSpace(configured))
        {
            return null;
        }

        if (Uri.TryCreate(configured, UriKind.Absolute, out var absolute))
        {
            return absolute;
        }

        var fullPath = Path.GetFullPath(configured);
        return Uri.TryCreate(fullPath, UriKind.Absolute, out absolute)
            ? absolute
            : new Uri(fullPath);
    }

    private static string? LoadInstalledFeedUri()
    {
        foreach (var candidate in GetInstallStateCandidates())
        {
            if (!File.Exists(candidate))
            {
                continue;
            }

            try
            {
                var json = File.ReadAllText(candidate);
                var state = JsonSerializer.Deserialize<InstalledUpdateState>(json, JsonOptions);
                if (!string.IsNullOrWhiteSpace(state?.UpdateFeedUri))
                {
                    return state.UpdateFeedUri;
                }
            }
            catch
            {
            }
        }

        return null;
    }

    private static IEnumerable<string> GetInstallStateCandidates()
    {
        var baseDirectory = AppContext.BaseDirectory;
        yield return Path.Combine(baseDirectory, "asplshield.installstate.json");

        var parent = Directory.GetParent(baseDirectory)?.FullName;
        if (!string.IsNullOrWhiteSpace(parent))
        {
            yield return Path.Combine(parent, "asplshield.installstate.json");
        }
    }

    private static string NormalizeDownloadUrl(string downloadUrl)
    {
        if (Uri.TryCreate(downloadUrl, UriKind.Absolute, out var absolute))
        {
            return absolute.ToString();
        }

        if (File.Exists(downloadUrl))
        {
            return new Uri(Path.GetFullPath(downloadUrl)).ToString();
        }

        return downloadUrl;
    }

    private sealed class InstalledUpdateState
    {
        public string? UpdateFeedUri { get; set; }
    }
}

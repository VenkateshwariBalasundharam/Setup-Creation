namespace ASPLShield.UpdateEngine;

/// <summary>
/// Declarative update feed payload consumed by the auto-updater.
/// </summary>
public sealed class UpdateFeedManifest
{
    public string CurrentVersion { get; set; } = string.Empty;

    public string LatestVersion { get; set; } = string.Empty;

    public string DownloadUrl { get; set; } = string.Empty;

    public string? ReleaseNotes { get; set; }
}

using System.Security.Principal;
using System.Text.Json;
using System.Text.Json.Nodes;
using ASPLShield.Core;
using ASPLShield.PackageEngine;
using ASPLShield.ServiceInstaller;
using Microsoft.Win32;

namespace ASPLShield.Runtime;

public interface IInstallationService
{
    Task<InstallationState> InstallAsync(AsplPackageInfo package, string installFolder, IProgress<InstallationProgress> progress, CustomerCustomization? customization = null, CancellationToken cancellationToken = default);

    Task UninstallAsync(string installFolder, CancellationToken cancellationToken = default);
}

/// <summary>
/// Branding details the installing customer supplied on the optional customization page.
/// </summary>
public sealed class CustomerCustomization
{
    public string? CompanyName { get; set; }

    public string? LogoPath { get; set; }

    public string? BrandColorHex { get; set; }

    public Dictionary<string, string> AppSettingsValues { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class InstallationState
{
    public string ProductName { get; set; } = string.Empty;

    public string ProductVersion { get; set; } = string.Empty;

    public string Publisher { get; set; } = string.Empty;

    public string InstallFolder { get; set; } = string.Empty;

    public string PackagePath { get; set; } = string.Empty;

    public string? UpdateFeedUri { get; set; }

    public List<string> ShortcutPaths { get; set; } = new();
}

public sealed class InstallationService : IInstallationService
{
    private readonly IPackageEngine _packageEngine;
    private readonly IPrerequisiteChecker _prerequisiteChecker;
    private readonly WindowsRegistryInstaller _registryInstaller = new();
    private readonly WindowsServiceInstaller _serviceInstaller = new();
    private readonly WindowsIisInstaller _iisInstaller = new();
    private readonly string _logRoot = Path.Combine(Path.GetTempPath(), "ASPLShield", "Logs");

    public InstallationService(IPackageEngine? packageEngine = null, IPrerequisiteChecker? prerequisiteChecker = null)
    {
        _packageEngine = packageEngine ?? new AsplPackageEngine();
        _prerequisiteChecker = prerequisiteChecker ?? new WindowsPrerequisiteChecker();
    }

    public async Task<InstallationState> InstallAsync(AsplPackageInfo package, string installFolder, IProgress<InstallationProgress> progress, CustomerCustomization? customization = null, CancellationToken cancellationToken = default)
    {
        if (package is null)
        {
            throw new ArgumentNullException(nameof(package));
        }

        var state = new InstallationState
        {
            ProductName = package.Manifest.ProductName,
            ProductVersion = package.Manifest.Version,
            Publisher = package.Manifest.Publisher,
            InstallFolder = installFolder,
            PackagePath = package.PackagePath,
            UpdateFeedUri = IntegrationSettingsLoader.Current.UpdateFeedUri
        };

        progress.Report(new InstallationProgress { Percent = 3, Message = "Checking prerequisites..." });
        await EnsurePrerequisitesAsync(package.Manifest, cancellationToken).ConfigureAwait(true);

        Directory.CreateDirectory(installFolder);

        progress.Report(new InstallationProgress { Percent = 5, Message = "Extracting application files..." });
        try
        {
            await _packageEngine.ExtractPackageAsync(package.PackagePath, installFolder, cancellationToken).ConfigureAwait(true);

            if (customization?.AppSettingsValues.Count > 0)
            {
                progress.Report(new InstallationProgress { Percent = 35, Message = "Applying setup values..." });
                await ApplyAppSettingsAsync(installFolder, customization.AppSettingsValues, cancellationToken).ConfigureAwait(true);
            }

            string? brandedIconPath = null;
            if (package.Manifest.AllowCustomerCustomization && customization is not null)
            {
                progress.Report(new InstallationProgress { Percent = 40, Message = "Applying your branding..." });
                brandedIconPath = ApplyCustomerBranding(installFolder, customization);
            }

            progress.Report(new InstallationProgress { Percent = 45, Message = "Creating shortcuts..." });
            foreach (var shortcut in package.Manifest.Shortcuts)
            {
                var shortcutPath = CreateShortcut(installFolder, shortcut, package.Manifest.ProductName, brandedIconPath);
                state.ShortcutPaths.Add(shortcutPath);
            }

            progress.Report(new InstallationProgress { Percent = 55, Message = "Writing registry entries..." });
            await InstallRegistryAsync(package.Manifest, installFolder, cancellationToken).ConfigureAwait(true);

            progress.Report(new InstallationProgress { Percent = 62, Message = "Installing services..." });
            await InstallServicesAsync(package.Manifest, installFolder, cancellationToken).ConfigureAwait(true);

            progress.Report(new InstallationProgress { Percent = 70, Message = "Configuring IIS..." });
            await InstallIisAsync(package.Manifest, installFolder, cancellationToken).ConfigureAwait(true);

            progress.Report(new InstallationProgress { Percent = 75, Message = "Copying uninstaller..." });
            var uninstallerPath = CopyUninstallerBootstrapper(installFolder);
            if (string.IsNullOrWhiteSpace(uninstallerPath))
            {
                progress.Report(new InstallationProgress { Percent = 78, Message = "Creating self-uninstall bootstrapper..." });
                uninstallerPath = CopySelfBootstrapper(installFolder);
            }

            progress.Report(new InstallationProgress { Percent = 85, Message = "Registering uninstall information..." });
            WriteUninstallInformation(package.Manifest, package.PackagePath, installFolder, uninstallerPath);

            progress.Report(new InstallationProgress { Percent = 92, Message = "Saving installation state..." });
            var statePath = Path.Combine(installFolder, "asplshield.installstate.json");
            await File.WriteAllTextAsync(statePath, JsonSerializer.Serialize(state, new JsonSerializerOptions { WriteIndented = true }), cancellationToken).ConfigureAwait(true);
            await WriteLogAsync("install.log", $"Installation state saved for {state.ProductName} {state.ProductVersion} by {state.Publisher}. Update feed: {state.UpdateFeedUri ?? "not configured"}.", cancellationToken).ConfigureAwait(false);

            progress.Report(new InstallationProgress { Percent = 100, Message = "Installation complete." });
            return state;
        }
        catch (Exception ex)
        {
            var root = UnwrapException(ex);
            var rootDescription = string.IsNullOrWhiteSpace(root.Message)
                ? $"{root.GetType().Name} (HRESULT 0x{root.HResult:X8})"
                : $"{root.GetType().Name}: {root.Message} (HRESULT 0x{root.HResult:X8})";
            await WriteLogAsync("install.log", $"Installation failed for '{package.Manifest.ProductName} {package.Manifest.Version}'. Rolling back. Cause: {rootDescription}{Environment.NewLine}Full exception: {ex}", cancellationToken).ConfigureAwait(false);
            await RollbackAsync(package.Manifest, installFolder, state, cancellationToken).ConfigureAwait(true);
            throw new InvalidOperationException(rootDescription, ex);
        }
    }

    private static async Task ApplyAppSettingsAsync(string installFolder, IReadOnlyDictionary<string, string> values, CancellationToken cancellationToken)
    {
        var path = Path.Combine(installFolder, "appsettings.json");
        JsonObject root;
        if (File.Exists(path))
        {
            var existing = JsonNode.Parse(await File.ReadAllTextAsync(path, cancellationToken).ConfigureAwait(false));
            root = existing as JsonObject ?? new JsonObject();
        }
        else
        {
            root = new JsonObject();
        }

        foreach (var pair in values)
        {
            var segments = pair.Key.Split(':', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            if (segments.Length == 0) continue;
            var current = root;
            for (var index = 0; index < segments.Length - 1; index++)
            {
                if (current[segments[index]] is not JsonObject next)
                {
                    next = new JsonObject();
                    current[segments[index]] = next;
                }
                current = next;
            }

            current[segments[^1]] = ParseJsonValue(pair.Value);
        }

        await File.WriteAllTextAsync(path, root.ToJsonString(new JsonSerializerOptions { WriteIndented = true }), cancellationToken).ConfigureAwait(false);
    }

    private static JsonNode ParseJsonValue(string value)
    {
        if (bool.TryParse(value, out var boolean)) return JsonValue.Create(boolean)!;
        if (decimal.TryParse(value, out var number)) return JsonValue.Create(number)!;
        return JsonValue.Create(value)!;
    }

    private async Task EnsurePrerequisitesAsync(AsplPackageManifest manifest, CancellationToken cancellationToken)
    {
        foreach (var prerequisite in manifest.Prerequisites)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var entry = new PrerequisiteEntry
            {
                Name = prerequisite.Name,
                Version = prerequisite.Version,
                Required = prerequisite.Required,
                Description = prerequisite.Description,
                DetectionTarget = prerequisite.DetectionTarget,
                MinimumVersion = prerequisite.MinimumVersion,
                ExpectedValue = prerequisite.ExpectedValue,
                Type = ParsePrerequisiteType(prerequisite.Type)
            };

            var satisfied = await _prerequisiteChecker.IsSatisfiedAsync(entry, cancellationToken).ConfigureAwait(true);
            if (satisfied)
            {
                continue;
            }

            var message = prerequisite.Required
                ? $"Required prerequisite missing: {prerequisite.Name}"
                : $"Optional prerequisite missing: {prerequisite.Name}";

            if (prerequisite.Required)
            {
                throw new InvalidOperationException(message);
            }
        }
    }

    public async Task UninstallAsync(string installFolder, CancellationToken cancellationToken = default)
    {
        var statePath = Path.Combine(installFolder, "asplshield.installstate.json");
        if (!File.Exists(statePath))
        {
            return;
        }

        var state = JsonSerializer.Deserialize<InstallationState>(await File.ReadAllTextAsync(statePath, cancellationToken).ConfigureAwait(true));
        if (state is null)
        {
            return;
        }

        await WriteLogAsync("uninstall.log", $"Uninstall starting for '{state.ProductName} {state.ProductVersion}' from '{state.InstallFolder}'.", cancellationToken).ConfigureAwait(false);

        if (File.Exists(state.PackagePath))
        {
            try
            {
                var package = await _packageEngine.ReadPackageAsync(state.PackagePath, cancellationToken).ConfigureAwait(true);
                await TryCleanupAsync("registry uninstall", () => UninstallRegistryAsync(package.Manifest, cancellationToken), cancellationToken).ConfigureAwait(true);
                await TryCleanupAsync("service uninstall", () => UninstallServicesAsync(package.Manifest, cancellationToken), cancellationToken).ConfigureAwait(true);
                await TryCleanupAsync("iis uninstall", () => _iisInstaller.UninstallAsync(package.Manifest.IisSites.Select(site => new IisSiteEntry
                {
                    SiteName = site.SiteName,
                    PhysicalPath = site.PhysicalPath,
                    ApplicationPoolName = site.ApplicationPoolName,
                    CreateApplicationPool = site.CreateApplicationPool,
                    StartOnInstall = site.StartOnInstall,
                    Bindings = site.Bindings.Select(binding => new IisSiteBindingEntry
                    {
                        Protocol = binding.Protocol,
                        BindingInformation = binding.BindingInformation
                    }).ToList()
                }), cancellationToken), cancellationToken).ConfigureAwait(true);
            }
            catch (Exception ex)
            {
                await WriteLogAsync("uninstall.log", $"Package metadata could not be read for uninstall: {ex.Message}", cancellationToken).ConfigureAwait(false);
            }
        }

        foreach (var shortcutPath in state.ShortcutPaths)
        {
            await TryDeleteFile(shortcutPath).ConfigureAwait(true);
        }

        CleanupShortcutFolders(state.ShortcutPaths);
        await TryDeleteDirectory(installFolder).ConfigureAwait(true);
        RemoveUninstallInformation(state.ProductName, installFolder);
        await WriteLogAsync("uninstall.log", $"Uninstall complete for '{state.ProductName} {state.ProductVersion}'.", cancellationToken).ConfigureAwait(false);
    }

    private async Task InstallRegistryAsync(AsplPackageManifest manifest, string installFolder, CancellationToken cancellationToken)
    {
        var entries = manifest.RegistryEntries.Select(entry => new RegistryEntry
        {
            RegistryRoot = entry.RegistryRoot,
            KeyPath = entry.KeyPath,
            Name = entry.Name,
            // BUGFIX: entry.Value used to be copied verbatim here, so a Value of literally
            // "[INSTALLFOLDER]" was written to the registry as that literal placeholder text
            // instead of the real install path. Shortcuts/Services/IIS already resolve this
            // token via ResolveInstallPath; Registry values need the same substitution, but
            // only the token-replace half of it - registry values aren't necessarily paths
            // (e.g. a plain version string), so we must not run them through
            // Path.Combine(installFolder, ...) the way ResolveInstallPath does for
            // non-rooted paths, or an unrelated string value would get silently corrupted
            // into "installFolder\thatValue".
            Value = ResolveInstallFolderToken(entry.Value, installFolder),
            ValueKind = entry.ValueKind
        }).ToList();

        if (entries.Count == 0)
        {
            return;
        }

        await _registryInstaller.InstallAsync(entries, cancellationToken).ConfigureAwait(true);
    }

    /// <summary>
    /// Replaces the [InstallFolder] placeholder token in a configured string, if present.
    /// Unlike ResolveInstallPath, this never falls back to Path.Combine for values that
    /// don't contain the token, since callers (e.g. registry values) aren't guaranteed to
    /// be paths at all.
    /// </summary>
    private static string ResolveInstallFolderToken(string configuredValue, string installFolder)
    {
        if (string.IsNullOrEmpty(configuredValue))
        {
            return configuredValue;
        }

        return configuredValue.Contains("[InstallFolder]", StringComparison.OrdinalIgnoreCase)
            ? configuredValue.Replace("[InstallFolder]", installFolder, StringComparison.OrdinalIgnoreCase)
            : configuredValue;
    }

    private async Task UninstallRegistryAsync(AsplPackageManifest manifest, CancellationToken cancellationToken)
    {
        var entries = manifest.RegistryEntries.Select(entry => new RegistryEntry
        {
            RegistryRoot = entry.RegistryRoot,
            KeyPath = entry.KeyPath,
            Name = entry.Name,
            Value = entry.Value,
            ValueKind = entry.ValueKind
        }).ToList();

        if (entries.Count == 0)
        {
            return;
        }

        await _registryInstaller.UninstallAsync(entries, cancellationToken).ConfigureAwait(true);
    }

    private async Task InstallServicesAsync(AsplPackageManifest manifest, string installFolder, CancellationToken cancellationToken)
    {
        foreach (var service in manifest.Services)
        {
            var entry = new ServiceEntry
            {
                ServiceName = service.ServiceName,
                DisplayName = service.DisplayName,
                ExecutablePath = ResolveInstallPath(service.ExecutablePath, installFolder),
                Arguments = service.Arguments,
                Description = service.Description,
                AccountName = service.AccountName,
                AccountPassword = service.AccountPassword,
                AutoStart = service.AutoStart,
                DelayedAutoStart = service.DelayedAutoStart,
                Dependencies = service.Dependencies.ToList()
            };

            await _serviceInstaller.InstallAsync(entry, cancellationToken).ConfigureAwait(true);
        }
    }

    private async Task UninstallServicesAsync(AsplPackageManifest manifest, CancellationToken cancellationToken)
    {
        foreach (var service in manifest.Services)
        {
            if (string.IsNullOrWhiteSpace(service.ServiceName))
            {
                continue;
            }

            await _serviceInstaller.UninstallAsync(service.ServiceName, cancellationToken).ConfigureAwait(true);
        }
    }

    private async Task InstallIisAsync(AsplPackageManifest manifest, string installFolder, CancellationToken cancellationToken)
    {
        var sites = manifest.IisSites.Select(site => new IisSiteEntry
        {
            SiteName = site.SiteName,
            PhysicalPath = string.IsNullOrWhiteSpace(site.PhysicalPath) ? installFolder : ResolveInstallPath(site.PhysicalPath, installFolder),
            ApplicationPoolName = site.ApplicationPoolName,
            CreateApplicationPool = site.CreateApplicationPool,
            StartOnInstall = site.StartOnInstall,
            Bindings = site.Bindings.Select(binding => new IisSiteBindingEntry
            {
                Protocol = binding.Protocol,
                BindingInformation = binding.BindingInformation
            }).ToList()
        }).ToList();

        if (sites.Count == 0)
        {
            return;
        }

        await _iisInstaller.InstallAsync(sites, cancellationToken).ConfigureAwait(true);
    }

    private static string ResolveInstallPath(string configuredPath, string installFolder)
    {
        if (configuredPath.Contains("[InstallFolder]", StringComparison.OrdinalIgnoreCase))
        {
            return configuredPath.Replace("[InstallFolder]", installFolder, StringComparison.OrdinalIgnoreCase);
        }

        if (!Path.IsPathRooted(configuredPath))
        {
            return Path.Combine(installFolder, configuredPath);
        }

        return configuredPath;
    }

    private static PrerequisiteType ParsePrerequisiteType(string type)
        => Enum.TryParse<PrerequisiteType>(type, ignoreCase: true, out var parsed) ? parsed : PrerequisiteType.Unknown;

    private static string CreateShortcut(string installFolder, AsplPackageShortcut shortcut, string productName, string? iconPath = null)
    {
        var shellType = Type.GetTypeFromProgID("WScript.Shell") ?? throw new InvalidOperationException("Windows Script Host is not available.");
        dynamic shell = Activator.CreateInstance(shellType)!;
        var shortcutFolder = shortcut.Location.Equals("Desktop", StringComparison.OrdinalIgnoreCase)
            ? Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)
            : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Programs", productName);

        Directory.CreateDirectory(shortcutFolder);
        var shortcutPath = Path.Combine(shortcutFolder, $"{shortcut.Name}.lnk");
        dynamic shortcutObject = shell.CreateShortcut(shortcutPath);
        shortcutObject.TargetPath = Path.Combine(installFolder, shortcut.TargetPath);
        shortcutObject.WorkingDirectory = string.IsNullOrWhiteSpace(shortcut.WorkingDirectory) ? installFolder : Path.Combine(installFolder, shortcut.WorkingDirectory);
        shortcutObject.Arguments = shortcut.Arguments ?? string.Empty;

        // Only set IconLocation when a real icon file is available; passing an empty/invalid
        // value here is what used to throw ArgumentException from CreateShortcut.
        if (!string.IsNullOrWhiteSpace(iconPath) && File.Exists(iconPath))
        {
            shortcutObject.IconLocation = $"{iconPath},0";
        }

        shortcutObject.Save();
        return shortcutPath;
    }

    /// <summary>
    /// Copies the customer-supplied logo into the install folder, writes a small branding.json
    /// for the installed app to read, and returns the path to a generated .ico for shortcut icons
    /// (or null if no usable logo was supplied).
    /// </summary>
    private static string? ApplyCustomerBranding(string installFolder, CustomerCustomization customization)
    {
        var brandingFolder = Path.Combine(installFolder, "branding");
        Directory.CreateDirectory(brandingFolder);

        string? logoFileName = null;
        string? iconPath = null;

        if (!string.IsNullOrWhiteSpace(customization.LogoPath) && File.Exists(customization.LogoPath))
        {
            var extension = Path.GetExtension(customization.LogoPath);
            logoFileName = $"logo{extension}";
            var logoDestination = Path.Combine(brandingFolder, logoFileName);
            File.Copy(customization.LogoPath, logoDestination, overwrite: true);

            var generatedIconPath = Path.Combine(brandingFolder, "logo.ico");
            iconPath = TryConvertToIcon(customization.LogoPath, generatedIconPath) ? generatedIconPath : null;
        }

        var brandingInfo = new
        {
            companyName = customization.CompanyName,
            brandColorHex = customization.BrandColorHex,
            logoFileName
        };

        File.WriteAllText(
            Path.Combine(brandingFolder, "branding.json"),
            JsonSerializer.Serialize(brandingInfo, new JsonSerializerOptions { WriteIndented = true }));

        return iconPath;
    }

    /// <summary>
    /// Renders an arbitrary raster image (or copies an existing .ico) into a single-size .ico
    /// suitable for use as a shortcut icon.
    /// </summary>
    private static bool TryConvertToIcon(string sourceImagePath, string destinationIconPath)
    {
        try
        {
            if (Path.GetExtension(sourceImagePath).Equals(".ico", StringComparison.OrdinalIgnoreCase))
            {
                File.Copy(sourceImagePath, destinationIconPath, overwrite: true);
                return true;
            }

            using var original = System.Drawing.Image.FromFile(sourceImagePath);
            using var square = new System.Drawing.Bitmap(256, 256);
            using (var g = System.Drawing.Graphics.FromImage(square))
            {
                g.Clear(System.Drawing.Color.Transparent);
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                var scale = Math.Min(256f / original.Width, 256f / original.Height);
                var width = Math.Max(1, (int)(original.Width * scale));
                var height = Math.Max(1, (int)(original.Height * scale));
                var x = (256 - width) / 2;
                var y = (256 - height) / 2;
                g.DrawImage(original, x, y, width, height);
            }

            var iconHandle = square.GetHicon();
            try
            {
                using var icon = System.Drawing.Icon.FromHandle(iconHandle);
                using var iconStream = File.Create(destinationIconPath);
                icon.Save(iconStream);
            }
            finally
            {
                DestroyIcon(iconHandle);
            }

            return true;
        }
        catch
        {
            // Branding is a nice-to-have; if the supplied file can't be turned into an icon,
            // the install still proceeds with the default shortcut icon.
            return false;
        }
    }

    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern bool DestroyIcon(nint hIcon);

    private static string? CopyUninstallerBootstrapper(string installFolder)
    {
        var source = Path.Combine(AppContext.BaseDirectory, "uninstall.exe");
        if (!File.Exists(source))
        {
            return null;
        }

        var destination = Path.Combine(installFolder, "uninstall.exe");
        File.Copy(source, destination, overwrite: true);
        return destination;
    }

    private static string CopySelfBootstrapper(string installFolder)
    {
        var source = Environment.ProcessPath ?? throw new InvalidOperationException("The current process path could not be determined.");
        if (!File.Exists(source))
        {
            throw new FileNotFoundException("The installer bootstrapper could not be found.", source);
        }

        var destination = Path.Combine(installFolder, Path.GetFileName(source));
        File.Copy(source, destination, overwrite: true);
        return destination;
    }

    private static void WriteUninstallInformation(AsplPackageManifest manifest, string packagePath, string installFolder, string? uninstallerPath)
    {
        if (string.IsNullOrWhiteSpace(uninstallerPath))
        {
            return;
        }

        var keyPath = $@"Software\Microsoft\Windows\CurrentVersion\Uninstall\ASPLShield_{manifest.ProductName}";
        var root = IsAdministrator() ? Registry.LocalMachine : Registry.CurrentUser;
        using var key = root.CreateSubKey(keyPath, writable: true);
        if (key is null)
        {
            return;
        }

        var estimatedSizeKb = GetFolderSizeInKilobytes(installFolder);
        key.SetValue("DisplayName", manifest.ProductName);
        key.SetValue("DisplayVersion", manifest.Version);
        key.SetValue("Publisher", manifest.Publisher);
        key.SetValue("InstallLocation", installFolder);
        key.SetValue("InstallSource", Path.GetDirectoryName(packagePath) ?? installFolder);
        key.SetValue("DisplayIcon", uninstallerPath);
        key.SetValue("URLInfoAbout", string.IsNullOrWhiteSpace(manifest.Publisher) ? manifest.ProductName : manifest.Publisher);
        if (!string.IsNullOrWhiteSpace(IntegrationSettingsLoader.Current.UpdateFeedUri))
        {
            key.SetValue("URLUpdateInfo", IntegrationSettingsLoader.Current.UpdateFeedUri);
        }
        var uninstallArguments = $"--install-folder \"{installFolder}\"";
        key.SetValue("UninstallString", $@"""{uninstallerPath}"" {uninstallArguments}");
        key.SetValue("QuietUninstallString", $@"""{uninstallerPath}"" {uninstallArguments} --quiet");
        key.SetValue("EstimatedSize", estimatedSizeKb);
        key.SetValue("NoModify", 1);
        key.SetValue("NoRepair", 1);
        key.SetValue("SystemComponent", 0);
        key.SetValue("InstallDate", DateTime.UtcNow.ToString("yyyyMMdd"));
    }

    private static bool IsAdministrator()
    {
        using var identity = WindowsIdentity.GetCurrent();
        var principal = new WindowsPrincipal(identity);
        return principal.IsInRole(WindowsBuiltInRole.Administrator);
    }

    private static int GetFolderSizeInKilobytes(string folder)
    {
        if (!Directory.Exists(folder))
        {
            return 0;
        }

        long bytes = 0;
        foreach (var file in Directory.EnumerateFiles(folder, "*", SearchOption.AllDirectories))
        {
            bytes += new FileInfo(file).Length;
        }

        return checked((int)Math.Max(1, Math.Ceiling(bytes / 1024d)));
    }

    private static void RemoveUninstallInformation(string productName, string installFolder)
    {
        var keyPath = $@"Software\Microsoft\Windows\CurrentVersion\Uninstall\ASPLShield_{SanitizeRegistrySegment(productName)}";
        TryDeleteSubKeyTree(Registry.CurrentUser, keyPath);
        TryDeleteSubKeyTree(Registry.LocalMachine, keyPath);
        TryDeleteMatchingSubKey(Registry.CurrentUser, productName, installFolder);
        TryDeleteMatchingSubKey(Registry.LocalMachine, productName, installFolder);
    }

    private static void TryDeleteSubKeyTree(RegistryKey root, string keyPath)
    {
        try
        {
            root.DeleteSubKeyTree(keyPath, throwOnMissingSubKey: false);
        }
        catch
        {
        }
    }

    private static void TryDeleteMatchingSubKey(RegistryKey root, string productName, string installFolder)
    {
        try
        {
            using var uninstallRoot = root.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Uninstall", writable: true);
            if (uninstallRoot is null)
            {
                return;
            }

            foreach (var subKeyName in uninstallRoot.GetSubKeyNames())
            {
                if (!subKeyName.StartsWith("ASPLShield_", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                using var subKey = uninstallRoot.OpenSubKey(subKeyName, writable: true);
                var displayName = subKey?.GetValue("DisplayName") as string;
                var installLocation = subKey?.GetValue("InstallLocation") as string;
                if (!string.Equals(displayName, productName, StringComparison.OrdinalIgnoreCase) &&
                    !string.Equals(installLocation, installFolder, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                uninstallRoot.DeleteSubKeyTree(subKeyName, throwOnMissingSubKey: false);
            }
        }
        catch
        {
        }
    }

    private static void CleanupShortcutFolders(IEnumerable<string> shortcutPaths)
    {
        var desktopRoot = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
        var startMenuProgramsRoot = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Programs");

        foreach (var shortcutPath in shortcutPaths)
        {
            var folder = Path.GetDirectoryName(shortcutPath);
            if (string.IsNullOrWhiteSpace(folder))
            {
                continue;
            }

            if (folder.StartsWith(desktopRoot, StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            if (!folder.StartsWith(startMenuProgramsRoot, StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            DeleteEmptyParents(folder, startMenuProgramsRoot);
        }
    }

    private static void DeleteEmptyParents(string path, string stopAt)
    {
        var current = path;
        while (!string.IsNullOrWhiteSpace(current) &&
               current.StartsWith(stopAt, StringComparison.OrdinalIgnoreCase) &&
               !string.Equals(current, stopAt, StringComparison.OrdinalIgnoreCase))
        {
            try
            {
                if (Directory.Exists(current) && Directory.GetFileSystemEntries(current).Length == 0)
                {
                    Directory.Delete(current, recursive: false);
                }
                else
                {
                    break;
                }
            }
            catch
            {
                return;
            }

            current = Directory.GetParent(current)?.FullName ?? string.Empty;
        }
    }

    private async Task TryCleanupAsync(string stepName, Func<Task> action, CancellationToken cancellationToken)
    {
        try
        {
            await action().ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            await WriteLogAsync("install.log", $"Cleanup step '{stepName}' failed: {ex.Message}", cancellationToken).ConfigureAwait(false);
        }
    }

    private async Task TryDeleteFile(string path)
    {
        try
        {
            if (File.Exists(path))
            {
                ClearReadOnlyAttributes(path);
                File.Delete(path);
            }
        }
        catch (Exception ex)
        {
            await WriteLogAsync("install.log", $"Failed to delete file '{path}': {ex.Message}", CancellationToken.None).ConfigureAwait(false);
        }
    }

    private async Task TryDeleteDirectory(string path)
    {
        try
        {
            if (Directory.Exists(path))
            {
                ClearReadOnlyAttributes(path);
                Directory.Delete(path, recursive: true);
            }
        }
        catch (Exception ex)
        {
            await WriteLogAsync("install.log", $"Failed to delete directory '{path}': {ex.Message}", CancellationToken.None).ConfigureAwait(false);
        }
    }

    private async Task RollbackAsync(AsplPackageManifest manifest, string installFolder, InstallationState state, CancellationToken cancellationToken)
    {
        await WriteLogAsync("install.log", $"Rollback started for '{state.ProductName} {state.ProductVersion}'.", cancellationToken).ConfigureAwait(false);
        await TryCleanupAsync("registry uninstall", () => UninstallRegistryAsync(manifest, cancellationToken), cancellationToken).ConfigureAwait(true);
        await TryCleanupAsync("service uninstall", () => UninstallServicesAsync(manifest, cancellationToken), cancellationToken).ConfigureAwait(true);
        await TryCleanupAsync("iis uninstall", () => _iisInstaller.UninstallAsync(manifest.IisSites.Select(site => new IisSiteEntry
        {
            SiteName = site.SiteName,
            PhysicalPath = site.PhysicalPath,
            ApplicationPoolName = site.ApplicationPoolName,
            CreateApplicationPool = site.CreateApplicationPool,
            StartOnInstall = site.StartOnInstall,
            Bindings = site.Bindings.Select(binding => new IisSiteBindingEntry
            {
                Protocol = binding.Protocol,
                BindingInformation = binding.BindingInformation
            }).ToList()
        }), cancellationToken), cancellationToken).ConfigureAwait(true);

        foreach (var shortcutPath in state.ShortcutPaths)
        {
            await TryDeleteFile(shortcutPath).ConfigureAwait(true);
        }

        await TryDeleteDirectory(installFolder).ConfigureAwait(true);
        RemoveUninstallInformation(state.ProductName, installFolder);
        await WriteLogAsync("install.log", $"Rollback completed for '{state.ProductName} {state.ProductVersion}'.", cancellationToken).ConfigureAwait(false);
    }

    private static Exception UnwrapException(Exception ex)
    {
        var current = ex;
        while (true)
        {
            switch (current)
            {
                case System.Reflection.TargetInvocationException { InnerException: { } inner }:
                    current = inner;
                    continue;
                case AggregateException { InnerException: { } inner } aggregate when aggregate.InnerExceptions.Count <= 1:
                    current = inner;
                    continue;
                default:
                    return current;
            }
        }
    }

    private async Task WriteLogAsync(string logFileName, string message, CancellationToken cancellationToken)
    {
        try
        {
            Directory.CreateDirectory(_logRoot);
            var logPath = Path.Combine(_logRoot, logFileName);
            var line = $"[{DateTime.UtcNow:O}] {message}{Environment.NewLine}";
            await File.AppendAllTextAsync(logPath, line, cancellationToken).ConfigureAwait(false);
        }
        catch
        {
        }
    }

    private static void ClearReadOnlyAttributes(string path)
    {
        if (File.Exists(path))
        {
            var fileAttributes = File.GetAttributes(path);
            if (fileAttributes.HasFlag(FileAttributes.ReadOnly))
            {
                File.SetAttributes(path, fileAttributes & ~FileAttributes.ReadOnly);
            }

            return;
        }

        if (!Directory.Exists(path))
        {
            return;
        }

        foreach (var file in Directory.EnumerateFiles(path, "*", SearchOption.AllDirectories))
        {
            var attributes = File.GetAttributes(file);
            if (attributes.HasFlag(FileAttributes.ReadOnly))
            {
                File.SetAttributes(file, attributes & ~FileAttributes.ReadOnly);
            }
        }
    }

    private static string SanitizeRegistrySegment(string value)
    {
        var invalid = new HashSet<char>(new[] { '\\', '/', ':', '*', '?', '"', '<', '>', '|', '\0' });
        var chars = value.Select(ch => char.IsControl(ch) || invalid.Contains(ch) ? '_' : ch).ToArray();
        var sanitized = new string(chars).Trim();
        return string.IsNullOrWhiteSpace(sanitized) ? "ASPLShield" : sanitized;
    }
}

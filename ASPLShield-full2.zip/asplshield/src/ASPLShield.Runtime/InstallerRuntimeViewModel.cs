using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO.Compression;
using System.Text.Json;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using MediaColor = System.Windows.Media.Color;
using MediaBrush = System.Windows.Media.Brush;
using ASPLShield.Common;
using ASPLShield.Core;
using ASPLShield.PackageEngine;

namespace ASPLShield.Runtime;

public abstract class WizardPageViewModel : ObservableObject
{
}

public sealed class WelcomePageViewModel : WizardPageViewModel
{
    private string _description = "This wizard will install the selected application and create the required shortcuts.";
    private string _productName = string.Empty;
    private string _version = string.Empty;
    private string _publisher = string.Empty;
    private string _installLocation = string.Empty;
    private bool _hasDetails;

    public string Description
    {
        get => _description;
        set => SetProperty(ref _description, value);
    }

    public string ProductName
    {
        get => _productName;
        set => SetProperty(ref _productName, value);
    }

    public string Version
    {
        get => _version;
        set => SetProperty(ref _version, value);
    }

    public string Publisher
    {
        get => _publisher;
        set => SetProperty(ref _publisher, value);
    }

    public string InstallLocation
    {
        get => _installLocation;
        set => SetProperty(ref _installLocation, value);
    }

    public bool HasDetails
    {
        get => _hasDetails;
        set => SetProperty(ref _hasDetails, value);
    }
}

public sealed class LicensePageViewModel : WizardPageViewModel
{
    private bool _isAccepted;
    private string _licenseText = "License terms were supplied by the package manifest.";

    public string LicenseText
    {
        get => _licenseText;
        set => SetProperty(ref _licenseText, value);
    }

    public bool IsAccepted
    {
        get => _isAccepted;
        set => SetProperty(ref _isAccepted, value);
    }
}

public sealed class CustomizationPageViewModel : WizardPageViewModel
{
    private string _companyName = string.Empty;
    private string _logoPath = string.Empty;
    private string _brandColorHex = "#2563EB";
    private System.Windows.Media.Color _brandColor = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#2563EB")!;

    public string CompanyName
    {
        get => _companyName;
        set => SetProperty(ref _companyName, value);
    }

    public string LogoPath
    {
        get => _logoPath;
        set => SetProperty(ref _logoPath, value);
    }

    public string BrandColorHex
    {
        get => _brandColorHex;
        set
        {
            if (SetProperty(ref _brandColorHex, value))
            {
                try
                {
                    var converted = System.Windows.Media.ColorConverter.ConvertFromString(value);
                    if (converted is System.Windows.Media.Color color)
                    {
                        BrandColor = color;
                    }
                }
                catch (FormatException)
                {
                    // Leave the swatch showing the last valid color while the customer keeps typing.
                }
            }
        }
    }

    public System.Windows.Media.Color BrandColor
    {
        get => _brandColor;
        private set => SetProperty(ref _brandColor, value);
    }

    public RelayCommand BrowseLogoCommand { get; set; } = null!;
}

public sealed class FolderPageViewModel : WizardPageViewModel
{
    private string _installFolder = string.Empty;

    public string Description { get; init; } = "Choose the folder where the application files should be installed.";

    public string InstallFolder
    {
        get => _installFolder;
        set => SetProperty(ref _installFolder, value);
    }

    public RelayCommand BrowseCommand { get; set; } = null!;
}

public sealed class ProgressPageViewModel : WizardPageViewModel
{
    private double _progressValue;
    private string _statusText = "Preparing installation...";

    public double ProgressValue
    {
        get => _progressValue;
        set => SetProperty(ref _progressValue, value);
    }

    public string StatusText
    {
        get => _statusText;
        set => SetProperty(ref _statusText, value);
    }
}

public sealed class FinishPageViewModel : WizardPageViewModel
{
    private string _message = string.Empty;

    public string Message
    {
        get => _message;
        set => SetProperty(ref _message, value);
    }
}

public sealed class CustomFieldViewModel : ObservableObject
{
    private string _value;
    private bool _isChecked;

    public CustomFieldViewModel(CustomScreenControl definition)
    {
        Definition = definition;
        _value = definition.DefaultValue;
        _isChecked = string.Equals(definition.DefaultValue, "true", StringComparison.OrdinalIgnoreCase);
        BrowseCommand = new RelayCommand(_ => Browse());
    }

    public CustomScreenControl Definition { get; }
    public string Value { get => _value; set => SetProperty(ref _value, value); }
    public bool IsChecked { get => _isChecked; set => SetProperty(ref _isChecked, value); }
    public RelayCommand BrowseCommand { get; }

    public string AppSettingsValue => Definition.Type == CustomScreenControlType.CheckBox
        ? IsChecked.ToString().ToLowerInvariant()
        : Value;

    private void Browse()
    {
        var dialog = new Microsoft.Win32.OpenFileDialog { Title = Definition.Label, CheckFileExists = false };
        if (dialog.ShowDialog() == true)
        {
            Value = dialog.FileName;
        }
    }
}

public sealed class CustomScreenPageViewModel : WizardPageViewModel
{
    public CustomScreenPageViewModel(CustomScreenDefinition definition)
    {
        Definition = definition;
        Fields = new ObservableCollection<CustomFieldViewModel>(definition.Controls.Select(control => new CustomFieldViewModel(control)));
    }

    public CustomScreenDefinition Definition { get; }
    public ObservableCollection<CustomFieldViewModel> Fields { get; }

    public bool Validate(out string? error)
    {
        var missing = Fields.FirstOrDefault(field => field.Definition.Required &&
            ((field.Definition.Type == CustomScreenControlType.CheckBox && !field.IsChecked) ||
             (field.Definition.Type != CustomScreenControlType.CheckBox && string.IsNullOrWhiteSpace(field.Value))));
        error = missing is null ? null : $"'{missing.Definition.Label}' is required.";
        return missing is null;
    }
}

public sealed class InstallerRuntimeViewModel : ObservableObject
{
    private readonly string[] _args;
    private readonly IPackageEngine _packageEngine;
    private readonly IInstallationService _installationService;
    private readonly WelcomePageViewModel _welcomePage = new();
    private readonly LicensePageViewModel _licensePage = new();
    private readonly CustomizationPageViewModel _customizationPage = new();
    private readonly FolderPageViewModel _folderPage = new();
    private readonly ProgressPageViewModel _progressPage = new();
    private readonly FinishPageViewModel _finishPage = new();
    private readonly List<CustomScreenPageViewModel> _customPages = new();
    private List<WizardPageViewModel> _steps = new();
    private AsplPackageInfo? _packageInfo;
    private object _currentPage;
    private string _headerText = "ASPLShield Setup";
    private string _footerText = "Welcome to the setup wizard.";
    private string _nextButtonText = "Next";
    private int _stepIndex;
    private bool _isBusy;
    private bool _isUninstallMode;
    private string? _installFolder;
    private ImageSource? _bannerImageSource;
    private ImageSource? _welcomeImageSource;
    private ImageSource? _authorWelcomeImageSource;
    private MediaBrush? _authorWelcomeImageBackgroundBrush;
    private MediaBrush _welcomeImageBackgroundBrush = LookupThemeBrush("CardBrush");

    public InstallerRuntimeViewModel(string[] args, IPackageEngine packageEngine, IInstallationService installationService)
    {
        _args = args;
        _packageEngine = packageEngine;
        _installationService = installationService;
        _currentPage = _welcomePage;
        _folderPage.BrowseCommand = new RelayCommand(_ => BrowseForInstallFolder());
        _customizationPage.BrowseLogoCommand = new RelayCommand(_ => BrowseForLogo());

        // Live-preview the customer's own brand color choice on the wizard chrome (buttons,
        // progress bar) as they type or pick it, instead of only using the author's fixed accent.
        _customizationPage.PropertyChanged += (_, e) =>
        {
            if (e.PropertyName == nameof(CustomizationPageViewModel.BrandColorHex))
            {
                ApplyAccentColor(_customizationPage.BrandColorHex);
            }
        };

        // The Welcome page renders before Customization, so it can only ever show the author's
        // fixed logo. The Finish page renders after, so once the customer has picked (or cleared)
        // their own logo, preview it there instead — since it shares the same image slot as Welcome.
        _customizationPage.PropertyChanged += async (_, e) =>
        {
            if (e.PropertyName == nameof(CustomizationPageViewModel.LogoPath))
            {
                await PreviewCustomerLogoAsync().ConfigureAwait(true);
            }
        };

        BackCommand = new RelayCommand(_ => GoBack(), _ => !_isBusy && !_isUninstallMode && _stepIndex > 0 && _stepIndex < _steps.Count);
        NextCommand = new AsyncRelayCommand(_ => GoNextAsync(), _ => !_isBusy);
        CancelCommand = new RelayCommand(_ => System.Windows.Application.Current.Shutdown());
    }

    public object CurrentPage
    {
        get => _currentPage;
        private set => SetProperty(ref _currentPage, value);
    }

    public string HeaderText
    {
        get => _headerText;
        private set => SetProperty(ref _headerText, value);
    }

    public string FooterText
    {
        get => _footerText;
        private set => SetProperty(ref _footerText, value);
    }

    public string NextButtonText
    {
        get => _nextButtonText;
        private set => SetProperty(ref _nextButtonText, value);
    }

    public RelayCommand BackCommand { get; }

    public AsyncRelayCommand NextCommand { get; }

    public RelayCommand CancelCommand { get; }

    /// <summary>
    /// Author-supplied banner image (shown across the top of every page except Welcome/Finish),
    /// loaded from the package's "branding-banner.png" entry, or null if the author didn't set one.
    /// </summary>
    public ImageSource? BannerImageSource
    {
        get => _bannerImageSource;
        private set
        {
            if (SetProperty(ref _bannerImageSource, value))
            {
                OnPropertyChanged(nameof(HasBannerImage));
            }
        }
    }

    public bool HasBannerImage => _bannerImageSource is not null;

    /// <summary>
    /// Author-supplied full-height image (shown on the Welcome and Finish pages), loaded from the
    /// package's "branding-welcome.png" entry, or null if the author didn't set one.
    /// </summary>
    public ImageSource? WelcomeImageSource
    {
        get => _welcomeImageSource;
        private set
        {
            if (SetProperty(ref _welcomeImageSource, value))
            {
                OnPropertyChanged(nameof(HasWelcomeImage));
            }
        }
    }

    public bool HasWelcomeImage => _welcomeImageSource is not null;

    /// <summary>
    /// Fill color shown behind the Welcome/Finish image when it doesn't exactly cover its frame.
    /// Defaults to the Runtime's theme card color, or the author's
    /// <see cref="AsplPackageManifest.BrandingWelcomeBackgroundColorHex"/> if they set one — set
    /// this to match your logo's own background so it blends in seamlessly.
    /// </summary>
    public MediaBrush WelcomeImageBackgroundBrush
    {
        get => _welcomeImageBackgroundBrush;
        private set => SetProperty(ref _welcomeImageBackgroundBrush, value);
    }

    public async Task InitializeAsync()
    {
        _isUninstallMode = HasSwitch(_args, "--uninstall");
        if (_isUninstallMode)
        {
            _installFolder = LocateInstallFolder(_args);
            if (string.IsNullOrWhiteSpace(_installFolder))
            {
                _finishPage.Message = "Unable to locate an installed product to uninstall.";
                _currentPage = _finishPage;
                HeaderText = "Finish";
                FooterText = _finishPage.Message;
                NextButtonText = "Finish";
                _stepIndex = 3;
                OnPropertyChanged(nameof(CurrentPage));
                UpdateNavigation();
                return;
            }

            _currentPage = _progressPage;
            _headerText = "Uninstalling";
            _footerText = $"Removing installation from {_installFolder}.";
            _nextButtonText = "Finish";
            _stepIndex = 2;
            OnPropertyChanged(nameof(CurrentPage));
            OnPropertyChanged(nameof(HeaderText));
            OnPropertyChanged(nameof(FooterText));
            OnPropertyChanged(nameof(NextButtonText));
            UpdateNavigation();
            await RunUninstallAsync().ConfigureAwait(true);
            return;
        }

        var packagePath = LocatePackagePath(_args);
        if (packagePath is null)
        {
            _finishPage.Message = $"No .asplpkg package was found next to {Path.GetFileName(Environment.ProcessPath) ?? "the installer"}. Keep the setup .exe and the .asplpkg file together in the same folder.";
            _currentPage = _finishPage;
            FooterText = _finishPage.Message;
            NextButtonText = "Finish";
            _stepIndex = 4;
            OnPropertyChanged(nameof(CurrentPage));
            return;
        }

        _packageInfo = await _packageEngine.ReadPackageAsync(packagePath).ConfigureAwait(true);
        await ApplyBrandingAsync(packagePath, _packageInfo.Manifest).ConfigureAwait(true);
        var resolvedInstallFolder = ResolveInstallFolder(_packageInfo.Manifest.InstallPath, _packageInfo.Manifest.ProductName);
        _welcomePage.Description = $"This wizard will install {_packageInfo.Manifest.ProductName} {_packageInfo.Manifest.Version} and create the required shortcuts.";
        _welcomePage.ProductName = _packageInfo.Manifest.ProductName;
        _welcomePage.Version = _packageInfo.Manifest.Version;
        _welcomePage.Publisher = _packageInfo.Manifest.Publisher;
        _welcomePage.InstallLocation = resolvedInstallFolder;
        _welcomePage.HasDetails = !string.IsNullOrWhiteSpace(_packageInfo.Manifest.ProductName);
        _licensePage.LicenseText = await ReadEmbeddedTextAsync(packagePath, "license.txt").ConfigureAwait(true)
            ?? _licensePage.LicenseText;
        _folderPage.InstallFolder = resolvedInstallFolder;
        _footerText = $"Ready to install {_packageInfo.Manifest.ProductName} {_packageInfo.Manifest.Version}.";
        OnPropertyChanged(nameof(FooterText));

        _steps = new List<WizardPageViewModel> { _welcomePage, _licensePage };
        if (_packageInfo.Manifest.AllowCustomerCustomization)
        {
            // Seed the customer customization page with the author's defaults (set on the
            // Studio Customization tab) rather than the built-in placeholders. The customer can
            // still change any of these before installing.
            _customizationPage.CompanyName = string.IsNullOrWhiteSpace(_packageInfo.Manifest.DefaultCustomerCompanyName)
                ? _packageInfo.Manifest.Publisher
                : _packageInfo.Manifest.DefaultCustomerCompanyName;

            if (!string.IsNullOrWhiteSpace(_packageInfo.Manifest.DefaultCustomerBrandColorHex))
            {
                _customizationPage.BrandColorHex = _packageInfo.Manifest.DefaultCustomerBrandColorHex;
            }

            if (_packageInfo.Manifest.HasCustomerDefaultLogo)
            {
                var extractedLogoPath = await ExtractEmbeddedFileAsync(packagePath, "customer-default-logo.png", "customer-default-logo.png").ConfigureAwait(true);
                if (extractedLogoPath is not null)
                {
                    _customizationPage.LogoPath = extractedLogoPath;
                }
            }

            _steps.Add(_customizationPage);
        }
        else
        {
            _customizationPage.CompanyName = _packageInfo.Manifest.Publisher;
        }

        _customPages.Clear();
        foreach (var definition in _packageInfo.Manifest.CustomScreens)
        {
            var page = new CustomScreenPageViewModel(definition);
            _customPages.Add(page);
            _steps.Add(page);
        }

        _steps.Add(_folderPage);
        _steps.Add(_progressPage);
        _steps.Add(_finishPage);
        _stepIndex = 0;
    }

    private async Task GoNextAsync()
    {
        if (_currentPage is FinishPageViewModel)
        {
            System.Windows.Application.Current.Shutdown();
            return;
        }

        if (_packageInfo is null || _steps.Count == 0)
        {
            return;
        }

        switch (_steps[_stepIndex])
        {
            case WelcomePageViewModel:
                AdvanceTo(_stepIndex + 1);
                HeaderText = "License Agreement";
                FooterText = "Review and accept the license agreement to continue.";
                break;

            case LicensePageViewModel:
                if (!_licensePage.IsAccepted)
                {
                    System.Windows.MessageBox.Show("You must accept the license agreement to continue.", "ASPLShield Setup", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                AdvanceTo(_stepIndex + 1);
                if (_steps[_stepIndex] is CustomizationPageViewModel)
                {
                    HeaderText = "Customize Your Installation";
                    FooterText = "Personalize this install with your logo, company name, and brand color, or leave blank to skip.";
                }
                else
                {
                    SetHeaderForCurrentPage();
                }

                break;

            case CustomizationPageViewModel:
                AdvanceTo(_stepIndex + 1);
                SetHeaderForCurrentPage();
                break;

            case CustomScreenPageViewModel customPage:
                if (!customPage.Validate(out var validationError))
                {
                    System.Windows.MessageBox.Show(validationError, "ASPLShield Setup", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                AdvanceTo(_stepIndex + 1);
                SetHeaderForCurrentPage();
                break;

            case FolderPageViewModel:
                AdvanceTo(_stepIndex + 1);
                HeaderText = "Installing";
                NextButtonText = "Install";
                await RunInstallationAsync().ConfigureAwait(true);
                break;

            case ProgressPageViewModel:
                System.Windows.Application.Current.Shutdown();
                break;

            default:
                break;
        }

        UpdateNavigation();
    }

    private void AdvanceTo(int stepIndex)
    {
        _stepIndex = stepIndex;
        CurrentPage = _steps[_stepIndex];
    }

    private void GoBack()
    {
        if (_stepIndex <= 0 || _stepIndex >= _steps.Count)
        {
            return;
        }

        _stepIndex--;
        CurrentPage = _steps[_stepIndex];

        (HeaderText, FooterText) = _steps[_stepIndex] switch
        {
            WelcomePageViewModel => ("Welcome", "Welcome to the setup wizard."),
            LicensePageViewModel => ("License Agreement", "Review and accept the license agreement to continue."),
            CustomizationPageViewModel => ("Customize Your Installation", "Personalize this install with your logo, company name, and brand color, or leave blank to skip."),
            CustomScreenPageViewModel custom => (custom.Definition.Title, custom.Definition.Description),
            FolderPageViewModel => ("Installation Folder", "Choose where the application should be installed."),
            _ => (HeaderText, FooterText)
        };

        UpdateNavigation();
    }

    private void SetHeaderForCurrentPage()
    {
        (HeaderText, FooterText) = _steps[_stepIndex] switch
        {
            CustomScreenPageViewModel custom => (custom.Definition.Title, custom.Definition.Description),
            FolderPageViewModel => ("Installation Folder", "Choose where the application should be installed."),
            ProgressPageViewModel => ("Installing", "The application is being installed."),
            FinishPageViewModel => ("Finish", "Installation completed."),
            _ => (HeaderText, FooterText)
        };
    }

    private static string GetRootCauseMessage(Exception ex)
    {
        var current = ex;
        while (true)
        {
            switch (current)
            {
                case System.Reflection.TargetInvocationException { InnerException: { } inner }:
                    current = inner;
                    continue;
                case AggregateException { InnerException: { } inner } aggregate when aggregate.InnerExceptions.Count <= 1:
                    current = inner;
                    continue;
                default:
                    if (!string.IsNullOrWhiteSpace(current.Message))
                    {
                        return current.Message;
                    }

                    return $"{current.GetType().Name} (HRESULT 0x{current.HResult:X8})";
            }
        }
    }

    private async Task RunInstallationAsync()
    {
        if (_packageInfo is null)
        {
            return;
        }

        _isBusy = true;
        UpdateNavigation();
        try
        {
            var customization = BuildCustomization();
            var state = await _installationService.InstallAsync(_packageInfo, _folderPage.InstallFolder, new Progress<InstallationProgress>(progress =>
            {
                _progressPage.ProgressValue = progress.Percent;
                _progressPage.StatusText = progress.Message;
                FooterText = progress.Message;
            }), customization).ConfigureAwait(true);

            _finishPage.Message = $"Installed {_packageInfo.Manifest.ProductName} to {state.InstallFolder}.";
            CurrentPage = _finishPage;
            HeaderText = "Finish";
            NextButtonText = "Finish";
            FooterText = "Setup completed successfully.";
            _stepIndex = _steps.IndexOf(_finishPage);
        }
        catch (Exception ex)
        {
            _finishPage.Message = $"Installation failed: {GetRootCauseMessage(ex)}";
            CurrentPage = _finishPage;
            HeaderText = "Finish";
            NextButtonText = "Finish";
            FooterText = "The installer rolled back the changes.";
            _stepIndex = _steps.IndexOf(_finishPage);
        }
        finally
        {
            _isBusy = false;
            UpdateNavigation();
        }
    }

    private CustomerCustomization? BuildCustomization()
    {
        if (_packageInfo is null)
        {
            return null;
        }

        var hasCompanyName = !string.IsNullOrWhiteSpace(_customizationPage.CompanyName);
        var hasLogo = !string.IsNullOrWhiteSpace(_customizationPage.LogoPath) && File.Exists(_customizationPage.LogoPath);
        var hasColor = !string.IsNullOrWhiteSpace(_customizationPage.BrandColorHex);

        var appSettingsValues = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var field in _customPages.SelectMany(page => page.Fields))
        {
            if (!string.IsNullOrWhiteSpace(field.Definition.AppSettingsKey))
                appSettingsValues[field.Definition.AppSettingsKey] = field.AppSettingsValue;
        }

        if (!_packageInfo.Manifest.AllowCustomerCustomization && appSettingsValues.Count == 0)
        {
            return null;
        }

        if (!hasCompanyName && !hasLogo && !hasColor && appSettingsValues.Count == 0)
        {
            return null;
        }

        var customization = new CustomerCustomization
        {
            CompanyName = hasCompanyName ? _customizationPage.CompanyName : null,
            LogoPath = hasLogo ? _customizationPage.LogoPath : null,
            BrandColorHex = hasColor ? _customizationPage.BrandColorHex : null
        };
        foreach (var pair in appSettingsValues)
            customization.AppSettingsValues[pair.Key] = pair.Value;
        return customization;
    }

    private async Task RunUninstallAsync()
    {
        if (string.IsNullOrWhiteSpace(_installFolder))
        {
            return;
        }

        if (IsRunningInsideFolder(_installFolder))
        {
            RelaunchFromTempAndExit();
            return;
        }

        _isBusy = true;
        UpdateNavigation();
        try
        {
            _progressPage.ProgressValue = 0;
            _progressPage.StatusText = $"Removing installation from {_installFolder}...";
            FooterText = _progressPage.StatusText;
            await _installationService.UninstallAsync(_installFolder).ConfigureAwait(true);

            _finishPage.Message = $"Removed installation from {_installFolder}.";
            CurrentPage = _finishPage;
            HeaderText = "Finish";
            FooterText = "Uninstallation completed successfully.";
            _stepIndex = 3;
        }
        catch (Exception ex)
        {
            _finishPage.Message = $"Uninstallation failed: {GetRootCauseMessage(ex)}";
            CurrentPage = _finishPage;
            HeaderText = "Finish";
            FooterText = "The uninstaller rolled back as much as possible.";
            _stepIndex = 3;
        }
        finally
        {
            _isBusy = false;
            UpdateNavigation();
        }
    }

    private void BrowseForLogo()
    {
        var dialog = new Microsoft.Win32.OpenFileDialog
        {
            Title = "Select Company Logo",
            Filter = "Image files (*.png;*.jpg;*.jpeg;*.bmp;*.ico)|*.png;*.jpg;*.jpeg;*.bmp;*.ico|All files (*.*)|*.*"
        };

        if (dialog.ShowDialog() == true)
        {
            _customizationPage.LogoPath = dialog.FileName;
        }
    }

    /// <summary>
    /// Previews the customer's chosen logo in the shared Welcome/Finish image slot. Since the
    /// Welcome page has already been shown by the time this fires, the practical effect is that
    /// the Finish page reflects the customer's own branding instead of the author's fixed one —
    /// falling back to the author's original image if the customer clears their selection or the
    /// file fails to load (e.g. an unsupported format).
    /// </summary>
    private async Task PreviewCustomerLogoAsync()
    {
        try
        {
            if (!string.IsNullOrWhiteSpace(_customizationPage.LogoPath) && File.Exists(_customizationPage.LogoPath))
            {
                var customerImage = await LoadImageFromFileAsync(_customizationPage.LogoPath).ConfigureAwait(true);
                if (customerImage is not null)
                {
                    WelcomeImageSource = customerImage;
                    WelcomeImageBackgroundBrush = customerImage is BitmapSource sampled && SampleCornerBackgroundColor(sampled) is { } color
                        ? ToFrozenBrush(color)
                        : _authorWelcomeImageBackgroundBrush ?? WelcomeImageBackgroundBrush;
                    return;
                }
            }
        }
        catch (Exception)
        {
            // Best-effort preview only; a bad logo file should never break the wizard — fall through to the author default below.
        }

        WelcomeImageSource = _authorWelcomeImageSource;
        if (_authorWelcomeImageBackgroundBrush is not null)
        {
            WelcomeImageBackgroundBrush = _authorWelcomeImageBackgroundBrush;
        }
    }

    private static async Task<ImageSource?> LoadImageFromFileAsync(string filePath)
    {
        try
        {
            await using var fileStream = File.OpenRead(filePath);
            using var memory = new MemoryStream();
            await fileStream.CopyToAsync(memory).ConfigureAwait(false);
            memory.Position = 0;

            var image = new BitmapImage();
            image.BeginInit();
            image.CacheOption = BitmapCacheOption.OnLoad;
            image.StreamSource = memory;
            image.EndInit();
            image.Freeze();
            return image;
        }
        catch (NotSupportedException)
        {
            return null;
        }
        catch (IOException)
        {
            return null;
        }
    }

    private void BrowseForInstallFolder()
    {
        using var dialog = new System.Windows.Forms.FolderBrowserDialog
        {
            Description = "Select the installation folder",
            SelectedPath = _folderPage.InstallFolder
        };

        if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
        {
            _folderPage.InstallFolder = dialog.SelectedPath;
        }
    }

    private void UpdateNavigation()
    {
        BackCommand.RaiseCanExecuteChanged();
        NextCommand.RaiseCanExecuteChanged();
    }

    /// <summary>
    /// Loads the author's banner/Welcome-page branding images (if present) and, if the author set
    /// a <see cref="AsplPackageManifest.BrandingAccentColorHex"/>, recolors the wizard chrome by
    /// overriding the app-level theme brushes — the same mechanism ASPLShield.Studio uses for its
    /// own theme switcher.
    /// </summary>
    private async Task ApplyBrandingAsync(string packagePath, AsplPackageManifest manifest)
    {
        if (manifest.HasBrandingBanner)
        {
            BannerImageSource = await ReadEmbeddedImageAsync(packagePath, "branding-banner.png").ConfigureAwait(true);
        }

        if (manifest.HasBrandingWelcomeImage)
        {
            WelcomeImageSource = await ReadEmbeddedImageAsync(packagePath, "branding-welcome.png").ConfigureAwait(true);
            _authorWelcomeImageSource = WelcomeImageSource;

            // Auto-detect the panel background from the logo's own artwork so it blends in
            // seamlessly without requiring the package author to pick a matching color by hand.
            if (WelcomeImageSource is BitmapSource sampledSource)
            {
                var detectedColor = SampleCornerBackgroundColor(sampledSource);
                if (detectedColor is { } color)
                {
                    WelcomeImageBackgroundBrush = ToFrozenBrush(color);
                    _authorWelcomeImageBackgroundBrush = WelcomeImageBackgroundBrush;
                }
            }
        }

        if (!string.IsNullOrWhiteSpace(manifest.BrandingAccentColorHex))
        {
            ApplyAccentColor(manifest.BrandingAccentColorHex);
        }

        // An explicit author-supplied color (from older packages) still wins over auto-detection.
        if (!string.IsNullOrWhiteSpace(manifest.BrandingWelcomeBackgroundColorHex))
        {
            var brush = TryParseBrush(manifest.BrandingWelcomeBackgroundColorHex);
            if (brush is not null)
            {
                WelcomeImageBackgroundBrush = brush;
                _authorWelcomeImageBackgroundBrush = brush;
            }
        }
    }

    /// <summary>
    /// Samples a band of pixels around the outer edge of the logo image and returns the color
    /// that appears most often among them, so the panel fill matches the image's real background
    /// tone instead of whatever a single corner pixel happens to be (anti-aliasing, a stray
    /// gradient, or compression noise near one exact corner can make one pixel an unreliable
    /// stand-in for the artwork's actual background). Logo artwork is usually inset from the
    /// edges, so the solid background fill wins the vote — giving a close auto-detected match
    /// without asking the package author to type in a hex code. Colors are quantized slightly
    /// before voting so near-identical shades (e.g. off-by-one antialiasing) count together
    /// instead of splitting the vote.
    /// </summary>
    private static MediaColor? SampleCornerBackgroundColor(BitmapSource source)
    {
        try
        {
            var converted = new FormatConvertedBitmap(source, PixelFormats.Bgra32, null, 0);
            var width = converted.PixelWidth;
            var height = converted.PixelHeight;
            if (width < 2 || height < 2)
            {
                return null;
            }

            // Sample every pixel along a thin border strip around the whole perimeter, not just
            // the four literal corners, so a single noisy pixel can't skew the result.
            var samples = new List<MediaColor>();
            var borderThickness = Math.Max(1, Math.Min(width, height) / 20);
            var step = Math.Max(1, Math.Min(width, height) / 100);

            for (var x = 0; x < width; x += step)
            {
                for (var t = 0; t < borderThickness; t++)
                {
                    samples.Add(ReadPixel(converted, x, t));
                    samples.Add(ReadPixel(converted, x, height - 1 - t));
                }
            }

            for (var y = 0; y < height; y += step)
            {
                for (var t = 0; t < borderThickness; t++)
                {
                    samples.Add(ReadPixel(converted, t, y));
                    samples.Add(ReadPixel(converted, width - 1 - t, y));
                }
            }

            // Quantize to buckets of 8 per channel so near-identical shades vote together.
            var best = samples
                .Where(c => c.A > 0)
                .GroupBy(c => (c.R / 8, c.G / 8, c.B / 8))
                .OrderByDescending(group => group.Count())
                .Select(group => group.OrderBy(c => Math.Abs(c.R - group.Key.Item1 * 8 - 4)
                                                     + Math.Abs(c.G - group.Key.Item2 * 8 - 4)
                                                     + Math.Abs(c.B - group.Key.Item3 * 8 - 4)).First())
                .FirstOrDefault();

            // If every sampled pixel was fully transparent, fall back to white rather than
            // tinting the panel with an invisible color.
            return best == default ? MediaColor.FromRgb(255, 255, 255) : best;
        }
        catch (Exception ex) when (ex is NotSupportedException or ArgumentException)
        {
            return null;
        }
    }

    private static MediaColor ReadPixel(BitmapSource source, int x, int y)
    {
        var pixel = new byte[4];
        source.CopyPixels(new Int32Rect(x, y, 1, 1), pixel, 4, 0);

        // Bgra32 byte order is B, G, R, A.
        return MediaColor.FromArgb(pixel[3], pixel[2], pixel[1], pixel[0]);
    }

    private static MediaBrush? TryParseBrush(string colorHex)
    {
        try
        {
            var converted = System.Windows.Media.ColorConverter.ConvertFromString(colorHex);
            if (converted is MediaColor color)
            {
                return ToFrozenBrush(color);
            }
        }
        catch (FormatException)
        {
            // Invalid color supplied by the author — caller keeps whatever brush it already has.
        }

        return null;
    }

    /// <summary>
    /// Extracts an embedded package entry to a temp file so it can be used as a plain file path
    /// (e.g. the customization page's LogoPath, which the customer can Browse to replace).
    /// </summary>
    private static async Task<string?> ExtractEmbeddedFileAsync(string packagePath, string entryName, string extractedFileName)
    {
        if (!File.Exists(packagePath))
        {
            return null;
        }

        await using var stream = File.OpenRead(packagePath);
        using var archive = new ZipArchive(stream, ZipArchiveMode.Read, leaveOpen: false);
        var entry = archive.GetEntry(entryName);
        if (entry is null)
        {
            return null;
        }

        var extractDir = Path.Combine(Path.GetTempPath(), "ASPLShieldSetup");
        Directory.CreateDirectory(extractDir);
        var destinationPath = Path.Combine(extractDir, extractedFileName);

        await using var entryStream = entry.Open();
        await using var fileStream = File.Create(destinationPath);
        await entryStream.CopyToAsync(fileStream).ConfigureAwait(false);

        return destinationPath;
    }

    private static MediaBrush LookupThemeBrush(string resourceKey)
    {
        var resource = System.Windows.Application.Current?.TryFindResource(resourceKey);
        if (resource is MediaBrush brush)
        {
            return brush;
        }

        return System.Windows.Media.Brushes.White;
    }

    private static async Task<ImageSource?> ReadEmbeddedImageAsync(string packagePath, string entryName)
    {
        if (!File.Exists(packagePath))
        {
            return null;
        }

        await using var stream = File.OpenRead(packagePath);
        using var archive = new ZipArchive(stream, ZipArchiveMode.Read, leaveOpen: false);
        var entry = archive.GetEntry(entryName);
        if (entry is null)
        {
            return null;
        }

        await using var entryStream = entry.Open();
        using var memory = new MemoryStream();
        await entryStream.CopyToAsync(memory).ConfigureAwait(false);
        memory.Position = 0;

        try
        {
            var image = new BitmapImage();
            image.BeginInit();
            image.CacheOption = BitmapCacheOption.OnLoad;
            image.StreamSource = memory;
            image.EndInit();
            image.Freeze();
            return image;
        }
        catch (NotSupportedException)
        {
            // The embedded file wasn't a decodable image format — fall back to no image
            // rather than crashing the wizard over a bad branding asset.
            return null;
        }
    }

    /// <summary>
    /// Recolors the wizard's accent brushes (badge, buttons, progress bar) to the author's
    /// requested color by overriding the same DynamicResource keys defined in App.xaml, deriving
    /// soft/border/hover/pressed tints from the single base color.
    /// </summary>
    private static void ApplyAccentColor(string accentColorHex)
    {
        MediaColor baseColor;
        try
        {
            var converted = System.Windows.Media.ColorConverter.ConvertFromString(accentColorHex);
            if (converted is not MediaColor color)
            {
                return;
            }

            baseColor = color;
        }
        catch (FormatException)
        {
            // Invalid color supplied by the author — keep the default theme accent.
            return;
        }

        var resources = System.Windows.Application.Current?.Resources;
        if (resources is null)
        {
            return;
        }

        // Button/card surfaces in this theme are white, so a near-white accent (including plain
        // white itself) would otherwise render as invisible text and borders. Text/border/progress
        // elements use a contrast-safe variant; soft fills (which sit behind readable text, not
        // as text themselves) keep the true author/customer color.
        var readableColor = EnsureReadableOnLightSurface(baseColor);

        resources["AccentBrush"] = ToFrozenBrush(readableColor);
        resources["ProgressBrush"] = ToFrozenBrush(readableColor);
        resources["ButtonForegroundBrush"] = ToFrozenBrush(readableColor);
        resources["AccentSoftBrush"] = ToFrozenBrush(Lighten(baseColor, 0.85));
        resources["ButtonHoverBrush"] = ToFrozenBrush(Lighten(baseColor, 0.85));
        resources["ButtonPressedBrush"] = ToFrozenBrush(Lighten(baseColor, 0.65));
        resources["AccentBorderBrush"] = ToFrozenBrush(Lighten(readableColor, 0.5));
        resources["ButtonBorderBrush"] = ToFrozenBrush(Lighten(readableColor, 0.5));
    }

    /// <summary>
    /// Returns a color guaranteed to be visible as text/a border against this theme's white
    /// button and card backgrounds. Colors that are already dark enough pass through unchanged;
    /// near-white/pale colors (including pure white) are darkened toward their own hue so the
    /// wizard chrome still reads as "using the chosen color" rather than falling back to gray.
    /// </summary>
    private static MediaColor EnsureReadableOnLightSurface(MediaColor color)
    {
        var luminance = ((0.299 * color.R) + (0.587 * color.G) + (0.114 * color.B)) / 255.0;
        const double LuminanceThreshold = 0.75;
        if (luminance < LuminanceThreshold)
        {
            return color;
        }

        var severity = Math.Min(1.0, (luminance - LuminanceThreshold) / (1.0 - LuminanceThreshold));
        var darkenAmount = Math.Clamp(0.35 + (severity * 0.30), 0.35, 0.65);
        return Darken(color, darkenAmount);
    }

    private static MediaColor Lighten(MediaColor color, double amount)
    {
        // Blend toward white by `amount` (0 = unchanged, 1 = white).
        byte Blend(byte channel) => (byte)Math.Round(channel + ((255 - channel) * amount));
        return MediaColor.FromRgb(Blend(color.R), Blend(color.G), Blend(color.B));
    }

    private static MediaColor Darken(MediaColor color, double amount)
    {
        // Blend toward black by `amount` (0 = unchanged, 1 = black).
        byte Blend(byte channel) => (byte)Math.Round(channel * (1 - amount));
        return MediaColor.FromRgb(Blend(color.R), Blend(color.G), Blend(color.B));
    }

    private static SolidColorBrush ToFrozenBrush(MediaColor color)
    {
        var brush = new SolidColorBrush(color);
        brush.Freeze();
        return brush;
    }

    private static string? LocatePackagePath(IEnumerable<string> args)
        => InstalledProductLocator.ResolvePackagePath(args, AppContext.BaseDirectory);

    private static bool HasSwitch(IEnumerable<string> args, string switchName)
        => args.Any(arg => arg.Equals(switchName, StringComparison.OrdinalIgnoreCase));

    private static string? LocateInstallFolder(IEnumerable<string> args)
        => InstalledProductLocator.ResolveInstallFolder(args, AppContext.BaseDirectory);

    private static async Task<string?> ReadEmbeddedTextAsync(string packagePath, string entryName)
    {
        if (!File.Exists(packagePath))
        {
            return null;
        }

        await using var stream = File.OpenRead(packagePath);
        using var archive = new ZipArchive(stream, ZipArchiveMode.Read, leaveOpen: false);
        var entry = archive.GetEntry(entryName);
        if (entry is null)
        {
            return null;
        }

        await using var entryStream = entry.Open();
        using var reader = new StreamReader(entryStream);
        return await reader.ReadToEndAsync().ConfigureAwait(true);
    }

    private static string ResolveInstallFolder(string installPath, string productName)
    {
        var programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
        var resolved = installPath.Replace("[ProgramFiles]", programFiles, StringComparison.OrdinalIgnoreCase);
        return string.IsNullOrWhiteSpace(resolved) ? Path.Combine(programFiles, productName) : resolved;
    }

    private static bool IsRunningInsideFolder(string folder)
    {
        var processPath = Environment.ProcessPath;
        return !string.IsNullOrWhiteSpace(processPath) &&
               Path.GetFullPath(processPath).StartsWith(Path.GetFullPath(folder), StringComparison.OrdinalIgnoreCase);
    }

    private void RelaunchFromTempAndExit()
    {
        var currentProcessPath = Environment.ProcessPath ?? throw new InvalidOperationException("The current process path could not be determined.");
        var tempPath = Path.Combine(Path.GetTempPath(), $"{Guid.NewGuid():N}.exe");
        File.Copy(currentProcessPath, tempPath, overwrite: true);

        var psi = new ProcessStartInfo
        {
            FileName = tempPath,
            Arguments = string.Join(" ", _args.Select(QuoteArgument)),
            UseShellExecute = false,
            WorkingDirectory = Path.GetDirectoryName(tempPath) ?? Path.GetTempPath()
        };

        Process.Start(psi);
        System.Windows.Application.Current.Shutdown();
    }

    private static string QuoteArgument(string value)
        => value.Any(char.IsWhiteSpace) ? $"\"{value.Replace("\"", "\\\"", StringComparison.Ordinal)}\"" : value;
}

public sealed class InstallationProgress
{
    public double Percent { get; init; }

    public string Message { get; init; } = string.Empty;
}

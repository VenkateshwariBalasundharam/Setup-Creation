using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace ASPLShield.Runtime;

/// <summary>
/// Shows the author's banner image row on every wizard page except Welcome and Finish
/// (those pages show the full-height <see cref="InstallerRuntimeViewModel.WelcomeImageSource"/>
/// instead), and only when a banner image was actually supplied.
/// </summary>
public sealed class BannerVisibilityConverter : IMultiValueConverter
{
    public object Convert(object[] values, Type targetType, object? parameter, CultureInfo culture)
    {
        if (values.Length < 2 || values[0] is not bool hasBannerImage)
        {
            return Visibility.Collapsed;
        }

        var currentPage = values[1];
        var isWelcomeOrFinishPage = currentPage is WelcomePageViewModel || currentPage is FinishPageViewModel;

        return hasBannerImage && !isWelcomeOrFinishPage ? Visibility.Visible : Visibility.Collapsed;
    }

    public object[] ConvertBack(object value, Type[] targetTypes, object? parameter, CultureInfo culture)
        => throw new NotSupportedException();
}

/// <summary>
/// Shows the author's full-height Welcome/Finish image only on the Welcome and Finish pages,
/// and only when one was actually supplied.
/// </summary>
public sealed class WelcomeImageVisibilityConverter : IMultiValueConverter
{
    public object Convert(object[] values, Type targetType, object? parameter, CultureInfo culture)
    {
        if (values.Length < 2 || values[0] is not bool hasWelcomeImage)
        {
            return Visibility.Collapsed;
        }

        var currentPage = values[1];
        var isWelcomeOrFinishPage = currentPage is WelcomePageViewModel || currentPage is FinishPageViewModel;

        return hasWelcomeImage && isWelcomeOrFinishPage ? Visibility.Visible : Visibility.Collapsed;
    }

    public object[] ConvertBack(object value, Type[] targetTypes, object? parameter, CultureInfo culture)
        => throw new NotSupportedException();
}

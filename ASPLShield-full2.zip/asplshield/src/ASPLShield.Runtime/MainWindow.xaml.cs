using System.Windows;

namespace ASPLShield.Runtime;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    private void LicenseAccepted_Checked(object sender, RoutedEventArgs e)
    {
        if (DataContext is InstallerRuntimeViewModel vm &&
            vm.CurrentPage is LicensePageViewModel page)
        {
            page.IsAccepted = true;
        }
    }

    private void LicenseRejected_Checked(object sender, RoutedEventArgs e)
    {
        if (DataContext is InstallerRuntimeViewModel vm &&
            vm.CurrentPage is LicensePageViewModel page)
        {
            page.IsAccepted = false;
        }
    }
}
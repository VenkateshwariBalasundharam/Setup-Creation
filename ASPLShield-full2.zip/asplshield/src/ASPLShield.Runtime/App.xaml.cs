using System.Windows;
using ASPLShield.PackageEngine;

namespace ASPLShield.Runtime;

public partial class App : System.Windows.Application
{
    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        var window = new MainWindow();
        var viewModel = new InstallerRuntimeViewModel(e.Args, new AsplPackageEngine(), new InstallationService());
        window.DataContext = viewModel;
        MainWindow = window;
        window.Show();

        try
        {
            await viewModel.InitializeAsync().ConfigureAwait(true);
        }
        catch (Exception ex)
        {
            System.Windows.MessageBox.Show(ex.Message, "ASPLShield Setup", MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown();
        }
    }
}

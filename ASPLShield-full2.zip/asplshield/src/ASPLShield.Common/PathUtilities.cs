namespace ASPLShield.Common;

/// <summary>
/// File path helpers shared by the authoring and runtime projects.
/// </summary>
public static class PathUtilities
{
    public static string GetRelativePathSafe(string basePath, string fullPath)
        => Path.GetRelativePath(basePath, fullPath).Replace('\\', '/');

    public static string EnsureDirectory(string path)
    {
        Directory.CreateDirectory(path);
        return path;
    }
}

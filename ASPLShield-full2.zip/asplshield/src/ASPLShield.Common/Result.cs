namespace ASPLShield.Common;

/// <summary>
/// Represents the outcome of an operation.
/// </summary>
public sealed record Result(bool IsSuccess, string? ErrorMessage = null)
{
    public static Result Success() => new(true);

    public static Result Failure(string errorMessage) => new(false, errorMessage);
}

/// <summary>
/// Represents the outcome of an operation with a payload.
/// </summary>
public sealed record Result<T>(bool IsSuccess, T? Value = default, string? ErrorMessage = null)
{
    public static Result<T> Success(T value) => new(true, value);

    public static Result<T> Failure(string errorMessage) => new(false, default, errorMessage);
}

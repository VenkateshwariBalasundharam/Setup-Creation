namespace ASPLShield.Core;

public enum ProjectExplorerNodeKind
{
    Project,
    Files,
    Shortcuts,
    Registry,
    Iis,
    Services,
    Prerequisites,
    Build,
    File,
    Folder,
    Shortcut
}

public sealed class ProjectExplorerNode
{
    public string Header { get; set; } = string.Empty;

    public ProjectExplorerNodeKind Kind { get; set; }

    public string IconText { get; set; } = string.Empty;

    public string? Tag { get; set; }

    public string? Badge { get; set; }

    public string? Description { get; set; }

    public List<ProjectExplorerNode> Children { get; } = new();
}

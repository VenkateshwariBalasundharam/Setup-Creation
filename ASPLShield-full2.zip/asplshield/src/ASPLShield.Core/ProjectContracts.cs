namespace ASPLShield.Core;

public interface IProjectSerializer
{
    Task SaveAsync(InstallerProject project, string path, CancellationToken cancellationToken = default);

    Task<InstallerProject> LoadAsync(string path, CancellationToken cancellationToken = default);
}

public interface IProjectRepository
{
    Task InitializeAsync(CancellationToken cancellationToken = default);

    Task SaveProjectAsync(string path, InstallerProject project, CancellationToken cancellationToken = default);

    Task<InstallerProject?> LoadProjectAsync(string path, CancellationToken cancellationToken = default);

    Task RecordBuildAsync(BuildHistoryEntry entry, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<BuildHistoryEntry>> GetBuildHistoryAsync(CancellationToken cancellationToken = default);

    Task RecordRecentProjectAsync(string path, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<RecentProjectEntry>> GetRecentProjectsAsync(CancellationToken cancellationToken = default);

    Task ClearRecentProjectsAsync(CancellationToken cancellationToken = default);

    Task SaveTemplateAsync(ProjectTemplateEntry template, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<ProjectTemplateEntry>> GetTemplatesAsync(CancellationToken cancellationToken = default);

    Task DeleteTemplateAsync(long templateId, CancellationToken cancellationToken = default);
}

using System.Collections.ObjectModel;
using System.Xml.Serialization;
using ASPLShield.Common;

namespace ASPLShield.Core;

public enum CustomScreenControlType
{
    Label,
    TextBox,
    BrowseButton,
    CheckBox,
    RadioButton,
    NumberBox
}

public sealed class CustomScreenDefinition : ObservableObject
{
    private string _name = "Custom Screen";
    private string _title = "Custom screen";
    private string _description = string.Empty;

    public string Name { get => _name; set => SetProperty(ref _name, value); }
    public string Title { get => _title; set => SetProperty(ref _title, value); }
    public string Description { get => _description; set => SetProperty(ref _description, value); }

    [XmlArray("Controls")]
    [XmlArrayItem("Control")]
    public ObservableCollection<CustomScreenControl> Controls { get; set; } = new();
}

public sealed class CustomScreenControl : ObservableObject
{
    private string _id = $"field_{Guid.NewGuid():N}";
    private CustomScreenControlType _type = CustomScreenControlType.Label;
    private string _label = "Label";
    private string _text = string.Empty;
    private string _defaultValue = string.Empty;
    private string _appSettingsKey = string.Empty;
    private string _groupName = string.Empty;
    private bool _required;

    public string Id { get => _id; set => SetProperty(ref _id, value); }
    public CustomScreenControlType Type { get => _type; set => SetProperty(ref _type, value); }
    public string Label { get => _label; set => SetProperty(ref _label, value); }
    public string Text { get => _text; set => SetProperty(ref _text, value); }
    public string DefaultValue { get => _defaultValue; set => SetProperty(ref _defaultValue, value); }
    /// <summary>Dotted JSON path in appsettings.json, for example ConnectionStrings:Default.</summary>
    public string AppSettingsKey { get => _appSettingsKey; set => SetProperty(ref _appSettingsKey, value); }
    public string GroupName { get => _groupName; set => SetProperty(ref _groupName, value); }
    public bool Required { get => _required; set => SetProperty(ref _required, value); }
}

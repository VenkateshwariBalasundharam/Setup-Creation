using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace ASPLShield.Core;

/// <summary>
/// Serializes and deserializes ASPLShield project files.
/// </summary>
public sealed class XmlProjectSerializer : IProjectSerializer
{
    private static readonly XmlSerializer Serializer = new(typeof(InstallerProject));
    private static readonly XmlWriterSettings WriterSettings = new()
    {
        Encoding = new UTF8Encoding(encoderShouldEmitUTF8Identifier: false),
        Indent = true,
        NewLineChars = Environment.NewLine,
        NewLineHandling = NewLineHandling.Replace,
        Async = true,
        OmitXmlDeclaration = false,
        CloseOutput = true
    };
    private static readonly XmlReaderSettings ReaderSettings = new()
    {
        DtdProcessing = DtdProcessing.Prohibit,
        IgnoreComments = true,
        IgnoreWhitespace = true,
        CloseInput = true
    };

    public async Task SaveAsync(InstallerProject project, string path, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(project);

        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path)) ?? ".");
        await using var stream = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None, bufferSize: 4096, useAsync: true);
        await using var writer = XmlWriter.Create(stream, WriterSettings);
        Serializer.Serialize(writer, project);
        await writer.FlushAsync().ConfigureAwait(false);
        await stream.FlushAsync(cancellationToken).ConfigureAwait(false);
    }

    public async Task<InstallerProject> LoadAsync(string path, CancellationToken cancellationToken = default)
    {
        await using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, bufferSize: 4096, useAsync: true);
        using var reader = XmlReader.Create(stream, ReaderSettings);
        var result = Serializer.Deserialize(reader) as InstallerProject;
        return result ?? throw new InvalidDataException($"The project file '{path}' could not be read.");
    }
}

using ASPLShield.Common;

namespace ASPLShield.Core;

public enum ShortcutLocation
{
    Desktop = 0,
    StartMenu = 1
}

/// <summary>
/// Represents a shortcut created by the installer.
/// </summary>
public sealed class InstallerShortcut : ObservableObject
{
    private string _name = string.Empty;
    private string _targetPath = string.Empty;
    private string _arguments = string.Empty;
    private string _workingDirectory = string.Empty;
    private ShortcutLocation _location;

    public string Name { get => _name; set => SetProperty(ref _name, value); }

    public string TargetPath { get => _targetPath; set => SetProperty(ref _targetPath, value); }

    public string Arguments { get => _arguments; set => SetProperty(ref _arguments, value); }

    public string WorkingDirectory { get => _workingDirectory; set => SetProperty(ref _workingDirectory, value); }

    public ShortcutLocation Location { get => _location; set => SetProperty(ref _location, value); }
}

using System.Collections.ObjectModel;

namespace ASPLShield.Core;

public static class ProjectFactory
{
    public static InstallerProject CreateDefault()
        => Create(
            "Sample App",
            "ASPL",
            "1.0.0",
            "ASPL",
            @"[ProgramFiles]\SampleApp",
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "ASPLShieldBuild"));

    public static InstallerProject Create(string productName, string companyName, string version, string publisher, string installationFolder, string outputFolder)
        => new()
        {
            ProductName = productName,
            CompanyName = companyName,
            Version = version,
            Publisher = publisher,
            InstallationFolder = installationFolder,
            OutputFolder = outputFolder
        };
}

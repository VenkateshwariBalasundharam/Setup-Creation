using System.Runtime.Versioning;

namespace ASPLShield.Core;

/// <summary>
/// Resolves installation and package locations for runtime and uninstall scenarios.
/// </summary>
[SupportedOSPlatform("windows")]
public static class InstalledProductLocator
{
    public static string? ResolvePackagePath(IEnumerable<string> args, string baseDirectory)
    {
        var explicitPackage = GetExplicitPackagePath(args);
        if (!string.IsNullOrWhiteSpace(explicitPackage) && File.Exists(explicitPackage))
        {
            return explicitPackage;
        }

        // Look next to the running exe first (a single-file exe's BaseDirectory can be a temp
        // extraction folder), then fall back to the supplied base directory and the working directory.
        var candidates = new List<string>();
        var processDirectory = Path.GetDirectoryName(Environment.ProcessPath);
        if (!string.IsNullOrWhiteSpace(processDirectory))
        {
            candidates.Add(processDirectory);
        }

        candidates.Add(baseDirectory);
        candidates.Add(Directory.GetCurrentDirectory());

        foreach (var directory in candidates.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            if (!Directory.Exists(directory))
            {
                continue;
            }

            var match = Directory.GetFiles(directory, "*.asplpkg", SearchOption.TopDirectoryOnly).FirstOrDefault();
            if (match is not null)
            {
                return match;
            }
        }

        return null;
    }

    public static string? ResolveInstallFolder(IEnumerable<string> args, string baseDirectory)
    {
        var materialized = args.ToArray();
        var explicitFolder = GetExplicitInstallFolder(materialized);
        if (!string.IsNullOrWhiteSpace(explicitFolder))
        {
            return explicitFolder;
        }

        var fromBaseDirectory = FindInstallFolder(baseDirectory);
        if (!string.IsNullOrWhiteSpace(fromBaseDirectory))
        {
            return fromBaseDirectory;
        }

        return ReadInstallFolderFromRegistry();
    }

    private static string? GetExplicitPackagePath(IEnumerable<string> args)
    {
        var materialized = args.ToArray();
        var index = Array.FindIndex(materialized, arg => arg.Equals("--package", StringComparison.OrdinalIgnoreCase));
        if (index >= 0 && index + 1 < materialized.Length)
        {
            return materialized[index + 1];
        }

        return materialized.FirstOrDefault(arg => arg.EndsWith(".asplpkg", StringComparison.OrdinalIgnoreCase));
    }

    private static string? GetExplicitInstallFolder(string[] args)
    {
        var index = Array.FindIndex(args, arg => arg.Equals("--install-folder", StringComparison.OrdinalIgnoreCase));
        if (index >= 0 && index + 1 < args.Length)
        {
            return args[index + 1];
        }

        return args.FirstOrDefault(arg => Directory.Exists(arg));
    }

    private static string? FindInstallFolder(string rootFolder)
    {
        if (!Directory.Exists(rootFolder))
        {
            return null;
        }

        var directState = Path.Combine(rootFolder, "asplshield.installstate.json");
        if (File.Exists(directState))
        {
            return rootFolder;
        }

        var parent = Directory.GetParent(rootFolder)?.FullName;
        if (parent is not null && File.Exists(Path.Combine(parent, "asplshield.installstate.json")))
        {
            return parent;
        }

        return null;
    }

    private static string? ReadInstallFolderFromRegistry()
    {
        foreach (var hive in new[] { Microsoft.Win32.Registry.CurrentUser, Microsoft.Win32.Registry.LocalMachine })
        {
            using var key = hive.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Uninstall");
            if (key is null)
            {
                continue;
            }

            foreach (var subKeyName in key.GetSubKeyNames())
            {
                if (!subKeyName.StartsWith("ASPLShield_", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                using var subKey = key.OpenSubKey(subKeyName);
                var installLocation = subKey?.GetValue("InstallLocation") as string;
                if (!string.IsNullOrWhiteSpace(installLocation) && Directory.Exists(installLocation))
                {
                    return installLocation;
                }
            }
        }

        return null;
    }
}

using System.Collections.ObjectModel;
using System.Xml.Serialization;
using ASPLShield.Common;

namespace ASPLShield.Core;

/// <summary>
/// Root project model persisted as <c>.asplproj</c>.
/// </summary>
[XmlRoot("ASPLProject")]
public sealed class InstallerProject : ObservableObject
{
    private string _productName = string.Empty;
    private string _companyName = string.Empty;
    private string _version = "1.0.0";
    private string _publisher = string.Empty;
    private string _installationFolder = @"[ProgramFiles]\SampleApp";
    private string _outputFolder = string.Empty;

    public string ProductName { get => _productName; set => SetProperty(ref _productName, value); }

    public string CompanyName { get => _companyName; set => SetProperty(ref _companyName, value); }

    public string Version { get => _version; set => SetProperty(ref _version, value); }

    public string Publisher { get => _publisher; set => SetProperty(ref _publisher, value); }

    public string InstallationFolder { get => _installationFolder; set => SetProperty(ref _installationFolder, value); }

    public string OutputFolder { get => _outputFolder; set => SetProperty(ref _outputFolder, value); }

    public ProjectBuildSettings Build { get; set; } = new();

    [XmlArray("Files")]
    [XmlArrayItem("File")]
    public ObservableCollection<InstallerFile> Files { get; set; } = new();

    [XmlArray("Features")]
    [XmlArrayItem("Feature")]
    public ObservableCollection<InstallerFeature> Features { get; set; } = new();

    [XmlArray("Shortcuts")]
    [XmlArrayItem("Shortcut")]
    public ObservableCollection<InstallerShortcut> Shortcuts { get; set; } = new();

    [XmlArray("Registry")]
    [XmlArrayItem("Entry")]
    public ObservableCollection<RegistryEntry> RegistryEntries { get; set; } = new();

    [XmlArray("IisSites")]
    [XmlArrayItem("Site")]
    public ObservableCollection<IisSiteEntry> IisSites { get; set; } = new();

    [XmlArray("Services")]
    [XmlArrayItem("Service")]
    public ObservableCollection<ServiceEntry> Services { get; set; } = new();

    [XmlArray("Prerequisites")]
    [XmlArrayItem("Prerequisite")]
    public ObservableCollection<PrerequisiteEntry> Prerequisites { get; set; } = new();

    [XmlArray("NativePreviewOperations")]
    [XmlArrayItem("Operation")]
    public ObservableCollection<NativePreviewOperationEntry> NativePreviewOperations { get; set; } = new();

    [XmlArray("CustomScreens")]
    [XmlArrayItem("Screen")]
    public ObservableCollection<CustomScreenDefinition> CustomScreens { get; set; } = new();
}

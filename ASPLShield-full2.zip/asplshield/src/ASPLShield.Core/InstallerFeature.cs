using System.Xml.Serialization;

using ASPLShield.Common;

namespace ASPLShield.Core;

/// <summary>
/// Describes an optional (or required) installable component that the customer can choose
/// during a Custom setup, or select directly via the Setup.exe <c>ADDLOCAL=</c> command line.
/// </summary>
public sealed class InstallerFeature : ObservableObject
{
    private string _name = string.Empty;
    private string _displayName = string.Empty;
    private string _description = string.Empty;
    private string _parentFeatureName = string.Empty;
    private bool _isSelectedByDefault = true;
    private bool _isRequired;

    /// <summary>
    /// Stable identifier for this feature. Used as the ADDLOCAL token
    /// (e.g. <c>ADDLOCAL=MainApp,LanguagePackFR</c>) — keep it short, no spaces or commas.
    /// </summary>
    public string Name { get => _name; set => SetProperty(ref _name, value); }

    /// <summary>Label shown to the customer in the Custom setup tree view.</summary>
    public string DisplayName { get => _displayName; set => SetProperty(ref _displayName, value); }

    /// <summary>Longer explanation shown when the feature is selected/hovered in the tree view.</summary>
    public string Description { get => _description; set => SetProperty(ref _description, value); }

    /// <summary>
    /// <see cref="Name"/> of the parent feature, or empty for a top-level feature. Selecting a
    /// parent selects all of its children; unchecking every child clears the parent.
    /// </summary>
    public string ParentFeatureName { get => _parentFeatureName; set => SetProperty(ref _parentFeatureName, value); }

    /// <summary>Whether this feature is pre-checked under Typical / Complete setup.</summary>
    public bool IsSelectedByDefault { get => _isSelectedByDefault; set => SetProperty(ref _isSelectedByDefault, value); }

    /// <summary>When true, the customer cannot uncheck this feature (e.g. the main application).</summary>
    public bool IsRequired { get => _isRequired; set => SetProperty(ref _isRequired, value); }
}

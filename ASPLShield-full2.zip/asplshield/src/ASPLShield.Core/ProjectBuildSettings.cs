using ASPLShield.Common;

namespace ASPLShield.Core;

public enum MsiAuthoringMode
{
    Wix,
    NativePreview
}

public sealed class ProjectBuildSettings : ObservableObject
{
    private bool _createUninstaller = true;
    private string _setupExecutableName = "Setup.exe";
    private bool _includeIcon = true;
    private bool _includeLicense = true;
    private bool _allowCustomerCustomization;
    private string _iconPath = string.Empty;
    private string _licensePath = string.Empty;
    private string _runtimeBootstrapperPath = string.Empty;
    private string _customLogoPath = string.Empty;
    private string _customCompanyName = string.Empty;
    private string _customBrandColorHex = string.Empty;
    private string _brandingBannerImagePath = string.Empty;
    private string _brandingWelcomeImagePath = string.Empty;
    private string _brandingAccentColorHex = string.Empty;
    private string _brandingWelcomeBackgroundColorHex = string.Empty;
    private string _upgradeVersionMin = "0.0.0";
    private string _upgradeVersionMax = string.Empty;
    private string _upgradeActionProperty = string.Empty;
    private MsiAuthoringMode _msiAuthoringMode = MsiAuthoringMode.Wix;

    public bool CreateUninstaller { get => _createUninstaller; set => SetProperty(ref _createUninstaller, value); }

    /// <summary>File name for the generated installer bootstrapper executable.</summary>
    public string SetupExecutableName { get => _setupExecutableName; set => SetProperty(ref _setupExecutableName, value); }

    public const string DefaultSetupExecutableName = "Setup.exe";

    /// <summary>
    /// Turns whatever the user typed into a valid installer file name: trims, strips invalid
    /// characters and any folder part, falls back to Setup.exe when empty, and appends ".exe" if missing.
    /// </summary>
    public static string NormalizeSetupExecutableName(string? input)
    {
        var name = (input ?? string.Empty).Trim();
        name = Path.GetFileName(name.Replace('/', Path.DirectorySeparatorChar).Replace('\\', Path.DirectorySeparatorChar));
        foreach (var invalid in Path.GetInvalidFileNameChars())
        {
            name = name.Replace(invalid.ToString(), string.Empty, StringComparison.Ordinal);
        }

        name = name.Trim().TrimEnd('.');
        if (name.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
        {
            name = name[..^4].TrimEnd('.', ' ');
        }

        return name.Length == 0 ? DefaultSetupExecutableName : name + ".exe";
    }

    public bool IncludeIcon { get => _includeIcon; set => SetProperty(ref _includeIcon, value); }

    public bool IncludeLicense { get => _includeLicense; set => SetProperty(ref _includeLicense, value); }

    /// <summary>
    /// When true, the generated Setup.exe asks the end customer for a logo, company name,
    /// and brand color during installation and applies them (branding files + shortcut icon).
    /// </summary>
    public bool AllowCustomerCustomization { get => _allowCustomerCustomization; set => SetProperty(ref _allowCustomerCustomization, value); }

    public string IconPath { get => _iconPath; set => SetProperty(ref _iconPath, value); }

    public string LicensePath { get => _licensePath; set => SetProperty(ref _licensePath, value); }

    public string RuntimeBootstrapperPath { get => _runtimeBootstrapperPath; set => SetProperty(ref _runtimeBootstrapperPath, value); }

    /// <summary>
    /// Author-supplied default logo (bmp/png) used for installer branding when
    /// <see cref="AllowCustomerCustomization"/> is enabled. ~493x312 recommended for WiX banner/dialog bitmaps.
    /// </summary>
    public string CustomLogoPath { get => _customLogoPath; set => SetProperty(ref _customLogoPath, value); }

    /// <summary>
    /// Author-supplied default company name shown in the installer branding when
    /// <see cref="AllowCustomerCustomization"/> is enabled.
    /// </summary>
    public string CustomCompanyName { get => _customCompanyName; set => SetProperty(ref _customCompanyName, value); }

    /// <summary>
    /// Author-supplied default brand color (hex, e.g. "#1A73E8") used for installer branding when
    /// <see cref="AllowCustomerCustomization"/> is enabled.
    /// </summary>
    public string CustomBrandColorHex { get => _customBrandColorHex; set => SetProperty(ref _customBrandColorHex, value); }

    /// <summary>
    /// Author-set banner image shown across the top of every wizard page except Welcome/Finish.
    /// Recommended size ~494x58 (PNG, JPG, or BMP) — matches the classic WiX/InstallAware banner
    /// dimensions. This is fixed installer branding, distinct from <see cref="AllowCustomerCustomization"/>,
    /// which lets the end customer pick their own logo at install time.
    /// </summary>
    public string BrandingBannerImagePath { get => _brandingBannerImagePath; set => SetProperty(ref _brandingBannerImagePath, value); }

    /// <summary>
    /// Author-set full-height image shown on the Welcome and Finish pages. Recommended size
    /// ~164x312 (PNG, JPG, or BMP) — matches the classic WiX/InstallAware dialog image dimensions.
    /// </summary>
    public string BrandingWelcomeImagePath { get => _brandingWelcomeImagePath; set => SetProperty(ref _brandingWelcomeImagePath, value); }

    /// <summary>
    /// Author-set accent color (hex, e.g. "#1A73E8") applied to the setup wizard's header badge,
    /// buttons, and progress bar. Leave blank to use the Runtime's default theme accent.
    /// </summary>
    public string BrandingAccentColorHex { get => _brandingAccentColorHex; set => SetProperty(ref _brandingAccentColorHex, value); }

    /// <summary>
    /// Author-set fill color (hex, e.g. "#F3E6D0") shown behind the Welcome/Finish image when the
    /// image doesn't exactly fill its frame — set this to match your logo's own background so the
    /// image blends in seamlessly instead of showing a white/mismatched border. Leave blank to use
    /// the Runtime's default card background.
    /// </summary>
    public string BrandingWelcomeBackgroundColorHex { get => _brandingWelcomeBackgroundColorHex; set => SetProperty(ref _brandingWelcomeBackgroundColorHex, value); }

    public string UpgradeVersionMin { get => _upgradeVersionMin; set => SetProperty(ref _upgradeVersionMin, value); }

    public string UpgradeVersionMax { get => _upgradeVersionMax; set => SetProperty(ref _upgradeVersionMax, value); }

    public string UpgradeActionProperty { get => _upgradeActionProperty; set => SetProperty(ref _upgradeActionProperty, value); }

    public MsiAuthoringMode MsiAuthoringMode { get => _msiAuthoringMode; set => SetProperty(ref _msiAuthoringMode, value); }
}

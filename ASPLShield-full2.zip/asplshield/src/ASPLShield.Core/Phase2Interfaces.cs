namespace ASPLShield.Core;

/// <summary>
/// Future phase extension point for registry authoring.
/// </summary>
public interface IRegistryInstaller
{
    Task InstallAsync(IEnumerable<RegistryEntry> entries, CancellationToken cancellationToken = default);

    Task UninstallAsync(IEnumerable<RegistryEntry> entries, CancellationToken cancellationToken = default);
}

/// <summary>
/// Future phase extension point for IIS site and application pool deployment.
/// </summary>
public interface IIisInstaller
{
    Task InstallAsync(IEnumerable<IisSiteEntry> sites, CancellationToken cancellationToken = default);

    Task UninstallAsync(IEnumerable<IisSiteEntry> sites, CancellationToken cancellationToken = default);
}

/// <summary>
/// Future phase extension point for Windows service deployment.
/// </summary>
public interface IServiceInstaller
{
    Task InstallAsync(ServiceEntry service, CancellationToken cancellationToken = default);

    Task UninstallAsync(string serviceName, CancellationToken cancellationToken = default);
}

/// <summary>
/// Future phase extension point for prerequisite detection.
/// </summary>
public interface IPrerequisiteChecker
{
    Task<bool> IsSatisfiedAsync(PrerequisiteEntry prerequisite, CancellationToken cancellationToken = default);
}

/// <summary>
/// Future phase extension point for MSI generation.
/// </summary>
public interface IMsiGenerator
{
    Task<string> GenerateAsync(InstallerProject project, CancellationToken cancellationToken = default);
}

/// <summary>
/// Future phase extension point for auto-updating installed products.
/// </summary>
public interface IAutoUpdater
{
    Task CheckForUpdatesAsync(CancellationToken cancellationToken = default);
}

/// <summary>
/// Future phase extension point for digital signing.
/// </summary>
public interface IDigitalSigner
{
    Task<string> SignAsync(string filePath, CancellationToken cancellationToken = default);
}

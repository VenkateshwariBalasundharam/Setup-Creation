namespace ASPLShield.Core;

public sealed class BuildHistoryEntry
{
    public long Id { get; set; }

    public string ProjectPath { get; set; } = string.Empty;

    public DateTimeOffset BuiltAtUtc { get; set; } = DateTimeOffset.UtcNow;

    public string OutputFolder { get; set; } = string.Empty;

    public bool Succeeded { get; set; }

    public string? Message { get; set; }
}

public sealed class RecentProjectEntry
{
    public long Id { get; set; }

    public string ProjectPath { get; set; } = string.Empty;

    public DateTimeOffset OpenedAtUtc { get; set; } = DateTimeOffset.UtcNow;
}

public sealed class ProjectTemplateEntry
{
    public long Id { get; set; }

    public string Name { get; set; } = string.Empty;

    public string Description { get; set; } = string.Empty;

    public string TemplatePath { get; set; } = string.Empty;
}

using System.Collections.ObjectModel;

namespace ASPLShield.Core;

/// <summary>
/// Represents a single node (folder or file) in the nested destination-path tree
/// shown on the Files tab. Unlike the flat <see cref="InstallerFile"/> list, this
/// splits each destination path (e.g. "wwwroot/assets/img/logo.png") into real,
/// individually-addressable folder nodes.
/// </summary>
public sealed class DestinationTreeNode
{
    public string Name { get; set; } = string.Empty;

    public string FullPath { get; set; } = string.Empty;

    public bool IsFolder { get; set; }

    /// <summary>
    /// The underlying file entry. Set for file leaf nodes, and for folder nodes that
    /// were added directly as a folder (via Add Folder / drag-drop of a directory).
    /// </summary>
    public InstallerFile? File { get; set; }

    public string IconText => IsFolder ? "FD" : "FI";

    public string Badge => IsFolder
        ? $"{Children.Count} item{(Children.Count == 1 ? string.Empty : "s")}"
        : FormatSize(File?.SizeBytes ?? 0);

    public ObservableCollection<DestinationTreeNode> Children { get; } = new();

    private static string FormatSize(long bytes)
    {
        string[] units = { "B", "KB", "MB", "GB", "TB" };
        double size = bytes;
        var unitIndex = 0;
        while (size >= 1024 && unitIndex < units.Length - 1)
        {
            size /= 1024;
            unitIndex++;
        }

        return unitIndex == 0 ? $"{bytes} B" : $"{size:0.#} {units[unitIndex]}";
    }
}

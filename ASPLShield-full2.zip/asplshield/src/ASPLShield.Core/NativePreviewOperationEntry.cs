using ASPLShield.Common;

namespace ASPLShield.Core;

/// <summary>
/// Persisted native MSI preview operation metadata stored in <c>.asplproj</c>.
/// </summary>
public sealed class NativePreviewOperationEntry : ObservableObject
{
    private int _sequence;
    private string _operation = string.Empty;
    private string _table = string.Empty;
    private string _primaryKey = string.Empty;
    private string _summary = string.Empty;

    public int Sequence
    {
        get => _sequence;
        set => SetProperty(ref _sequence, value);
    }

    public string Operation
    {
        get => _operation;
        set => SetProperty(ref _operation, value);
    }

    public string Table
    {
        get => _table;
        set => SetProperty(ref _table, value);
    }

    public string PrimaryKey
    {
        get => _primaryKey;
        set => SetProperty(ref _primaryKey, value);
    }

    public string Summary
    {
        get => _summary;
        set => SetProperty(ref _summary, value);
    }
}

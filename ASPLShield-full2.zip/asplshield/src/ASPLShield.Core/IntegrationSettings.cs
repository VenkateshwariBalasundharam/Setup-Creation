using System.Text.Json;

namespace ASPLShield.Core;

/// <summary>
/// Shared integration settings for update and signing workflows.
/// </summary>
public sealed class IntegrationSettings
{
    public string? SigningCertificatePath { get; set; }

    public string? SigningCertificatePassword { get; set; }

    public string? SigningTimestampUrl { get; set; }

    public string? SigningToolPath { get; set; }

    public string? UpdateFeedUri { get; set; }
}

public static class IntegrationSettingsLoader
{
    private static readonly Lazy<IntegrationSettings> LazyCurrent = new(Load);

    public static IntegrationSettings Current => LazyCurrent.Value;

    public static IntegrationSettings Load()
    {
        var configPath = GetConfigPath();
        if (configPath is null || !File.Exists(configPath))
        {
            return new IntegrationSettings();
        }

        var json = File.ReadAllText(configPath);
        return JsonSerializer.Deserialize<IntegrationSettings>(json, new JsonSerializerOptions(JsonSerializerDefaults.Web))
            ?? new IntegrationSettings();
    }

    private static string? GetConfigPath()
    {
        var configured = Environment.GetEnvironmentVariable("ASPLSHIELD_INTEGRATION_CONFIG");
        if (!string.IsNullOrWhiteSpace(configured))
        {
            return Path.GetFullPath(configured);
        }

        var defaultPath = Path.Combine(AppContext.BaseDirectory, "asplshield.integration.json");
        return defaultPath;
    }
}

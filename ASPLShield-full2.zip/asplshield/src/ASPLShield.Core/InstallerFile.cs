using System.Xml.Serialization;

using ASPLShield.Common;

namespace ASPLShield.Core;

/// <summary>
/// Describes a file or folder included in the installer payload.
/// </summary>
public sealed class InstallerFile : ObservableObject
{
    private string _sourcePath = string.Empty;
    private string _destinationPath = string.Empty;
    private bool _isFolder;
    private long _sizeBytes;
    private string _displayName = string.Empty;
    private string _featureName = string.Empty;

    public string SourcePath { get => _sourcePath; set => SetProperty(ref _sourcePath, value); }

    public string DestinationPath { get => _destinationPath; set => SetProperty(ref _destinationPath, value); }

    public bool IsFolder { get => _isFolder; set => SetProperty(ref _isFolder, value); }

    public long SizeBytes { get => _sizeBytes; set => SetProperty(ref _sizeBytes, value); }

    public string DisplayName { get => _displayName; set => SetProperty(ref _displayName, value); }

    /// <summary>
    /// <see cref="InstallerFeature.Name"/> of the feature this file belongs to, or empty if the
    /// file is feature-independent (always installed). Set from the Files tab's
    /// "Assign to Feature" tree and used to filter the Files grid and to scope MSI components.
    /// </summary>
    public string FeatureName { get => _featureName; set => SetProperty(ref _featureName, value); }
}

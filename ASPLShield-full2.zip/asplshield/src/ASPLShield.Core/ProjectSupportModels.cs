using System.Collections.Generic;
using ASPLShield.Common;

namespace ASPLShield.Core;

public enum RegistryRootKind
{
    CurrentUser,
    LocalMachine,
    ClassesRoot,
    Users,
    CurrentConfig
}

public sealed class RegistryEntry : ObservableObject
{
    private RegistryRootKind _registryRoot = RegistryRootKind.CurrentUser;
    private string _keyPath = string.Empty;
    private string _name = string.Empty;
    private string _value = string.Empty;
    private string _valueKind = "String";

    public RegistryRootKind RegistryRoot { get => _registryRoot; set => SetProperty(ref _registryRoot, value); }

    public string KeyPath { get => _keyPath; set => SetProperty(ref _keyPath, value); }

    public string Name { get => _name; set => SetProperty(ref _name, value); }

    public string Value { get => _value; set => SetProperty(ref _value, value); }

    public string ValueKind { get => _valueKind; set => SetProperty(ref _valueKind, value); }
}

public sealed class ServiceEntry : ObservableObject
{
    private string _serviceName = string.Empty;
    private string _displayName = string.Empty;
    private string _executablePath = string.Empty;
    private string _arguments = string.Empty;
    private string? _description;
    private string? _accountName;
    private string? _accountPassword;
    private bool _autoStart = true;
    private bool _delayedAutoStart;

    public string ServiceName { get => _serviceName; set => SetProperty(ref _serviceName, value); }

    public string DisplayName { get => _displayName; set => SetProperty(ref _displayName, value); }

    public string ExecutablePath { get => _executablePath; set => SetProperty(ref _executablePath, value); }

    public string Arguments { get => _arguments; set => SetProperty(ref _arguments, value); }

    public string? Description { get => _description; set => SetProperty(ref _description, value); }

    public string? AccountName { get => _accountName; set => SetProperty(ref _accountName, value); }

    public string? AccountPassword { get => _accountPassword; set => SetProperty(ref _accountPassword, value); }

    public bool AutoStart { get => _autoStart; set => SetProperty(ref _autoStart, value); }

    public bool DelayedAutoStart { get => _delayedAutoStart; set => SetProperty(ref _delayedAutoStart, value); }

    public List<string> Dependencies { get; set; } = new();
}

public sealed class IisSiteBindingEntry : ObservableObject
{
    private string _protocol = "http";
    private string _bindingInformation = "*:80:";

    public string Protocol { get => _protocol; set => SetProperty(ref _protocol, value); }

    public string BindingInformation { get => _bindingInformation; set => SetProperty(ref _bindingInformation, value); }
}

public sealed class IisSiteEntry : ObservableObject
{
    private string _siteName = string.Empty;
    private string _physicalPath = string.Empty;
    private string _applicationPoolName = string.Empty;
    private bool _createApplicationPool = true;
    private bool _startOnInstall = true;

    public string SiteName { get => _siteName; set => SetProperty(ref _siteName, value); }

    public string PhysicalPath { get => _physicalPath; set => SetProperty(ref _physicalPath, value); }

    public string ApplicationPoolName { get => _applicationPoolName; set => SetProperty(ref _applicationPoolName, value); }

    public bool CreateApplicationPool { get => _createApplicationPool; set => SetProperty(ref _createApplicationPool, value); }

    public bool StartOnInstall { get => _startOnInstall; set => SetProperty(ref _startOnInstall, value); }

    public List<IisSiteBindingEntry> Bindings { get; set; } = new();
}

public enum PrerequisiteType
{
    Unknown,
    OperatingSystem,
    DotNetRuntime,
    FileExists,
    RegistryKey,
    Iis
}

public sealed class PrerequisiteEntry
{
    public string Name { get; set; } = string.Empty;

    public string Version { get; set; } = string.Empty;

    public bool Required { get; set; } = true;

    public string? Description { get; set; }

    public PrerequisiteType Type { get; set; } = PrerequisiteType.Unknown;

    public string? DetectionTarget { get; set; }

    public string? MinimumVersion { get; set; }

    public string? ExpectedValue { get; set; }
}

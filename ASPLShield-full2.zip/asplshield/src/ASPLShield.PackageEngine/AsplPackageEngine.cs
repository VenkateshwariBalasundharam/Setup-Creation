using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Serialization;
using ASPLShield.Common;
using ASPLShield.Core;

namespace ASPLShield.PackageEngine;

/// <summary>
/// Creates and consumes ASPLShield deployment packages.
/// </summary>
public sealed class AsplPackageEngine : IPackageEngine
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public async Task CreatePackageAsync(InstallerProject project, string sourceRoot, string packagePath, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(project);

        PathUtilities.EnsureDirectory(Path.GetDirectoryName(packagePath) ?? ".");

        var tempPayload = Path.Combine(Path.GetTempPath(), $"{Guid.NewGuid():N}.payload.zip");
        try
        {
            CreatePayloadZip(sourceRoot, tempPayload);

            await using var fileStream = File.Create(packagePath);
            using var archive = new ZipArchive(fileStream, ZipArchiveMode.Create, leaveOpen: true);

            var manifestEntry = archive.CreateEntry("manifest.json", CompressionLevel.Optimal);
            await using (var manifestStream = manifestEntry.Open())
            {
                var manifest = BuildManifest(project);
                await JsonSerializer.SerializeAsync(manifestStream, manifest, JsonOptions, cancellationToken).ConfigureAwait(false);
            }

            archive.CreateEntryFromFile(tempPayload, "payload.zip", CompressionLevel.Optimal);

            if (project.Build.IncludeIcon)
            {
                await AddOptionalFileEntryAsync(archive, project.Build.IconPath, "icon.ico", cancellationToken).ConfigureAwait(false);
            }

            if (project.Build.IncludeLicense)
            {
                await AddOptionalFileEntryAsync(archive, project.Build.LicensePath, "license.txt", cancellationToken).ConfigureAwait(false);
            }

            if (!string.IsNullOrWhiteSpace(project.Build.BrandingBannerImagePath))
            {
                await AddOptionalFileEntryAsync(archive, project.Build.BrandingBannerImagePath, "branding-banner.png", cancellationToken).ConfigureAwait(false);
            }

            if (!string.IsNullOrWhiteSpace(project.Build.BrandingWelcomeImagePath))
            {
                await AddOptionalFileEntryAsync(archive, project.Build.BrandingWelcomeImagePath, "branding-welcome.png", cancellationToken).ConfigureAwait(false);
            }

            if (project.Build.AllowCustomerCustomization && !string.IsNullOrWhiteSpace(project.Build.CustomLogoPath))
            {
                await AddOptionalFileEntryAsync(archive, project.Build.CustomLogoPath, "customer-default-logo.png", cancellationToken).ConfigureAwait(false);
            }
        }
        finally
        {
            if (File.Exists(tempPayload))
            {
                File.Delete(tempPayload);
            }
        }
    }

    public async Task<AsplPackageInfo> ReadPackageAsync(string packagePath, CancellationToken cancellationToken = default)
    {
        await using var stream = File.OpenRead(packagePath);
        using var archive = new ZipArchive(stream, ZipArchiveMode.Read, leaveOpen: false);
        var manifestEntry = archive.GetEntry("manifest.json") ?? throw new InvalidDataException("Package manifest is missing.");
        await using var manifestStream = manifestEntry.Open();
        var manifest = await JsonSerializer.DeserializeAsync<AsplPackageManifest>(manifestStream, JsonOptions, cancellationToken).ConfigureAwait(false)
            ?? throw new InvalidDataException("Package manifest could not be read.");

        return new AsplPackageInfo
        {
            Manifest = manifest,
            PackagePath = packagePath
        };
    }

    public async Task<PackageValidationResult> ValidatePackageAsync(string packagePath, CancellationToken cancellationToken = default)
    {
        var result = new PackageValidationResult();

        if (!File.Exists(packagePath))
        {
            result.AddError($"Package '{packagePath}' was not found.");
            return result;
        }

        try
        {
            await using var stream = File.OpenRead(packagePath);
            using var archive = new ZipArchive(stream, ZipArchiveMode.Read, leaveOpen: false);
            var manifestEntry = archive.GetEntry("manifest.json") ?? throw new InvalidDataException("Package manifest is missing.");
            await using var manifestStream = manifestEntry.Open();
            var manifest = await JsonSerializer.DeserializeAsync<AsplPackageManifest>(manifestStream, JsonOptions, cancellationToken).ConfigureAwait(false)
                ?? throw new InvalidDataException("Package manifest could not be read.");

            if (string.IsNullOrWhiteSpace(manifest.ProductName))
            {
                result.AddError("Manifest product name is required.");
            }

            if (string.IsNullOrWhiteSpace(manifest.Version))
            {
                result.AddError("Manifest version is required.");
            }

            if (string.IsNullOrWhiteSpace(manifest.InstallPath))
            {
                result.AddError("Manifest install path is required.");
            }

            if (manifest.HasIcon && archive.GetEntry("icon.ico") is null)
            {
                result.AddError("Package icon was expected but icon.ico is missing.");
            }

            if (manifest.HasLicense && archive.GetEntry("license.txt") is null)
            {
                result.AddError("Package license was expected but license.txt is missing.");
            }

            if (manifest.HasBrandingBanner && archive.GetEntry("branding-banner.png") is null)
            {
                result.AddError("Banner branding image was expected but branding-banner.png is missing.");
            }

            if (manifest.HasBrandingWelcomeImage && archive.GetEntry("branding-welcome.png") is null)
            {
                result.AddError("Welcome branding image was expected but branding-welcome.png is missing.");
            }

            if (manifest.HasCustomerDefaultLogo && archive.GetEntry("customer-default-logo.png") is null)
            {
                result.AddError("Customer customization default logo was expected but customer-default-logo.png is missing.");
            }

            if (manifest.Shortcuts.Any(shortcut => string.IsNullOrWhiteSpace(shortcut.Name) || string.IsNullOrWhiteSpace(shortcut.TargetPath)))
            {
                result.AddError("Every shortcut entry requires a name and target path.");
            }

            if (manifest.Services.Any(service => string.IsNullOrWhiteSpace(service.ServiceName) || string.IsNullOrWhiteSpace(service.ExecutablePath)))
            {
                result.AddError("Every service entry requires a service name and executable path.");
            }

            if (manifest.IisSites.Any(site => string.IsNullOrWhiteSpace(site.SiteName) || site.Bindings.Count == 0))
            {
                result.AddError("Every IIS site requires a site name and at least one binding.");
            }

            if (manifest.Prerequisites.Any(prerequisite => string.IsNullOrWhiteSpace(prerequisite.Name)))
            {
                result.AddError("Every prerequisite entry requires a name.");
            }

            if (manifest.Prerequisites.Any(prerequisite => string.Equals(prerequisite.Type, nameof(PrerequisiteType.FileExists), StringComparison.OrdinalIgnoreCase) && string.IsNullOrWhiteSpace(prerequisite.DetectionTarget)))
            {
                result.AddError("File prerequisite entries require a detection target.");
            }

            if (manifest.Prerequisites.Any(prerequisite => string.Equals(prerequisite.Type, nameof(PrerequisiteType.RegistryKey), StringComparison.OrdinalIgnoreCase) && string.IsNullOrWhiteSpace(prerequisite.DetectionTarget)))
            {
                result.AddError("Registry prerequisite entries require a detection target.");
            }

            if (manifest.Prerequisites.Any(prerequisite => (string.Equals(prerequisite.Type, nameof(PrerequisiteType.OperatingSystem), StringComparison.OrdinalIgnoreCase) || string.Equals(prerequisite.Type, nameof(PrerequisiteType.DotNetRuntime), StringComparison.OrdinalIgnoreCase)) && string.IsNullOrWhiteSpace(prerequisite.MinimumVersion) && string.IsNullOrWhiteSpace(prerequisite.Version)))
            {
                result.AddError("Operating system and .NET prerequisite entries require a minimum version.");
            }
        }
        catch (Exception ex)
        {
            result.AddError(ex.Message);
        }

        return result;
    }

    public async Task ExtractPackageAsync(string packagePath, string destinationFolder, CancellationToken cancellationToken = default)
    {
        PathUtilities.EnsureDirectory(destinationFolder);

        await using var stream = File.OpenRead(packagePath);
        using var archive = new ZipArchive(stream, ZipArchiveMode.Read, leaveOpen: false);
        var payloadEntry = archive.GetEntry("payload.zip") ?? throw new InvalidDataException("Package payload is missing.");

        var tempPayload = Path.Combine(Path.GetTempPath(), $"{Guid.NewGuid():N}.payload.zip");
        await using (var payloadStream = payloadEntry.Open())
        await using (var tempFile = File.Create(tempPayload))
        {
            await payloadStream.CopyToAsync(tempFile, cancellationToken).ConfigureAwait(false);
        }

        try
        {
            using var payloadArchive = ZipFile.OpenRead(tempPayload);
            foreach (var entry in payloadArchive.Entries)
            {
                var outputPath = Path.Combine(destinationFolder, entry.FullName);
                if (string.IsNullOrEmpty(entry.Name))
                {
                    Directory.CreateDirectory(outputPath);
                    continue;
                }

                Directory.CreateDirectory(Path.GetDirectoryName(outputPath) ?? destinationFolder);
                entry.ExtractToFile(outputPath, overwrite: true);
            }
        }
        finally
        {
            File.Delete(tempPayload);
        }
    }

    private static AsplPackageManifest BuildManifest(InstallerProject project) => new()
    {
        ProductName = project.ProductName,
        Version = project.Version,
        Publisher = project.Publisher,
        InstallPath = project.InstallationFolder,
        HasIcon = project.Build.IncludeIcon,
        HasLicense = project.Build.IncludeLicense,
        AllowCustomerCustomization = project.Build.AllowCustomerCustomization,
        DefaultCustomerCompanyName = string.IsNullOrWhiteSpace(project.Build.CustomCompanyName) ? null : project.Build.CustomCompanyName,
        DefaultCustomerBrandColorHex = string.IsNullOrWhiteSpace(project.Build.CustomBrandColorHex) ? null : project.Build.CustomBrandColorHex,
        HasCustomerDefaultLogo = project.Build.AllowCustomerCustomization && !string.IsNullOrWhiteSpace(project.Build.CustomLogoPath) && File.Exists(project.Build.CustomLogoPath),
        HasBrandingBanner = !string.IsNullOrWhiteSpace(project.Build.BrandingBannerImagePath) && File.Exists(project.Build.BrandingBannerImagePath),
        HasBrandingWelcomeImage = !string.IsNullOrWhiteSpace(project.Build.BrandingWelcomeImagePath) && File.Exists(project.Build.BrandingWelcomeImagePath),
        BrandingAccentColorHex = string.IsNullOrWhiteSpace(project.Build.BrandingAccentColorHex) ? null : project.Build.BrandingAccentColorHex,
        BrandingWelcomeBackgroundColorHex = string.IsNullOrWhiteSpace(project.Build.BrandingWelcomeBackgroundColorHex) ? null : project.Build.BrandingWelcomeBackgroundColorHex,
        CustomScreens = project.CustomScreens.ToList(),
        Shortcuts = project.Shortcuts.Select(shortcut => new AsplPackageShortcut
        {
            Name = shortcut.Name,
            TargetPath = shortcut.TargetPath,
            Arguments = shortcut.Arguments,
            WorkingDirectory = shortcut.WorkingDirectory,
            Location = shortcut.Location.ToString()
        }).ToList(),
        IisSites = project.IisSites.Select(site => new AsplPackageIisSite
        {
            SiteName = site.SiteName,
            PhysicalPath = site.PhysicalPath,
            ApplicationPoolName = site.ApplicationPoolName,
            CreateApplicationPool = site.CreateApplicationPool,
            StartOnInstall = site.StartOnInstall,
            Bindings = site.Bindings.Select(binding => new AsplPackageIisBinding
            {
                Protocol = binding.Protocol,
                BindingInformation = binding.BindingInformation
            }).ToList()
        }).ToList(),
        RegistryEntries = project.RegistryEntries.Select(entry => new AsplPackageRegistryEntry
        {
            RegistryRoot = entry.RegistryRoot,
            KeyPath = entry.KeyPath,
            Name = entry.Name,
            Value = entry.Value,
            ValueKind = entry.ValueKind
        }).ToList(),
        Services = project.Services.Select(service => new AsplPackageServiceEntry
        {
            ServiceName = service.ServiceName,
            DisplayName = service.DisplayName,
            ExecutablePath = service.ExecutablePath,
            Arguments = service.Arguments,
            Description = service.Description,
            AccountName = service.AccountName,
            AccountPassword = service.AccountPassword,
            AutoStart = service.AutoStart,
            DelayedAutoStart = service.DelayedAutoStart,
            Dependencies = service.Dependencies.ToList()
        }).ToList(),
        Prerequisites = project.Prerequisites.Select(prerequisite => new AsplPackagePrerequisite
        {
            Name = prerequisite.Name,
            Version = prerequisite.Version,
            Required = prerequisite.Required,
            Description = prerequisite.Description,
            Type = prerequisite.Type.ToString(),
            DetectionTarget = prerequisite.DetectionTarget,
            MinimumVersion = prerequisite.MinimumVersion,
            ExpectedValue = prerequisite.ExpectedValue
        }).ToList()
    };

    private static void CreatePayloadZip(string sourceRoot, string payloadPath)
    {
        if (File.Exists(payloadPath))
        {
            File.Delete(payloadPath);
        }

        ZipFile.CreateFromDirectory(sourceRoot, payloadPath, CompressionLevel.Optimal, includeBaseDirectory: false);
    }

    private static async Task AddOptionalFileEntryAsync(ZipArchive archive, string sourcePath, string entryName, CancellationToken cancellationToken)
    {
        var entry = archive.CreateEntry(entryName, CompressionLevel.Optimal);
        if (string.IsNullOrWhiteSpace(sourcePath) || !File.Exists(sourcePath))
        {
            return;
        }

        await using var sourceStream = File.OpenRead(sourcePath);
        await using var entryStream = entry.Open();
        await sourceStream.CopyToAsync(entryStream, cancellationToken).ConfigureAwait(false);
    }
}

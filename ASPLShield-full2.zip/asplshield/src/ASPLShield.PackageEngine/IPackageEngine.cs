using ASPLShield.Core;

namespace ASPLShield.PackageEngine;

public interface IPackageEngine
{
    Task CreatePackageAsync(InstallerProject project, string sourceRoot, string packagePath, CancellationToken cancellationToken = default);

    Task<AsplPackageInfo> ReadPackageAsync(string packagePath, CancellationToken cancellationToken = default);

    Task<PackageValidationResult> ValidatePackageAsync(string packagePath, CancellationToken cancellationToken = default);

    Task ExtractPackageAsync(string packagePath, string destinationFolder, CancellationToken cancellationToken = default);
}

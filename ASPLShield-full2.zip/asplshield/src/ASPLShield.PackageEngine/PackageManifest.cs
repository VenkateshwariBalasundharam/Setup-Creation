using ASPLShield.Core;

namespace ASPLShield.PackageEngine;

public sealed class AsplPackageShortcut
{
    public string Name { get; set; } = string.Empty;

    public string TargetPath { get; set; } = string.Empty;

    public string Arguments { get; set; } = string.Empty;

    public string WorkingDirectory { get; set; } = string.Empty;

    public string Location { get; set; } = string.Empty;
}

public sealed class AsplPackageIisBinding
{
    public string Protocol { get; set; } = "http";

    public string BindingInformation { get; set; } = "*:80:";
}

public sealed class AsplPackageIisSite
{
    public string SiteName { get; set; } = string.Empty;

    public string PhysicalPath { get; set; } = string.Empty;

    public string ApplicationPoolName { get; set; } = string.Empty;

    public bool CreateApplicationPool { get; set; } = true;

    public bool StartOnInstall { get; set; } = true;

    public List<AsplPackageIisBinding> Bindings { get; set; } = new();
}

public sealed class AsplPackageRegistryEntry
{
    public RegistryRootKind RegistryRoot { get; set; } = RegistryRootKind.CurrentUser;

    public string KeyPath { get; set; } = string.Empty;

    public string Name { get; set; } = string.Empty;

    public string Value { get; set; } = string.Empty;

    public string ValueKind { get; set; } = "String";
}

public sealed class AsplPackageServiceEntry
{
    public string ServiceName { get; set; } = string.Empty;

    public string DisplayName { get; set; } = string.Empty;

    public string ExecutablePath { get; set; } = string.Empty;

    public string Arguments { get; set; } = string.Empty;

    public string? Description { get; set; }

    public string? AccountName { get; set; }

    public string? AccountPassword { get; set; }

    public bool AutoStart { get; set; } = true;

    public bool DelayedAutoStart { get; set; }

    public List<string> Dependencies { get; set; } = new();
}

public sealed class AsplPackagePrerequisite
{
    public string Name { get; set; } = string.Empty;

    public string Version { get; set; } = string.Empty;

    public bool Required { get; set; } = true;

    public string? Description { get; set; }

    public string Type { get; set; } = string.Empty;

    public string? DetectionTarget { get; set; }

    public string? MinimumVersion { get; set; }

    public string? ExpectedValue { get; set; }
}

/// <summary>
/// Metadata stored in each <c>.asplpkg</c> package.
/// </summary>
public sealed class AsplPackageManifest
{
    public string ProductName { get; set; } = string.Empty;

    public string Version { get; set; } = string.Empty;

    public string Publisher { get; set; } = string.Empty;

    public string InstallPath { get; set; } = string.Empty;

    public bool HasIcon { get; set; }

    public bool HasLicense { get; set; }

    /// <summary>
    /// When true, Setup.exe shows a customization page (logo, company name, brand color)
    /// that the installing customer can fill in before the install proceeds.
    /// </summary>
    public bool AllowCustomerCustomization { get; set; }

    /// <summary>
    /// Author-set starting value for the customer customization page's "Company Name" field.
    /// Falls back to <see cref="Publisher"/> at runtime when null/blank.
    /// </summary>
    public string? DefaultCustomerCompanyName { get; set; }

    /// <summary>
    /// Author-set starting value for the customer customization page's "Brand Color" field
    /// (hex, e.g. "#FFFFFF"), or null to use the Runtime's built-in default swatch.
    /// </summary>
    public string? DefaultCustomerBrandColorHex { get; set; }

    /// <summary>
    /// True when the author supplied a default logo for the customer customization page,
    /// embedded as "customer-default-logo.png". The customer can still replace it via Browse.
    /// </summary>
    public bool HasCustomerDefaultLogo { get; set; }

    /// <summary>
    /// True when the author supplied a banner image (embedded as "branding-banner.png").
    /// </summary>
    public bool HasBrandingBanner { get; set; }

    /// <summary>
    /// True when the author supplied a Welcome/Finish page image (embedded as "branding-welcome.png").
    /// </summary>
    public bool HasBrandingWelcomeImage { get; set; }

    /// <summary>
    /// Author-set accent color (hex) applied to the setup wizard chrome, or null to use the
    /// Runtime's default theme accent.
    /// </summary>
    public string? BrandingAccentColorHex { get; set; }

    /// <summary>
    /// Author-set fill color (hex) shown behind the Welcome/Finish image, or null to use the
    /// Runtime's default card background.
    /// </summary>
    public string? BrandingWelcomeBackgroundColorHex { get; set; }

    public List<AsplPackageShortcut> Shortcuts { get; set; } = new();

    public List<AsplPackageIisSite> IisSites { get; set; } = new();

    public List<AsplPackageRegistryEntry> RegistryEntries { get; set; } = new();

    public List<AsplPackageServiceEntry> Services { get; set; } = new();

    public List<AsplPackagePrerequisite> Prerequisites { get; set; } = new();

    public List<CustomScreenDefinition> CustomScreens { get; set; } = new();
}

public sealed class AsplPackageInfo
{
    public required AsplPackageManifest Manifest { get; init; }

    public required string PackagePath { get; init; }
}

public sealed class PackageValidationResult
{
    private readonly List<string> _errors = new();

    public bool IsValid => _errors.Count == 0;

    public IReadOnlyList<string> Errors => _errors;

    public void AddError(string message)
    {
        if (!string.IsNullOrWhiteSpace(message))
        {
            _errors.Add(message);
        }
    }
}

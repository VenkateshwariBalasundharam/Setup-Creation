using System;

Console.WriteLine("SamplePayload started.");
Console.WriteLine("This is a demo EXE for ASPLShield Studio.");
Console.WriteLine($"Started at: {DateTimeOffset.Now:O}");

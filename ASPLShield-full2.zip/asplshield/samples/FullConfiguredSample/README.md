# Full Configured Sample

This folder contains a complete example installer project for ASPLShield Studio.

## What Is Included

- `FullConfiguredSample.asplproj` - the installer project
- `assets/ASPLShieldSample.ico` - demo application icon
- `assets/ASPLShieldSampleLicense.txt` - demo license text
- `..\SamplePayload\` - the sample EXE project used by the installer

## How To Use It

1. Build the payload first:

   ```powershell
   dotnet build ..\SamplePayload\SamplePayload.csproj
   ```

2. Open `FullConfiguredSample.asplproj` in ASPLShield Studio.
3. Review the tabs:
   - `Overview`
   - `Files`
   - `Shortcuts`
   - `Registry`
   - `IIS`
   - `Services`
   - `Prerequisites`
   - `Build`
   - `Settings`
4. Click `Build` to generate the sample package and bootstrappers.

## Notes

- The project is configured to use the sample icon and license files.
- The sample payload EXE lives at `..\SamplePayload\bin\Debug\net8.0\SamplePayload.exe` after build.
- If you move the repo, reopen the project and update any absolute paths if needed.


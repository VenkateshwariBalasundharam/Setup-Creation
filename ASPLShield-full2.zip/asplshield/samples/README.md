# Samples

This folder contains ready-to-use examples for ASPLShield Studio.

## Available Samples

- [SamplePayload](./SamplePayload) - a tiny demo EXE project you can build and package
- [FullConfiguredSample](./FullConfiguredSample) - a fully configured installer project using the sample payload

## Recommended Order

1. Build `SamplePayload` first.
2. Open `FullConfiguredSample/FullConfiguredSample.asplproj` in ASPLShield Studio.
3. Review the configuration and click `Build`.

## Useful Files

- [FullConfiguredSample README](./FullConfiguredSample/README.md)
- [Sample help guide](../ASPLShield-Studio-Help.md)

